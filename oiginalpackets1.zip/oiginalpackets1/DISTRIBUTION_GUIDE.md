# Distribution Guide for Smart Dispatch Optimizer

This guide explains how to package and distribute the Smart Dispatch Optimizer to users who cannot install software on their computers.

## Quick Start (Easiest Method)

### Step 1: Run the Build Script

Simply double-click `build_executable.bat` or run:

```powershell
.\build_executable.bat
```

This automated script will:
- ✅ Check/install PyInstaller
- ✅ Clean previous builds
- ✅ Build the standalone executable
- ✅ Copy user documentation
- ✅ Create a distribution zip file

### Step 2: Distribute to Users

Send users the file: `dist/SmartDispatchOptimizer_Distribution.zip`

**That's it!** Users just need to:
1. Extract the zip file
2. Read README_FOR_USERS.txt
3. Double-click SmartDispatchOptimizer.exe

---

## Manual Build (Alternative Method)

If you prefer to build manually:

### Install PyInstaller

```powershell
pip install pyinstaller
```

### Build Single File Executable

```powershell
pyinstaller --onefile --windowed --name "SmartDispatchOptimizer" databricks_gui.py
```

### Find the Executable

Your executable will be in: `dist/SmartDispatchOptimizer.exe`

---

## Distribution Options

### Option 1: Single Executable (Recommended)

**Pros:**
- ✅ Just one file to distribute
- ✅ Users can put it anywhere
- ✅ Simple and clean

**Cons:**
- ⚠️ Slower startup (extracts temp files on launch)
- ⚠️ Larger file size (~50-100 MB)

**How to Build:**
```powershell
pyinstaller --onefile --windowed --name "SmartDispatchOptimizer" databricks_gui.py
```

**What to Send:**
- `dist/SmartDispatchOptimizer.exe`
- `README_FOR_USERS.txt`

### Option 2: Folder with Dependencies

**Pros:**
- ✅ Faster startup time
- ✅ Easier to troubleshoot

**Cons:**
- ⚠️ Multiple files (users must keep together)
- ⚠️ Larger folder size

**How to Build:**
```powershell
pyinstaller --windowed --name "SmartDispatchOptimizer" databricks_gui.py
```

**What to Send:**
- Zip the entire `dist/SmartDispatchOptimizer` folder
- Include `README_FOR_USERS.txt` in the zip

---

## What Files to Include

### Essential Files (Users MUST have)

1. **SmartDispatchOptimizer.exe** - The application
2. **README_FOR_USERS.txt** - User instructions

### Optional Files

3. **databricks_credentials_TEMPLATE.json** - Template for credentials
   - Only if you want users to manually edit a config file
   - Usually NOT needed (users configure in GUI)

### Files to NEVER Include

❌ **databricks_credentials.json** - YOUR credentials (security risk!)
❌ **databricks_gui.py** - Source code (not needed)
❌ **.pyc files** - Compiled Python (included in .exe)
❌ **__pycache__** - Cache folders (not needed)

---

## Distribution Package Structure

Create a professional distribution package:

```
SmartDispatchOptimizer_Distribution/
│
├── SmartDispatchOptimizer.exe          # The application
├── README_FOR_USERS.txt                # User guide
└── databricks_credentials_TEMPLATE.json # Optional template
```

Zip this folder and send to users.

---

## Testing Before Distribution

### Test on Your Computer

1. Build the executable
2. Go to `dist` folder
3. Double-click `SmartDispatchOptimizer.exe`
4. Test all features:
   - Connection to Databricks ✓
   - Loading data ✓
   - Running optimization ✓
   - Exporting results ✓
   - Updating database ✓

### Test on a Clean Machine (Recommended)

Ideally, test on a computer that doesn't have:
- Python installed
- Your development environment
- Databricks credentials cached

This ensures users will have the same experience.

---

## Common User Issues & Solutions

### Issue 1: "Windows protected your PC"

**Cause:** Unsigned executable (Windows SmartScreen)

**Solution for Users:**
1. Click "More info"
2. Click "Run anyway"

**Solution for You (Advanced):**
- Purchase code signing certificate ($50-300/year)
- Sign the executable with `signtool`

### Issue 2: Antivirus Flags the .exe

**Cause:** PyInstaller executables sometimes trigger false positives

**Solution for Users:**
- Add exception in antivirus software
- Right-click → "Scan with [antivirus]" to verify it's safe
- Contact IT department to whitelist

**Solution for You:**
- Submit to antivirus vendors for whitelisting
- Use Nuitka instead of PyInstaller (creates native .exe)

### Issue 3: "Application failed to start"

**Cause:** Missing Visual C++ Runtime (rare)

**Solution:** User needs to install:
- Microsoft Visual C++ Redistributable
- Download from: https://aka.ms/vs/17/release/vc_redist.x64.exe

### Issue 4: Credentials Not Saving

**Cause:** User lacks write permissions in program folder

**Solution:** Tell users to:
- Run as Administrator (right-click → "Run as administrator")
- OR move .exe to their Documents folder
- OR IT needs to grant write permissions

---

## File Sizes

Expect these approximate sizes:

| Build Type | Size | Notes |
|------------|------|-------|
| Single file .exe | 50-100 MB | Includes Python + all libraries |
| Folder distribution | 150-200 MB | Unpacked dependencies |
| Zipped folder | 60-110 MB | Compressed for distribution |

**Note:** Large size is normal for Python applications packaged with PyInstaller.

---

## Version Updates

When you update the application code:

### Step 1: Make Your Changes

Edit `databricks_gui.py` as needed

### Step 2: Rebuild

```powershell
.\build_executable.bat
```

Or manually:
```powershell
pyinstaller --onefile --windowed --name "SmartDispatchOptimizer" databricks_gui.py
```

### Step 3: Update Version Number (Recommended)

In the build command, add version info:
```powershell
pyinstaller --onefile --windowed --name "SmartDispatchOptimizer_v1.1" databricks_gui.py
```

### Step 4: Test & Redistribute

Test the new .exe and send to users.

---

## Network Drives & Shared Locations

### Can Users Run from Network Drive?

✅ **Yes**, but:
- First launch may be slower
- Network must be reliable
- Multiple users can run simultaneously (each gets own session)

### Recommended Deployment:

1. **Option A: Email Distribution**
   - Send zip file via email
   - Users extract to their local computer
   - Simple but manual

2. **Option B: Shared Network Folder**
   - Place .exe on shared drive
   - Users copy to their computer OR run directly
   - Easier to update (replace one file)

3. **Option C: SharePoint/OneDrive**
   - Upload to company SharePoint
   - Users download latest version
   - Central location with version control

---

## Advanced: Creating an Installer

For a more professional distribution, create an installer:

### Using Inno Setup (Free)

1. Download: https://jrsoftware.org/isinfo.php
2. Create installer script
3. Builds a proper Windows installer (.msi or setup.exe)

**Pros:**
- Professional appearance
- Can install to Program Files
- Creates Start Menu shortcuts
- Uninstaller included

**Cons:**
- Users need admin rights to install
- More complex to set up

---

## Security Best Practices

### For You (Developer):

1. ❌ **NEVER** hardcode credentials in the source code
2. ❌ **NEVER** include your `databricks_credentials.json` in distribution
3. ✅ **ALWAYS** test with a test/demo account first
4. ✅ **ALWAYS** use HTTPS for Databricks connections (default)
5. ✅ **Consider** code signing for professional deployments

### For Users:

1. ✅ Each user should use their own Databricks credentials
2. ✅ Credentials are stored locally (not in the .exe)
3. ✅ Access tokens should be time-limited
4. ✅ Never share credentials between users

---

## Troubleshooting Build Issues

### "ModuleNotFoundError" during build

**Solution:** Explicitly specify hidden imports:

```powershell
pyinstaller --onefile --windowed --hidden-import=databricks.sql --hidden-import=databricks.sdk databricks_gui.py
```

### Build succeeds but .exe crashes

**Solution:** Test with console enabled to see errors:

```powershell
pyinstaller --onefile databricks_gui.py
# (Remove --windowed to see console errors)
```

### .exe file is too large

**Solution:** Use folder distribution instead of single file, or use UPX compression:

```powershell
pyinstaller --onefile --windowed --upx-dir=C:\path\to\upx databricks_gui.py
```

---

## Summary Checklist

Before distributing to users:

- [ ] Build executable using automated script
- [ ] Test executable on your computer
- [ ] Test on clean computer (if possible)
- [ ] Include README_FOR_USERS.txt
- [ ] Create distribution zip file
- [ ] Verify credentials file is NOT included
- [ ] Document any specific requirements
- [ ] Provide support contact information
- [ ] Test antivirus/SmartScreen behavior
- [ ] Prepare responses to common issues

---

## Quick Reference Commands

**Automated Build:**
```powershell
.\build_executable.bat
```

**Manual Build (single file):**
```powershell
pyinstaller --onefile --windowed --name "SmartDispatchOptimizer" databricks_gui.py
```

**Manual Build (folder):**
```powershell
pyinstaller --windowed --name "SmartDispatchOptimizer" databricks_gui.py
```

**Rebuild from spec:**
```powershell
pyinstaller SmartDispatchOptimizer.spec
```

**Clean builds:**
```powershell
Remove-Item build -Recurse -Force
Remove-Item dist -Recurse -Force
```

---

## Support Resources

- **PyInstaller Docs:** https://pyinstaller.org/en/stable/
- **Troubleshooting:** https://pyinstaller.org/en/stable/when-things-go-wrong.html
- **Code Signing:** https://docs.microsoft.com/en-us/windows/win32/seccrypto/signtool

---

**Need Help?**

If you encounter issues not covered in this guide, check the BUILD_EXECUTABLE.md file for more detailed technical information.

