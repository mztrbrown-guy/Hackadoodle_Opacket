# Building Standalone Executable for Distribution

This guide will help you create a standalone `.exe` file that other users can run without installing Python or any dependencies.

## Prerequisites (Only You Need These)

- Python installed on your computer
- All project dependencies installed
- PyInstaller (we'll install this)

## Step 1: Install PyInstaller

Open PowerShell/Command Prompt and run:

```powershell
pip install pyinstaller
```

## Step 2: Create the Executable

### Option A: Single File Executable (Recommended)

This creates one `.exe` file that contains everything:

```powershell
pyinstaller --onefile --windowed --name "SmartDispatchOptimizer" --icon=app_icon.ico databricks_gui.py
```

**Parameters explained:**
- `--onefile` - Creates a single executable file
- `--windowed` - No console window (GUI only)
- `--name` - Name of the executable
- `--icon` - Custom icon (optional, remove if you don't have one)

### Option B: Folder with Executable (Faster startup)

This creates a folder with the `.exe` and support files:

```powershell
pyinstaller --windowed --name "SmartDispatchOptimizer" databricks_gui.py
```

## Step 3: Find Your Executable

After building, you'll find:
- `dist/SmartDispatchOptimizer.exe` - Your standalone executable
- `build/` - Temporary build files (can be deleted)
- `SmartDispatchOptimizer.spec` - Build configuration (keep for rebuilding)

## Step 4: Test the Executable

1. Navigate to the `dist` folder
2. Double-click `SmartDispatchOptimizer.exe`
3. Test all features to ensure everything works

## Step 5: Distribute to Users

### For Single File (.exe)

Simply send them the `SmartDispatchOptimizer.exe` file from the `dist` folder.

**User Instructions:**
1. Download the `.exe` file
2. Double-click to run
3. That's it! No installation needed

### For Folder Distribution

1. Zip the entire `dist/SmartDispatchOptimizer` folder
2. Send the zip file to users

**User Instructions:**
1. Extract the zip file to any location
2. Double-click `SmartDispatchOptimizer.exe` inside the folder
3. Keep all files together - don't move the .exe out of the folder

## Step 6: Important Notes

### Credentials File

The `databricks_credentials.json` file will NOT be included in the executable for security reasons. Users will need to:

1. Configure their Databricks credentials on first run, OR
2. You can include a template credentials file in the same folder as the .exe

### Antivirus Warnings

Some antivirus software may flag PyInstaller executables as suspicious (false positive). To resolve:

- Have users right-click → "Run anyway" or add exception
- Code sign your executable (advanced, requires certificate)

### Windows Defender SmartScreen

First-time users may see "Windows protected your PC" warning:
- Click "More info"
- Click "Run anyway"
- This happens because the .exe isn't digitally signed

## Troubleshooting

### Build Fails

If the build fails with import errors, create a `requirements.txt`:

```powershell
pip freeze > requirements.txt
```

Then install PyInstaller in the same environment.

### Missing Dependencies

If the .exe crashes due to missing modules, create a spec file:

```powershell
pyinstaller --onefile --windowed databricks_gui.py
```

This creates `databricks_gui.spec`. Edit it to add hidden imports:

```python
hiddenimports=['databricks.sql', 'databricks.sdk', 'tkinter']
```

Then rebuild:

```powershell
pyinstaller databricks_gui.spec
```

### Large File Size

The .exe will be 30-100 MB because it includes Python and all libraries. This is normal.

## Advanced: Auto-py-to-exe (GUI Method)

If you prefer a graphical interface:

```powershell
pip install auto-py-to-exe
auto-py-to-exe
```

This opens a GUI where you can:
1. Select your script
2. Choose options with checkboxes
3. Click "Convert .py to .exe"

## Distribution Package Structure

Create a distribution folder with:

```
SmartDispatchOptimizer/
├── SmartDispatchOptimizer.exe
├── README_FOR_USERS.txt
└── databricks_credentials_template.json (optional)
```

## Rebuilding After Code Changes

Whenever you update the code:

```powershell
pyinstaller --onefile --windowed --name "SmartDispatchOptimizer" databricks_gui.py
```

Or use the spec file:

```powershell
pyinstaller SmartDispatchOptimizer.spec
```

## Security Considerations

⚠️ **Important:**
- Never include your personal credentials in the executable
- Users should configure their own Databricks credentials
- The credentials file is stored locally on each user's computer
- Credentials are not embedded in the .exe

## Support for Users

Provide users with:
1. The `.exe` file
2. A simple README with:
   - How to run the application
   - How to configure Databricks connection
   - Who to contact for support

