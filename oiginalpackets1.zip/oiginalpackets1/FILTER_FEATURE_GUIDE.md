# 🔍 Column Filters Feature Guide

## Overview

The Optimization Results table now includes **real-time column filters** to help you quickly find and analyze specific data in your optimization results.

---

## How to Use Filters

### Step 1: Run Optimization

First, run the optimization to generate results:
1. Click **▶️ Run Optimization**
2. Wait for results to appear in the table

### Step 2: Filter Your Results

Above the results table, you'll see a **"🔍 Column Filters"** section with 8 filter input boxes - one for each column:

```
┌─────────────────────────────────────────────────────────────────────┐
│ 🔍 Column Filters (type to filter)                                  │
├─────────────────────────────────────────────────────────────────────┤
│ [Dispatch ID] [Required Skill] [City, State] [Original Tech] ...   │
│                                                                      │
│               [✖ Clear All Filters]                                  │
└─────────────────────────────────────────────────────────────────────┘
```

### Step 3: Type to Filter

Simply type in any filter box to instantly filter the results:

**Example Filters:**

| Filter Type | Filter Box | Type This | Result |
|-------------|------------|-----------|--------|
| **Specific Dispatch** | Dispatch ID | `200000050` | Shows only that dispatch |
| **By Skill** | Required Skill | `fiber` | Shows all Fiber ONT installations |
| **By City** | City, State | `dallas` | Shows all Dallas dispatches |
| **By Technician** | Original Tech | `T900045` | Shows all dispatches for that tech |
| **By Status** | Status | `yes` | Shows only successful matches |
| **Distance Range** | Distance (mi) | `5` | Shows dispatches with "5" in distance |

### Step 4: Combine Multiple Filters

**Filters work together!** Type in multiple boxes to narrow down results:

**Example:** Find all Fiber installations in Dallas that succeeded
- Required Skill: `fiber`
- City, State: `dallas`
- Status: `yes`

The table will show only rows that match ALL filters.

### Step 5: Clear Filters

To see all results again:
- **Option A:** Delete text from filter boxes manually
- **Option B:** Click **✖ Clear All Filters** button (clears all at once)

---

## Filter Behavior

### ✅ What Filters Do:

1. **Real-time Search** - Results update as you type
2. **Case-Insensitive** - "Dallas", "dallas", and "DALLAS" all work
3. **Partial Match** - "fiber" matches "Fiber ONT installation"
4. **Multiple Filters** - All active filters must match (AND logic)
5. **Works on Visible Text** - Searches what you see in the table

### ❌ What Filters Don't Do:

- Regular expressions (advanced patterns)
- Greater than / Less than comparisons
- Date range filtering
- Sorting (use column headers for that)

---

## Common Use Cases

### 1. Find Problem Dispatches

**Goal:** Find dispatches that didn't get matched

**How:**
- Status filter: `no`

**Result:** Shows all "No" status rows (no available technician)

---

### 2. Review Specific City

**Goal:** See all assignments in Houston

**How:**
- City, State filter: `houston`

**Result:** Shows only Houston dispatches

---

### 3. Check Technician Workload

**Goal:** See what was assigned to a specific tech

**How:**
- Optimized Tech filter: `T900125`

**Result:** Shows all assignments for that technician

---

### 4. Find Long Distance Dispatches

**Goal:** Find dispatches over 10 miles

**How:**
- Distance (mi) filter: Type values one at a time (e.g., `15`, `20`, `25`)

**Result:** Shows dispatches with those distance values

**Note:** For true range filtering (>10), you'd need to export to Excel

---

### 5. Compare Before/After

**Goal:** See where technician was changed

**How:**
- Look for rows where "Original Tech" ≠ "Optimized Tech"
- Manual review or export to Excel for comparison

---

### 6. Skill-Specific Analysis

**Goal:** Analyze all Network Troubleshooting dispatches

**How:**
- Required Skill filter: `network`

**Result:** Shows all network-related skills

---

## Tips & Tricks

### 💡 Tip 1: Start Broad, Then Narrow

```
Step 1: Status = "yes"         (shows all successful matches)
Step 2: Add City = "dallas"    (narrows to Dallas only)
Step 3: Add Skill = "fiber"    (narrows to Fiber in Dallas)
```

### 💡 Tip 2: Use Short Keywords

Instead of typing full text, use keywords:
- ✅ `fiber` instead of `Fiber ONT installation`
- ✅ `tech` instead of `technician`
- ✅ `T900` to see all techs starting with T900

### 💡 Tip 3: Clear and Restart

If results seem wrong:
1. Click **✖ Clear All Filters**
2. Start over with fresh filters

### 💡 Tip 4: Export After Filtering

Filters affect the **display only**, not the export:
- Export always includes ALL results
- To export filtered data:
  1. Filter in the GUI
  2. Copy visible rows manually
  3. OR export all → filter in Excel

### 💡 Tip 5: Watch Filter Count

After filtering, look at how many rows remain:
- Scroll to see all filtered results
- If zero results, your filters might be too restrictive

---

## Advanced Filtering (Export to Excel)

For advanced analysis, export to CSV then use Excel/Python:

**Excel Advanced Filters:**
- Number ranges (distance > 10)
- Date calculations
- Complex formulas
- Pivot tables
- Charts and graphs

**How to Export:**
1. Run optimization
2. Click **📤 Export to CSV**
3. Open in Excel
4. Use Excel's filter/sort features

---

## Filter Keyboard Shortcuts

| Action | Shortcut |
|--------|----------|
| Move between filter boxes | `Tab` |
| Clear current filter box | `Ctrl + A` then `Delete` |
| Apply filter | Type (automatic) |

---

## Troubleshooting

### Problem: Filter not working

**Causes & Solutions:**

1. **No results loaded**
   - Solution: Run optimization first

2. **Typo in filter text**
   - Solution: Check spelling, try shorter keyword

3. **Too many filters active**
   - Solution: Clear some filters to broaden results

4. **Case sensitivity assumption**
   - Solution: Filters are case-insensitive, try different text

---

### Problem: Results disappear

**Cause:** Active filter with no matches

**Solution:**
- Click **✖ Clear All Filters**
- Check which filters are filled in
- Remove filters one at a time

---

### Problem: Can't find "✖ Clear All Filters" button

**Location:** 
- Inside the "🔍 Column Filters" section
- Below the filter input boxes
- Above the results table

---

## Filter Performance

### Speed

- **Instant filtering** for results up to 1,000 rows
- **Fast filtering** for results up to 10,000 rows
- **May lag** for extremely large datasets (100,000+ rows)

If filtering is slow, consider exporting to CSV and using Excel or Python.

---

## Examples in Action

### Example 1: Quality Control Check

**Scenario:** Verify all high-priority dispatches got matched

**Steps:**
1. Run optimization
2. Filter Status: `no`
3. Review any unmatched dispatches
4. Investigate why (no skill match, no capacity, etc.)

---

### Example 2: Geographic Analysis

**Scenario:** Compare optimization performance by city

**Steps:**
1. Filter City: `dallas`
2. Note average distance
3. Clear filter, repeat for other cities
4. Compare results

---

### Example 3: Technician Load Balancing

**Scenario:** Check if specific techs are overloaded

**Steps:**
1. Filter Optimized Tech: `T900001`
2. Count how many assignments
3. Check Workload % values
4. Repeat for other techs

---

## Summary

**Filters Help You:**
- ✅ Find specific dispatches quickly
- ✅ Analyze subsets of data
- ✅ Verify optimization quality
- ✅ Investigate problems
- ✅ Compare before/after assignments

**Remember:**
- Type to filter (real-time)
- Multiple filters work together (AND)
- Clear filters to reset
- Export for advanced analysis

---

**Need More Help?**

See main README_FOR_USERS.txt for general application help.

---

**Filter Feature Version:** 1.0  
**Last Updated:** November 2024

