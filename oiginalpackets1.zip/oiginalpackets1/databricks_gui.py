import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog, simpledialog
import json
import os
import sys
from databricks import sql
from databricks.sdk import WorkspaceClient
import threading
from datetime import datetime
import tkintermapview
import math
from collections import defaultdict

class DatabricksGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Dispatch Optimizer - Databricks")
        
        # Responsive window sizing
        self.root.geometry("1350x850")  # Initial size: 800px (left) + 500px (map) + 50px (padding)
        self.root.minsize(900, 600)  # Minimum size for mobile/small screens
        self.root.configure(bg='#f0f0f0')
        
        # Connection variables
        self.server_hostname = tk.StringVar()
        self.http_path = tk.StringVar()
        self.access_token = tk.StringVar()
        self.workspace_url = tk.StringVar()
        self.connection = None
        self.workspace_client = None
        
        # Profile management
        self.current_profile = tk.StringVar()
        self.profiles = {}
        
        # Load saved configuration
        self.config_file = "databricks_config.json"
        self.load_config()
        
        # Initialize ticket and technician data for map
        self.ticket_data = {}
        self.technician_data = []
        self.selected_ticket_lat = None
        self.selected_ticket_lon = None
        self.selected_ticket_state = None
        self.selected_ticket_label = None  # Label for selected ticket
        self.selected_ticket_marker = None  # Marker for selected ticket location
        
        self.create_widgets()
    
    # ==================== OPTIMIZATION FUNCTIONS ====================
    
    def haversine_distance(self, lat1, lon1, lat2, lon2):
        """
        Calculate the great circle distance between two points 
        on the earth (specified in decimal degrees)
        Returns distance in miles
        """
        # Convert decimal degrees to radians
        lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
        
        # Haversine formula
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        
        # Radius of earth in miles
        r = 3959
        
        return c * r
    
    def optimize_dispatch_assignments(self, dispatches, technicians, calendar_data):
        """
        Optimize dispatch assignments based on three factors:
        1. Skill matching (required_skill must match technician's primary_skill)
        2. Distance minimization (assign closest available technician)
        3. Workload balancing (don't overload technicians)
        4. Calendar availability (technician must be available on dispatch date)
        
        Returns: List of optimized assignments with metrics
        """
        optimized_assignments = []
        metrics = {
            'total_dispatches': len(dispatches),
            'skill_matches': 0,
            'avg_distance': 0,
            'overloaded_techs': 0,
            'calendar_checks': 0
        }
        
        # Create a copy of technician workload to track assignments
        tech_workload = {}
        for tech in technicians:
            tech_workload[tech['Technician_id']] = {
                'current': tech['Current_assignments'],
                'capacity': tech['Workload_capacity'],
                'skill': tech['Primary_skill'],
                'lat': tech['Latitude'],
                'lon': tech['Longitude'],
                'city': tech['City']
            }
        
        # Create calendar lookup: {technician_id: {date: availability_info}}
        calendar_lookup = defaultdict(dict)
        for cal_entry in calendar_data:
            tech_id = cal_entry['Technician_id']
            date = cal_entry['Date']
            calendar_lookup[tech_id][date] = {
                'available': cal_entry['Available'],
                'max_assignments': cal_entry.get('Max_assignments', 0)
            }
        
        total_distance = 0
        
        for dispatch in dispatches:
            dispatch_id = dispatch['Dispatch_id']
            required_skill = dispatch['Required_skill']
            customer_lat = dispatch['Customer_latitude']
            customer_lon = dispatch['Customer_longitude']
            dispatch_city = dispatch['City']
            
            # Extract date from appointment_start_time
            appointment_time = dispatch.get('Appointment_start_time', '')
            if appointment_time:
                # Handle both string and datetime formats
                if isinstance(appointment_time, str):
                    dispatch_date = appointment_time.split()[0]  # Get date part (YYYY-MM-DD)
                else:
                    dispatch_date = appointment_time.date().isoformat()
            else:
                dispatch_date = None
            
            # Find all technicians with matching skill
            matching_technicians = []
            for tech_id, tech_info in tech_workload.items():
                # Check skill match
                if tech_info['skill'] != required_skill:
                    continue
                
                # Check workload capacity
                if tech_info['current'] >= tech_info['capacity']:
                    continue
                
                # Check calendar availability if dispatch date is available
                if dispatch_date and tech_id in calendar_lookup:
                    cal_info = calendar_lookup[tech_id].get(dispatch_date, {})
                    if not cal_info.get('available', 0):
                        continue
                    metrics['calendar_checks'] += 1
                
                # Calculate distance
                distance = self.haversine_distance(
                    customer_lat, customer_lon,
                    tech_info['lat'], tech_info['lon']
                )
                
                matching_technicians.append({
                    'technician_id': tech_id,
                    'distance': distance,
                    'workload_pct': (tech_info['current'] / tech_info['capacity']) * 100,
                    'city': tech_info['city']
                })
            
            # Select best technician based on:
            # 1. Prioritize same city
            # 2. Shortest distance
            # 3. Lower workload percentage
            best_tech = None
            if matching_technicians:
                # Sort by: city match (desc), distance (asc), workload (asc)
                matching_technicians.sort(key=lambda x: (
                    x['city'] != dispatch_city,  # False (0) comes first = same city prioritized
                    x['distance'],  # Shorter distance first
                    x['workload_pct']  # Lower workload first
                ))
                best_tech = matching_technicians[0]
                
                # Update workload
                tech_workload[best_tech['technician_id']]['current'] += 1
                
                # Update metrics
                metrics['skill_matches'] += 1
                total_distance += best_tech['distance']
            
            # Get state for display
            dispatch_state = dispatch.get('State', '')
            city_state = f"{dispatch_city}, {dispatch_state}" if dispatch_state else dispatch_city
            
            optimized_assignments.append({
                'Dispatch_id': dispatch_id,
                'Required_skill': required_skill,
                'Customer_city': dispatch_city,
                'Customer_city_state': city_state,
                'Original_technician': dispatch.get('Assigned_technician_id', ''),
                'Optimized_technician': best_tech['technician_id'] if best_tech else '',
                'Distance_mi': round(best_tech['distance'], 2) if best_tech else None,
                'Workload_pct': round(best_tech['workload_pct'], 1) if best_tech else None,
                'Match_found': 'Yes' if best_tech else 'No',
                'Reason': 'Optimal match' if best_tech else 'No available technician with required skill'
            })
        
        # Calculate final metrics
        if metrics['skill_matches'] > 0:
            metrics['avg_distance'] = round(total_distance / metrics['skill_matches'], 2)
        
        # Count overloaded technicians after optimization
        metrics['overloaded_techs'] = sum(1 for tech in tech_workload.values() 
                                         if tech['current'] >= tech['capacity'])
        
        metrics['skill_match_rate'] = round((metrics['skill_matches'] / metrics['total_dispatches']) * 100, 1)
        
        return optimized_assignments, metrics
        
    def load_config(self):
        """Load saved configuration from file"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    
                    # Check if it's the new profile-based format
                    if 'profiles' in config:
                        self.profiles = config.get('profiles', {})
                        current_profile_name = config.get('current_profile', '')
                        
                        # If we have profiles, load the current one
                        if current_profile_name and current_profile_name in self.profiles:
                            self.current_profile.set(current_profile_name)
                            profile = self.profiles[current_profile_name]
                            self.server_hostname.set(profile.get('server_hostname', '').strip())
                            self.http_path.set(profile.get('http_path', '').strip())
                            self.access_token.set(profile.get('access_token', '').strip())
                            self.workspace_url.set(profile.get('workspace_url', '').strip())
                        elif self.profiles:
                            # Load first profile if current_profile not set
                            first_profile = list(self.profiles.keys())[0]
                            self.current_profile.set(first_profile)
                            profile = self.profiles[first_profile]
                            self.server_hostname.set(profile.get('server_hostname', '').strip())
                            self.http_path.set(profile.get('http_path', '').strip())
                            self.access_token.set(profile.get('access_token', '').strip())
                            self.workspace_url.set(profile.get('workspace_url', '').strip())
                    else:
                        # Legacy format - migrate to profile format
                        profile_name = "Default"
                        self.profiles[profile_name] = {
                            'server_hostname': config.get('server_hostname', '').strip(),
                            'http_path': config.get('http_path', '').strip(),
                            'access_token': config.get('access_token', '').strip(),
                            'workspace_url': config.get('workspace_url', '').strip()
                        }
                        self.current_profile.set(profile_name)
                        self.server_hostname.set(config.get('server_hostname', '').strip())
                        self.http_path.set(config.get('http_path', '').strip())
                        self.access_token.set(config.get('access_token', '').strip())
                        self.workspace_url.set(config.get('workspace_url', '').strip())
                        # Save in new format
                        self.save_all_profiles()
                
                # If no profiles exist, create a default one
                if not self.profiles:
                    profile_name = "Default"
                    self.profiles[profile_name] = {
                        'server_hostname': '',
                        'http_path': '',
                        'access_token': '',
                        'workspace_url': ''
                    }
                    self.current_profile.set(profile_name)
            except Exception as e:
                print(f"Error loading config: {e}")
                # Create default profile on error
                if not self.profiles:
                    profile_name = "Default"
                    self.profiles[profile_name] = {
                        'server_hostname': '',
                        'http_path': '',
                        'access_token': '',
                        'workspace_url': ''
                    }
                    self.current_profile.set(profile_name)
    
    def save_all_profiles(self):
        """Save all profiles to file"""
        config = {
            'current_profile': self.current_profile.get(),
            'profiles': self.profiles
        }
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            return True
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save config: {e}")
            return False
    
    def save_config(self):
        """Save current configuration as a profile"""
        profile_name = self.current_profile.get().strip()
        
        if not profile_name:
            # Ask for profile name
            profile_name = simpledialog.askstring(
                "Profile Name",
                "Enter a name for this profile:",
                initialvalue="Profile 1"
            )
            if not profile_name:
                messagebox.showwarning("Warning", "Profile name is required")
                return False
            self.current_profile.set(profile_name)
        
        # Save current values to profile
        self.profiles[profile_name] = {
            'server_hostname': self.server_hostname.get().strip(),
            'http_path': self.http_path.get().strip(),
            'access_token': self.access_token.get().strip(),
            'workspace_url': self.workspace_url.get().strip()
        }
        
        # Save all profiles
        if self.save_all_profiles():
            messagebox.showinfo("Success", f"Configuration saved as profile: {profile_name}")
            # Update profile dropdown
            if hasattr(self, 'profile_combo'):
                self.update_profile_dropdown()
            return True
        return False
    
    def load_profile(self, profile_name):
        """Load a profile"""
        if profile_name in self.profiles:
            profile = self.profiles[profile_name]
            self.server_hostname.set(profile.get('server_hostname', '').strip())
            self.http_path.set(profile.get('http_path', '').strip())
            self.access_token.set(profile.get('access_token', '').strip())
            self.workspace_url.set(profile.get('workspace_url', '').strip())
            self.current_profile.set(profile_name)
            self.save_all_profiles()  # Update current_profile in file
            return True
        return False
    
    def delete_profile(self):
        """Delete current profile"""
        profile_name = self.current_profile.get()
        if not profile_name:
            messagebox.showwarning("Warning", "No profile selected")
            return
        
        if len(self.profiles) <= 1:
            messagebox.showwarning("Warning", "Cannot delete the last profile")
            return
        
        # Confirm deletion
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete profile '{profile_name}'?"):
            del self.profiles[profile_name]
            
            # Switch to first available profile
            first_profile = list(self.profiles.keys())[0]
            self.load_profile(first_profile)
            
            # Update dropdown
            self.update_profile_dropdown()
            
            messagebox.showinfo("Success", f"Profile '{profile_name}' deleted")
    
    def create_new_profile(self):
        """Create a new profile"""
        profile_name = simpledialog.askstring(
            "New Profile",
            "Enter a name for the new profile:",
            initialvalue=f"Profile {len(self.profiles) + 1}"
        )
        
        if profile_name and profile_name.strip():
            profile_name = profile_name.strip()
            if profile_name in self.profiles:
                messagebox.showwarning("Warning", f"Profile '{profile_name}' already exists")
                return
            
            # Create empty profile
            self.profiles[profile_name] = {
                'server_hostname': '',
                'http_path': '',
                'access_token': '',
                'workspace_url': ''
            }
            
            # Switch to new profile
            self.load_profile(profile_name)
            self.update_profile_dropdown()
    
    def update_profile_dropdown(self):
        """Update the profile dropdown with current profiles"""
        if hasattr(self, 'profile_combo'):
            current = self.current_profile.get()
            self.profile_combo['values'] = list(self.profiles.keys())
            self.profile_combo.set(current)
    
    def get_access_token(self):
        """Get access token with whitespace stripped"""
        return self.access_token.get().strip()
    
    def calculate_distance(self, lat1, lon1, lat2, lon2):
        """Calculate distance between two points using Haversine formula (in miles)"""
        from math import radians, sin, cos, sqrt, atan2
        
        # Radius of Earth in miles
        R = 3959.0
        
        # Convert to radians
        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        
        # Haversine formula
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
        c = 2 * atan2(sqrt(a), sqrt(1 - a))
        distance = R * c
        
        return distance
    
    def on_profile_selected(self, event=None):
        """Handle profile selection change"""
        profile_name = self.current_profile.get()
        if profile_name:
            self.load_profile(profile_name)
    
    def create_widgets(self):
        """Create the main GUI widgets"""
        # Create notebook (tabbed interface)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Dispatch Optimizer Tab - The ONLY tab
        self.optimizer_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.optimizer_frame, text="Dispatch Optimizer")
        self.create_optimizer_tab()
    
    def create_connection_tab(self):
        """Create connection configuration tab"""
        # Profile management frame
        profile_frame = ttk.LabelFrame(self.connection_frame, text="Profile Management", padding=10)
        profile_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Profile dropdown
        ttk.Label(profile_frame, text="Profile:", font=('TkDefaultFont', 9)).grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.profile_combo = ttk.Combobox(profile_frame, textvariable=self.current_profile, width=25, state='readonly')
        self.profile_combo.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        self.profile_combo.bind('<<ComboboxSelected>>', self.on_profile_selected)
        
        # Profile buttons
        profile_buttons = ttk.Frame(profile_frame)
        profile_buttons.grid(row=0, column=2, padx=10, pady=5)
        
        ttk.Button(profile_buttons, text="New Profile", command=self.create_new_profile, width=12).pack(side=tk.LEFT, padx=3)
        ttk.Button(profile_buttons, text="Delete Profile", command=self.delete_profile, width=12).pack(side=tk.LEFT, padx=3)
        
        # Update dropdown with existing profiles
        self.update_profile_dropdown()
        
        # Connection settings frame
        settings_frame = ttk.LabelFrame(self.connection_frame, text="Connection Settings", padding=20)
        settings_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Server Hostname
        ttk.Label(settings_frame, text="Server Hostname:", font=('TkDefaultFont', 9)).grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Entry(settings_frame, textvariable=self.server_hostname, width=50).grid(row=0, column=1, pady=5, padx=10)
        
        # HTTP Path
        ttk.Label(settings_frame, text="HTTP Path:", font=('TkDefaultFont', 9)).grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(settings_frame, textvariable=self.http_path, width=50).grid(row=1, column=1, pady=5, padx=10)
        
        # Access Token
        ttk.Label(settings_frame, text="Access Token:", font=('TkDefaultFont', 9)).grid(row=2, column=0, sticky=tk.W, pady=5)
        token_entry = ttk.Entry(settings_frame, textvariable=self.access_token, width=50, show="*")
        token_entry.grid(row=2, column=1, pady=5, padx=10)
        
        # Workspace URL (for Workspace API)
        ttk.Label(settings_frame, text="Workspace URL:", font=('TkDefaultFont', 9)).grid(row=3, column=0, sticky=tk.W, pady=5)
        ttk.Entry(settings_frame, textvariable=self.workspace_url, width=50).grid(row=3, column=1, pady=5, padx=10)
        
        # Buttons frame
        button_frame = ttk.Frame(settings_frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=20)
        
        ttk.Button(button_frame, text="Save Configuration", command=self.save_config, width=18).pack(side=tk.LEFT, padx=3)
        ttk.Button(button_frame, text="Test SQL Connection", command=self.test_sql_connection, width=18).pack(side=tk.LEFT, padx=3)
        ttk.Button(button_frame, text="Test Workspace Connection", command=self.test_workspace_connection, width=22).pack(side=tk.LEFT, padx=3)
        
        # Status frame
        status_frame = ttk.LabelFrame(self.connection_frame, text="Connection Status", padding=10)
        status_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.status_text = scrolledtext.ScrolledText(status_frame, height=10, wrap=tk.WORD)
        self.status_text.pack(fill=tk.BOTH, expand=True)
        self.status_text.insert(tk.END, "Ready to connect. Please configure your connection settings.\n")
        self.status_text.config(state=tk.DISABLED)
    
    def create_sql_tab(self):
        """Create SQL query tab"""
        # Query input frame
        query_frame = ttk.LabelFrame(self.sql_frame, text="SQL Query", padding=10)
        query_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.sql_query_text = scrolledtext.ScrolledText(query_frame, height=10, wrap=tk.NONE, font=('Consolas', 10))
        self.sql_query_text.pack(fill=tk.BOTH, expand=True)
        
        # Buttons
        button_frame = ttk.Frame(query_frame)
        button_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(button_frame, text="Execute Query", command=self.execute_sql_query, width=15).pack(side=tk.LEFT, padx=3)
        ttk.Button(button_frame, text="Clear", command=lambda: self.sql_query_text.delete(1.0, tk.END), width=15).pack(side=tk.LEFT, padx=3)
        ttk.Button(button_frame, text="Load Query from File", command=self.load_query_file, width=18).pack(side=tk.LEFT, padx=3)
        
        # Search/Filter frame (moved from Technician Details tab)
        filter_frame = ttk.LabelFrame(self.sql_frame, text="Search Filters", padding=10)
        filter_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        # Search term
        ttk.Label(filter_frame, text="Search Term:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.search_term_var = tk.StringVar()
        search_entry = ttk.Entry(filter_frame, textvariable=self.search_term_var, width=40)
        search_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # Column to search (optional)
        ttk.Label(filter_frame, text="Column (optional):").grid(row=0, column=2, sticky=tk.W, padx=5, pady=5)
        self.search_column_var = tk.StringVar()
        ttk.Entry(filter_frame, textvariable=self.search_column_var, width=30).grid(row=0, column=3, padx=5, pady=5)
        
        # Limit results
        ttk.Label(filter_frame, text="Limit:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.limit_var = tk.StringVar(value="100")
        ttk.Entry(filter_frame, textvariable=self.limit_var, width=10).grid(row=1, column=1, sticky=tk.W, padx=5, pady=5)
        
        # Query type selection
        ttk.Label(filter_frame, text="Query Type:").grid(row=1, column=2, sticky=tk.W, padx=5, pady=5)
        self.query_type_var = tk.StringVar(value="all")
        query_types = [
            ("Search (LIKE)", "search"),
            ("Exact Match", "exact"),
            ("Show All", "all"),
            ("Show Schema", "schema")
        ]
        for i, (text, value) in enumerate(query_types):
            rb = ttk.Radiobutton(filter_frame, text=text, variable=self.query_type_var, value=value)
            rb.grid(row=1, column=3+i, padx=5, pady=5)
        
        # Results frame
        results_frame = ttk.LabelFrame(self.sql_frame, text="Query Results", padding=10)
        results_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Treeview for results
        self.sql_results_tree = ttk.Treeview(results_frame)
        self.sql_results_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        # Scrollbar for treeview
        sql_scrollbar = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.sql_results_tree.yview)
        sql_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.sql_results_tree.configure(yscrollcommand=sql_scrollbar.set)
        
        # Status label
        self.sql_status_label = ttk.Label(self.sql_frame, text="Ready to execute queries")
        self.sql_status_label.pack(pady=5)
    
    def create_tickets_tab(self):
        """Create Tickets tab with filters, table, and map"""
        # Main container with responsive layout
        main_container = ttk.Frame(self.tickets_frame)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        main_container.grid_rowconfigure(0, weight=1)
        
        # Responsive columns: Tickets section + Map
        main_container.grid_columnconfigure(0, weight=8, minsize=600)  # Tickets section
        main_container.grid_columnconfigure(1, weight=5, minsize=400)  # Map
        
        # LEFT PANEL: Tickets Section
        tickets_panel = ttk.Frame(main_container)
        tickets_panel.grid(row=0, column=0, sticky='nsew', padx=(0, 3))
        tickets_panel.grid_rowconfigure(0, weight=1)
        tickets_panel.grid_columnconfigure(0, weight=1)
        
        # Tickets frame
        tickets_frame = ttk.LabelFrame(tickets_panel, text="Tickets", padding=5)
        tickets_frame.grid(row=0, column=0, sticky='nsew')
        tickets_frame.grid_rowconfigure(0, weight=1)
        tickets_frame.grid_columnconfigure(0, weight=0, minsize=150)  # Left: filters (fixed 150px)
        tickets_frame.grid_columnconfigure(1, weight=1, minsize=400)  # Right: results (min 400px)
        
        # Tickets filters (left side, vertical)
        tickets_buttons_frame = ttk.Frame(tickets_frame, width=150)
        tickets_buttons_frame.grid(row=0, column=0, sticky='ns', padx=(0, 5))
        tickets_buttons_frame.grid_propagate(False)
        
        # Ticket Type filter
        ttk.Label(tickets_buttons_frame, text="Tickets:", font=('TkDefaultFont', 9)).grid(row=0, column=0, sticky=tk.W, padx=3, pady=3)
        self.ticket_type_var = tk.StringVar()
        self.ticket_type_combo = ttk.Combobox(tickets_buttons_frame, textvariable=self.ticket_type_var, width=15, state='readonly')
        self.ticket_type_combo['values'] = ('All',)
        self.ticket_type_combo.current(0)
        self.ticket_type_combo.grid(row=1, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Priority filter
        ttk.Label(tickets_buttons_frame, text="Priority:", font=('TkDefaultFont', 9)).grid(row=2, column=0, sticky=tk.W, padx=3, pady=3)
        self.ticket_priority_var = tk.StringVar()
        self.ticket_priority_combo = ttk.Combobox(tickets_buttons_frame, textvariable=self.ticket_priority_var, width=15, state='readonly')
        self.ticket_priority_combo['values'] = ('All',)
        self.ticket_priority_combo.current(0)
        self.ticket_priority_combo.grid(row=3, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Skills filter
        ttk.Label(tickets_buttons_frame, text="Skills:", font=('TkDefaultFont', 9)).grid(row=4, column=0, sticky=tk.W, padx=3, pady=3)
        self.ticket_skill_var = tk.StringVar()
        self.ticket_skill_combo = ttk.Combobox(tickets_buttons_frame, textvariable=self.ticket_skill_var, width=15, state='readonly')
        self.ticket_skill_combo['values'] = ('All',)
        self.ticket_skill_combo.current(0)
        self.ticket_skill_combo.grid(row=5, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Appointment Slots filter
        ttk.Label(tickets_buttons_frame, text="Appointment:", font=('TkDefaultFont', 9)).grid(row=6, column=0, sticky=tk.W, padx=3, pady=3)
        self.ticket_appointment_var = tk.StringVar()
        self.ticket_appointment_combo = ttk.Combobox(tickets_buttons_frame, textvariable=self.ticket_appointment_var, width=15, state='readonly')
        self.ticket_appointment_combo['values'] = ('All',)
        self.ticket_appointment_combo.current(0)
        self.ticket_appointment_combo.grid(row=7, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Start Date/Time filter
        ttk.Label(tickets_buttons_frame, text="Start Date:", font=('TkDefaultFont', 9)).grid(row=8, column=0, sticky=tk.W, padx=3, pady=3)
        self.ticket_start_date_var = tk.StringVar()
        self.ticket_start_date_entry = ttk.Entry(tickets_buttons_frame, textvariable=self.ticket_start_date_var, width=17)
        self.ticket_start_date_entry.grid(row=9, column=0, padx=3, pady=(0, 5), sticky='ew')
        # Set default to today at 00:00:00
        today_start = datetime.now().strftime("%Y-%m-%d 00:00:00")
        self.ticket_start_date_entry.insert(0, today_start)
        
        # End Date/Time filter
        ttk.Label(tickets_buttons_frame, text="End Date:", font=('TkDefaultFont', 9)).grid(row=10, column=0, sticky=tk.W, padx=3, pady=3)
        self.ticket_end_date_var = tk.StringVar()
        self.ticket_end_date_entry = ttk.Entry(tickets_buttons_frame, textvariable=self.ticket_end_date_var, width=17)
        self.ticket_end_date_entry.grid(row=11, column=0, padx=3, pady=(0, 5), sticky='ew')
        # Set default to today at 23:59:59
        today_end = datetime.now().strftime("%Y-%m-%d 23:59:59")
        self.ticket_end_date_entry.insert(0, today_end)
        
        # Distance filter (for showing nearby technicians)
        ttk.Label(tickets_buttons_frame, text="Show Techs:", font=('TkDefaultFont', 9)).grid(row=12, column=0, sticky=tk.W, padx=3, pady=3)
        self.ticket_distance_var = tk.StringVar(value='All')
        self.ticket_distance_combo = ttk.Combobox(tickets_buttons_frame, textvariable=self.ticket_distance_var, width=15, state='readonly')
        self.ticket_distance_combo['values'] = ('All', '10 miles', '100 miles', '1000 miles')
        self.ticket_distance_combo.current(0)
        self.ticket_distance_combo.grid(row=13, column=0, padx=3, pady=(0, 10), sticky='ew')
        self.ticket_distance_combo.bind('<<ComboboxSelected>>', lambda e: self.update_tickets_map())
        
        # Buttons frame
        button_frame = ttk.Frame(tickets_buttons_frame)
        button_frame.grid(row=14, column=0, pady=5, sticky='ew')
        
        ttk.Button(button_frame, text="Load Tickets", command=self.load_dispatches).pack(fill=tk.X, padx=3, pady=2)
        ttk.Button(button_frame, text="Refresh", command=self.load_dispatches).pack(fill=tk.X, padx=3, pady=2)
        ttk.Button(button_frame, text="Clear Filters", command=self.clear_ticket_filters).pack(fill=tk.X, padx=3, pady=2)
        
        # Tickets results (right side)
        tickets_results_frame = ttk.Frame(tickets_frame)
        tickets_results_frame.grid(row=0, column=1, sticky='nsew')
        tickets_results_frame.grid_rowconfigure(0, weight=1)
        tickets_results_frame.grid_columnconfigure(0, weight=1)
        
        # Treeview
        self.dispatches_tree = ttk.Treeview(tickets_results_frame, show='headings', height=10)
        self.dispatches_tree.grid(row=0, column=0, sticky='nsew')
        
        # Configure treeview style
        style = ttk.Style()
        style.configure("Treeview", rowheight=20, font=('TkDefaultFont', 9))
        style.configure("Treeview.Heading", font=('TkDefaultFont', 9, 'bold'))
        
        dispatches_scrollbar_v = ttk.Scrollbar(tickets_results_frame, orient=tk.VERTICAL, command=self.dispatches_tree.yview)
        dispatches_scrollbar_h = ttk.Scrollbar(tickets_results_frame, orient=tk.HORIZONTAL, command=self.dispatches_tree.xview)
        dispatches_scrollbar_v.grid(row=0, column=1, sticky='ns')
        dispatches_scrollbar_h.grid(row=1, column=0, sticky='ew')
        self.dispatches_tree.configure(yscrollcommand=dispatches_scrollbar_v.set, xscrollcommand=dispatches_scrollbar_h.set)
        
        # RIGHT PANEL: Tickets Location Map
        tickets_map_frame = ttk.LabelFrame(main_container, text="Tickets Location Map", padding=5)
        tickets_map_frame.grid(row=0, column=1, sticky='nsew', padx=(3, 0))
        tickets_map_frame.grid_rowconfigure(0, weight=1, minsize=500)
        tickets_map_frame.grid_columnconfigure(0, weight=1, minsize=400)
        
        # Create tickets map widget
        self.tickets_map_widget = tkintermapview.TkinterMapView(tickets_map_frame, width=500, height=700, corner_radius=0)
        self.tickets_map_widget.grid(row=0, column=0, sticky='nsew', padx=5, pady=5)
        
        # Set tile server
        self.tickets_map_widget.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22)
        
        # Set default position (centered USA)
        self.tickets_map_widget.set_position(39.8283, -98.5795)
        self.tickets_map_widget.set_zoom(5)
        
        # Map info label (shows details when marker is clicked)
        self.tickets_map_info_label = ttk.Label(tickets_map_frame, text="Click on a marker to see ticket details", 
                                        font=('TkDefaultFont', 9), foreground='blue', 
                                        wraplength=450, justify=tk.LEFT, padding=5)
        self.tickets_map_info_label.grid(row=1, column=0, pady=2, sticky='ew')
        
        # Map status label
        self.tickets_map_status_label = ttk.Label(tickets_map_frame, text="Load tickets to display map", font=('TkDefaultFont', 8))
        self.tickets_map_status_label.grid(row=2, column=0, pady=2)
        
        # Status label
        self.tickets_status_label = ttk.Label(self.tickets_frame, text="Ready to load tickets")
        self.tickets_status_label.pack(pady=5)
    
    def create_smart_dispatch_tab(self):
        """Create Smart Dispatch query tab with table selection and search"""
        # Table definitions (dispatch_history moved to separate tab)
        self.smart_dispatch_tables = {
            'technician_calendar': 'hackathon.hackathon_the_original_packet.smart_dispatch_technician_calendar',
            'technicians': 'hackathon.hackathon_the_original_packet.smart_dispatch_technicians',
            'current_dispatches': 'hackathon.hackathon_the_original_packet.smartdispatchcurrentdispatches'
        }
        
        # Table for combined technicians view
        self.technicians_combined_table = {
            'technicians_combined': {
                'technicians': 'hackathon.hackathon_the_original_packet.smart_dispatch_technicians',
                'technician_calendar': 'hackathon.hackathon_the_original_packet.smart_dispatch_technician_calendar'
            }
        }
        
        # Initialize table_vars - all tables selected by default
        self.table_vars = {}
        # Add combined technicians view (selected by default)
        self.table_vars['technicians_combined'] = tk.BooleanVar(value=True)
        # Add individual tables (excluding dispatch_history and current_dispatches)
        for key, table_name in self.smart_dispatch_tables.items():
            if key != 'current_dispatches':  # Will be shown separately
                self.table_vars[key] = tk.BooleanVar(value=True)
        
        # Main container with responsive left and right panels
        main_container = ttk.Frame(self.smart_dispatch_frame)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        main_container.grid_rowconfigure(0, weight=1)
        
        # Responsive columns: Technician Details + Map
        main_container.grid_columnconfigure(0, weight=8, minsize=600)  # Technician Details: target 800px, min 600px
        main_container.grid_columnconfigure(1, weight=5, minsize=400)  # Map: target 500px, min 400px
        
        # Technician Details section
        tech_details_frame = ttk.LabelFrame(main_container, text="Technician Details", padding=5)
        tech_details_frame.grid(row=0, column=0, sticky='nsew', padx=(0, 3))
        tech_details_frame.grid_rowconfigure(0, weight=1)
        tech_details_frame.grid_columnconfigure(0, weight=0, minsize=150)  # Left: filters (fixed 150px)
        tech_details_frame.grid_columnconfigure(1, weight=1, minsize=400)  # Right: results (min 400px)
        
        # LEFT SIDE: Filters and buttons
        filters_subframe = ttk.Frame(tech_details_frame, width=150)  # Fixed width to match tickets
        filters_subframe.grid(row=0, column=0, sticky='ns', padx=(0, 5))
        filters_subframe.grid_propagate(False)  # Maintain fixed width
        
        # Date filter (default to today)
        today = datetime.now().strftime("%Y-%m-%d")
        ttk.Label(filters_subframe, text="Date:", font=('TkDefaultFont', 9)).grid(row=0, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_date_var = tk.StringVar(value=today)
        date_entry = ttk.Entry(filters_subframe, textvariable=self.filter_date_var, width=15)
        date_entry.grid(row=1, column=0, padx=3, pady=(0, 3), sticky='ew')
        ttk.Button(filters_subframe, text="Today", command=lambda: self.filter_date_var.set(today), width=15).grid(row=2, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Technician name filter
        ttk.Label(filters_subframe, text="Technician:", font=('TkDefaultFont', 9)).grid(row=3, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_technician_var = tk.StringVar()
        self.filter_technician_combo = ttk.Combobox(filters_subframe, textvariable=self.filter_technician_var, width=15, state='readonly')
        self.filter_technician_combo.grid(row=4, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # City/State filter
        ttk.Label(filters_subframe, text="City/State:", font=('TkDefaultFont', 9)).grid(row=5, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_location_var = tk.StringVar()
        self.filter_location_combo = ttk.Combobox(filters_subframe, textvariable=self.filter_location_var, width=15, state='readonly')
        self.filter_location_combo.grid(row=6, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Available filter
        ttk.Label(filters_subframe, text="Available:", font=('TkDefaultFont', 9)).grid(row=7, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_available_var = tk.StringVar()
        available_combo = ttk.Combobox(filters_subframe, textvariable=self.filter_available_var, width=15, state='readonly')
        available_combo['values'] = ('All', 'Available (1)', 'Not Available (0)')
        available_combo.current(0)
        available_combo.grid(row=8, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Reason filter
        ttk.Label(filters_subframe, text="Reason:", font=('TkDefaultFont', 9)).grid(row=9, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_reason_var = tk.StringVar()
        reason_combo = ttk.Combobox(filters_subframe, textvariable=self.filter_reason_var, width=15, state='readonly')
        reason_combo['values'] = ('Hide (default)', 'Show All', 'Show Non-Null Only')
        reason_combo.current(0)
        reason_combo.grid(row=10, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Show reasons checkbox
        self.show_reasons_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(filters_subframe, text="Show Reason Column", variable=self.show_reasons_var).grid(row=11, column=0, padx=3, pady=(0, 10), sticky='w')
        
        # Buttons frame
        button_frame = ttk.Frame(filters_subframe)
        button_frame.grid(row=12, column=0, pady=5, sticky='ew')
        
        ttk.Button(button_frame, text="Execute Queries", command=self.execute_smart_dispatch_queries).pack(fill=tk.X, padx=3, pady=2)
        ttk.Button(button_frame, text="Clear Results", command=self.clear_smart_dispatch_results).pack(fill=tk.X, padx=3, pady=2)
        ttk.Button(button_frame, text="Export Results", command=self.export_smart_dispatch_results).pack(fill=tk.X, padx=3, pady=2)
        
        # RIGHT SIDE: Technician results frame (table)
        self.details_results_frame = ttk.Frame(tech_details_frame)
        self.details_results_frame.grid(row=0, column=1, sticky='nsew')
        self.details_results_frame.grid_rowconfigure(0, weight=1)
        self.details_results_frame.grid_columnconfigure(0, weight=1)
        
        # RIGHT PANEL: Technicians Location Map (full height) - responsive sizing
        map_frame = ttk.LabelFrame(main_container, text="Technicians Location Map", padding=5)
        map_frame.grid(row=0, column=1, sticky='nsew', padx=(3, 0))
        map_frame.grid_rowconfigure(0, weight=1, minsize=500)  # Minimum height for mobile
        map_frame.grid_columnconfigure(0, weight=1, minsize=400)  # Minimum width for mobile
        
        # Create interactive map widget - responsive (target 500x700, adapts to screen)
        self.map_widget = tkintermapview.TkinterMapView(map_frame, width=500, height=700, corner_radius=0)
        self.map_widget.grid(row=0, column=0, sticky='nsew', padx=5, pady=5)
        
        # Set tile server for better visuals
        self.map_widget.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22)
        
        # Set default position (centered USA)
        self.map_widget.set_position(39.8283, -98.5795)
        self.map_widget.set_zoom(5)
        
        # Map info label (shows details when marker is clicked)
        self.map_info_label = ttk.Label(map_frame, text="Click on a marker to see technician details", 
                                        font=('TkDefaultFont', 9), foreground='blue', 
                                        wraplength=450, justify=tk.LEFT, padding=5)
        self.map_info_label.grid(row=1, column=0, pady=2, sticky='ew')
        
        # Map status label
        self.map_status_label = ttk.Label(map_frame, text="Execute queries to display technicians on map", font=('TkDefaultFont', 8))
        self.map_status_label.grid(row=2, column=0, pady=2)
        
        # Status label
        self.smart_dispatch_status_label = ttk.Label(self.smart_dispatch_frame, text="Ready to query Smart Dispatch tables")
        self.smart_dispatch_status_label.pack(pady=5)
        
        # Store results for each table
        self.smart_dispatch_results = {}
    
    def clear_smart_dispatch_results(self):
        """Clear all results"""
        # Clear details frame
        for widget in self.details_results_frame.winfo_children():
            widget.destroy()
        # Clear technicians map markers
        if hasattr(self, 'map_widget'):
            self.map_widget.delete_all_marker()
        self.map_status_label.config(text="Execute queries to display technicians on map")
        self.smart_dispatch_results = {}
        self.smart_dispatch_status_label.config(text="Results cleared")
    
    def tech_prev_page(self, display_func):
        """Navigate to the previous page of technician results"""
        if self.tech_current_page > 1:
            self.tech_current_page -= 1
            display_func()
    
    def tech_next_page(self, display_func):
        """Navigate to the next page of technician results"""
        if self.tech_current_page < self.tech_total_pages:
            self.tech_current_page += 1
            display_func()
    
    def execute_smart_dispatch_queries(self):
        """Execute queries for all tables (all selected by default)"""
        # Get all available tables (all are selected by default)
        selected_tables = list(self.table_vars.keys())
        
        query_type = self.query_type_var.get()
        search_term = self.search_term_var.get().strip()
        
        # Validate search term for search/exact queries
        if query_type in ["search", "exact"] and not search_term:
            messagebox.showwarning("Warning", "Please enter a search term for search/exact queries")
            return
        
        def execute():
            try:
                self.smart_dispatch_status_label.config(text="Executing queries...")
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                
                search_column = self.search_column_var.get().strip()
                limit = self.limit_var.get().strip() or "100"
                
                # Escape single quotes in search term to prevent SQL injection
                search_term_escaped = search_term.replace("'", "''")
                
                # Clear previous results
                self.clear_smart_dispatch_results()
                
                for table_key in selected_tables:
                    # Handle combined technicians view
                    if table_key == 'technicians_combined':
                        try:
                            # Build JOIN query for technicians and technician_calendar
                            tech_table = self.technicians_combined_table['technicians_combined']['technicians']
                            cal_table = self.technicians_combined_table['technicians_combined']['technician_calendar']
                            
                            # Get actual column names from schema
                            cursor.execute(f"DESCRIBE {tech_table}")
                            tech_columns_info = cursor.fetchall()
                            tech_columns = {col[0].lower(): col[0] for col in tech_columns_info}  # Map lowercase to actual
                            
                            cursor.execute(f"DESCRIBE {cal_table}")
                            cal_columns_info = cursor.fetchall()
                            cal_columns = {col[0].lower(): col[0] for col in cal_columns_info}  # Map lowercase to actual
                            
                            # Find actual column names (case-insensitive matching)
                            def find_column(col_dict, possible_names):
                                for name in possible_names:
                                    if name.lower() in col_dict:
                                        return col_dict[name.lower()]
                                return None
                            
                            tech_id_col = find_column(tech_columns, ['technician_id', 'Technician_id', 'Technician_ID'])
                            tech_name_col = find_column(tech_columns, ['technician_name', 'Technician_name', 'Name', 'name'])
                            # Search for skill column with many variations
                            skill_col = find_column(tech_columns, ['skill', 'Skill', 'skills', 'Skills', 'Skillset', 'skillset', 'Skill_set', 'skill_set', 'SkillSet'])
                            
                            # If not found with exact matches, search for any column containing "skill" (case-insensitive)
                            if not skill_col:
                                for col_name in tech_columns.values():
                                    if 'skill' in col_name.lower():
                                        skill_col = col_name
                                        break
                            
                            state_col = find_column(tech_columns, ['state', 'State', 'STATE'])
                            city_col = find_column(tech_columns, ['city', 'City', 'CITY'])
                            lat_col = find_column(tech_columns, ['latitude', 'Latitude', 'lat'])
                            lon_col = find_column(tech_columns, ['longitude', 'Longitude', 'lon', 'lng'])
                            
                            # Also check calendar table for skills if not found in technicians table
                            if not skill_col:
                                skill_col = find_column(cal_columns, ['skill', 'Skill', 'skills', 'Skills', 'Skillset', 'skillset', 'Skill_set', 'skill_set', 'SkillSet'])
                                # If still not found, search for any column containing "skill"
                                if not skill_col:
                                    for col_name in cal_columns.values():
                                        if 'skill' in col_name.lower():
                                            skill_col = col_name
                                            break
                            
                            cal_id_col = find_column(cal_columns, ['technician_id', 'Technician_id', 'Technician_ID'])
                            
                            # Determine which table the skill column is in (if found)
                            skill_table_prefix = None
                            if skill_col:
                                # Check if it's in technicians table
                                if any(skill_col.lower() == col.lower() for col in tech_columns.values()):
                                    skill_table_prefix = "t"
                                # Check if it's in calendar table
                                elif any(skill_col.lower() == col.lower() for col in cal_columns.values()):
                                    skill_table_prefix = "tc"
                            
                            # Find calendar time columns and available column
                            start_time_col = find_column(cal_columns, ['start_time', 'Start_time', 'Start_Time', 'startTime', 'StartTime'])
                            end_time_col = find_column(cal_columns, ['end_time', 'End_time', 'End_Time', 'endTime', 'EndTime'])
                            available_col = find_column(cal_columns, ['available', 'Available', 'AVAILABLE', 'is_available', 'Is_Available'])
                            reason_col = find_column(cal_columns, ['reason', 'Reason', 'REASON', 'reason_text', 'Reason_Text'])
                            
                            # Find date column for filtering
                            date_col = find_column(cal_columns, ['date', 'Date', 'DATE', 'work_date', 'Work_Date', 'calendar_date', 'Calendar_Date'])
                            
                            # Build SELECT clause - organized and simplified for clarity
                            select_parts = []
                            
                            # 0. AVAILABILITY: Dot indicator (will be shown as colored dot, not as column)
                            if available_col:
                                select_parts.append(f"tc.{available_col} AS Available")
                            
                            # 1. DATE: Calendar date (2nd column after Status)
                            if date_col:
                                select_parts.append(f"tc.{date_col} AS Date")
                            
                            # 2. MAX_ASSIGNMENT: Maximum assignments (3rd column)
                            max_assignment_col = find_column(cal_columns, ['max_assignment', 'max_assignments', 'maxassignment'])
                            if max_assignment_col:
                                select_parts.append(f"tc.{max_assignment_col} AS Max_Assignment")
                            
                            # 3. WHO: Technician Name
                            if tech_name_col:
                                select_parts.append(f"t.{tech_name_col} AS Technician_Name")
                            
                            # 4. SKILL: What skill they have
                            if skill_col and skill_table_prefix:
                                select_parts.append(f"{skill_table_prefix}.{skill_col} AS Skill")
                            
                            # 5. WHERE: Location (Combined City/State)
                            if city_col and state_col:
                                select_parts.append(f"CONCAT(t.{city_col}, ', ', t.{state_col}) AS Location")
                            elif city_col:
                                select_parts.append(f"t.{city_col} AS Location")
                            elif state_col:
                                select_parts.append(f"t.{state_col} AS Location")
                            
                            # 6. CALENDAR: Days and Hours (Start Time, End Time)
                            if start_time_col:
                                select_parts.append(f"tc.{start_time_col} AS Start_Time")
                            if end_time_col:
                                select_parts.append(f"tc.{end_time_col} AS End_Time")
                            
                            # 8. REASON: Only include if show_reasons is checked
                            if reason_col and self.show_reasons_var.get():
                                select_parts.append(f"tc.{reason_col} AS Reason")
                            
                            # 9. OTHER CALENDAR FIELDS: Add other relevant calendar fields (excluding already added ones)
                            for cal_col_name in cal_columns.values():
                                # Skip already added columns
                                skip = False
                                if cal_id_col and cal_col_name.lower() == cal_id_col.lower():
                                    skip = True
                                if start_time_col and cal_col_name.lower() == start_time_col.lower():
                                    skip = True
                                if end_time_col and cal_col_name.lower() == end_time_col.lower():
                                    skip = True
                                if available_col and cal_col_name.lower() == available_col.lower():
                                    skip = True
                                if date_col and cal_col_name.lower() == date_col.lower():
                                    skip = True
                                if reason_col and cal_col_name.lower() == reason_col.lower():
                                    skip = True
                                if max_assignment_col and cal_col_name.lower() == max_assignment_col.lower():
                                    skip = True
                                # Skip day_of_week column
                                if 'day_of_week' in cal_col_name.lower():
                                    skip = True
                                
                                if not skip:
                                    select_parts.append(f"tc.{cal_col_name}")
                            
                            # If no columns found at all, fallback to select all
                            if not select_parts:
                                select_parts = ["t.*", "tc.*"]
                            
                            select_clause = ",\n                                    ".join(select_parts)
                            
                            # Build JOIN condition
                            if tech_id_col and cal_id_col:
                                join_condition = f"t.{tech_id_col} = tc.{cal_id_col}"
                            else:
                                # Try to find any matching ID column
                                join_condition = "1=1"  # Fallback to cross join if no ID found
                            
                            # Build WHERE clause for filters
                            where_conditions = []
                            
                            # Date filter (default to today)
                            filter_date = self.filter_date_var.get().strip()
                            if filter_date and date_col:
                                where_conditions.append(f"CAST(tc.{date_col} AS DATE) = CAST('{filter_date}' AS DATE)")
                            
                            # Technician name filter
                            filter_tech = self.filter_technician_var.get().strip()
                            if filter_tech and filter_tech != 'All' and tech_name_col:
                                filter_tech_escaped = filter_tech.replace("'", "''")
                                where_conditions.append(f"t.{tech_name_col} = '{filter_tech_escaped}'")
                            
                            # Location filter (city/state)
                            filter_loc = self.filter_location_var.get().strip()
                            if filter_loc and filter_loc != 'All':
                                filter_loc_escaped = filter_loc.replace("'", "''")
                                if city_col and state_col:
                                    where_conditions.append(f"(t.{city_col} LIKE '%{filter_loc_escaped}%' OR t.{state_col} LIKE '%{filter_loc_escaped}%')")
                                elif city_col:
                                    where_conditions.append(f"t.{city_col} LIKE '%{filter_loc_escaped}%'")
                                elif state_col:
                                    where_conditions.append(f"t.{state_col} LIKE '%{filter_loc_escaped}%'")
                            
                            # Available filter
                            filter_avail = self.filter_available_var.get()
                            if filter_avail and available_col:
                                if filter_avail == 'Available (1)':
                                    where_conditions.append(f"tc.{available_col} = 1")
                                elif filter_avail == 'Not Available (0)':
                                    where_conditions.append(f"tc.{available_col} = 0")
                            
                            # Reason filter (only show non-null if selected)
                            filter_reason = self.filter_reason_var.get()
                            if filter_reason == 'Show Non-Null Only' and reason_col:
                                where_conditions.append(f"tc.{reason_col} IS NOT NULL")
                            
                            where_clause = " AND ".join(where_conditions) if where_conditions else "1=1"
                            
                            # Build query with specific fields
                            if query_type == "schema":
                                # Show schema for both tables
                                query = f"DESCRIBE {tech_table}"
                            elif query_type == "all":
                                query = f"""
                                SELECT 
                                    {select_clause}
                                FROM {tech_table} t
                                LEFT JOIN {cal_table} tc ON {join_condition}
                                WHERE {where_clause}
                                LIMIT {limit}
                                """
                            elif query_type == "exact":
                                if search_column:
                                    query = f"""
                                    SELECT 
                                        {select_clause}
                                    FROM {tech_table} t
                                    LEFT JOIN {cal_table} tc ON {join_condition}
                                    WHERE {search_column} = '{search_term_escaped}' AND {where_clause}
                                    LIMIT {limit}
                                    """
                                else:
                                    # Build search conditions for available text columns from both tables
                                    search_conditions = []
                                    # Technician table columns
                                    if tech_name_col:
                                        search_conditions.append(f"CAST(t.{tech_name_col} AS STRING) = '{search_term_escaped}'")
                                    if skill_col and skill_table_prefix == "t":
                                        search_conditions.append(f"CAST(t.{skill_col} AS STRING) = '{search_term_escaped}'")
                                    if state_col:
                                        search_conditions.append(f"CAST(t.{state_col} AS STRING) = '{search_term_escaped}'")
                                    if city_col:
                                        search_conditions.append(f"CAST(t.{city_col} AS STRING) = '{search_term_escaped}'")
                                    # Calendar table columns (search in all text columns)
                                    for cal_col_name in cal_columns.values():
                                        if cal_id_col and cal_col_name.lower() != cal_id_col.lower():
                                            search_conditions.append(f"CAST(tc.{cal_col_name} AS STRING) = '{search_term_escaped}'")
                                    
                                    where_clause = " OR ".join(search_conditions) if search_conditions else "1=1"
                                    
                                    query = f"""
                                    SELECT 
                                        {select_clause}
                                    FROM {tech_table} t
                                    LEFT JOIN {cal_table} tc ON {join_condition}
                                    WHERE {where_clause}
                                    LIMIT {limit}
                                    """
                            else:  # search (LIKE)
                                if search_column:
                                    query = f"""
                                    SELECT 
                                        {select_clause}
                                    FROM {tech_table} t
                                    LEFT JOIN {cal_table} tc ON {join_condition}
                                    WHERE {search_column} LIKE '%{search_term_escaped}%' AND {where_clause}
                                    LIMIT {limit}
                                    """
                                else:
                                    # Build search conditions for available text columns from both tables
                                    search_conditions = []
                                    # Technician table columns
                                    if tech_name_col:
                                        search_conditions.append(f"CAST(t.{tech_name_col} AS STRING) LIKE '%{search_term_escaped}%'")
                                    if skill_col and skill_table_prefix == "t":
                                        search_conditions.append(f"CAST(t.{skill_col} AS STRING) LIKE '%{search_term_escaped}%'")
                                    if state_col:
                                        search_conditions.append(f"CAST(t.{state_col} AS STRING) LIKE '%{search_term_escaped}%'")
                                    if city_col:
                                        search_conditions.append(f"CAST(t.{city_col} AS STRING) LIKE '%{search_term_escaped}%'")
                                    # Calendar table columns (search in all text columns)
                                    for cal_col_name in cal_columns.values():
                                        if cal_id_col and cal_col_name.lower() != cal_id_col.lower():
                                            search_conditions.append(f"CAST(tc.{cal_col_name} AS STRING) LIKE '%{search_term_escaped}%'")
                                    
                                    search_where = " OR ".join(search_conditions) if search_conditions else "1=1"
                                    
                                    query = f"""
                                    SELECT 
                                        {select_clause}
                                    FROM {tech_table} t
                                    LEFT JOIN {cal_table} tc ON {join_condition}
                                    WHERE ({search_where}) AND {where_clause}
                                    LIMIT {limit}
                                    """
                            
                            cursor.execute(query)
                            columns = [desc[0] for desc in cursor.description] if cursor.description else []
                            
                            # Clear previous details
                            for widget in self.details_results_frame.winfo_children():
                                widget.destroy()
                            
                            # Create treeview for results directly in details frame
                            results_frame = ttk.Frame(self.details_results_frame)
                            results_frame.pack(fill=tk.BOTH, expand=True)
                            results_frame.grid_rowconfigure(0, weight=1)
                            results_frame.grid_columnconfigure(0, weight=1)
                            
                            # Find Available column index for dot display
                            available_col_index = None
                            display_columns = []
                            other_columns = []
                            
                            for i, col in enumerate(columns):
                                if col.lower() == 'available':
                                    available_col_index = i
                                    # Will add "Status" as first column
                                else:
                                    other_columns.append(col)
                            
                            # Put Status (dot) as first column, then other columns
                            if available_col_index is not None:
                                display_columns.append("Status")
                            display_columns.extend(other_columns)
                            
                            tree = ttk.Treeview(results_frame, columns=display_columns, show='headings')
                            
                            # Configure columns with sorting
                            sort_states = {}  # Track sort direction for each column
                            
                            def sort_column(col_name, reverse=False):
                                """Sort treeview by column"""
                                # Get all items
                                items = [(tree.set(item, col_name), item) for item in tree.get_children('')]
                                
                                # Try to sort as numbers if possible
                                try:
                                    items.sort(key=lambda t: float(t[0]) if t[0] else 0, reverse=reverse)
                                except (ValueError, TypeError):
                                    items.sort(key=lambda t: str(t[0]).lower() if t[0] else '', reverse=reverse)
                                
                                # Rearrange items
                                for index, (val, item) in enumerate(items):
                                    tree.move(item, '', index)
                                
                                # Update heading to show sort direction
                                sort_states[col_name] = not reverse
                                direction = " ↓" if reverse else " ↑"
                                tree.heading(col_name, text=col_name + direction, command=lambda c=col_name: sort_column(c, sort_states.get(c, False)))
                            
                            # Configure headings with sorting
                            for i, col in enumerate(display_columns):
                                tree.heading(col, text=col, command=lambda c=col: sort_column(c, sort_states.get(c, False)))
                                # Status column is narrower and centered for the colored dot
                                if col == "Status":
                                    tree.column(col, width=60, anchor=tk.CENTER)
                                # Center Date and Max_Assignment columns
                                elif col in ["Date", "Max_Assignment"]:
                                    tree.column(col, width=150, anchor=tk.CENTER)
                                else:
                                    tree.column(col, width=150, anchor=tk.W)
                            
                            # Configure tags for colored dots (Status column)
                            tree.tag_configure('available', foreground='#00AA00')  # Green for available (1)
                            tree.tag_configure('unavailable', foreground='#FF0000')  # Red for unavailable (0)
                            
                            # Scrollbars
                            v_scrollbar = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=tree.yview)
                            h_scrollbar = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL, command=tree.xview)
                            tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
                            
                            # Pack widgets
                            tree.grid(row=0, column=0, sticky='nsew')
                            v_scrollbar.grid(row=0, column=1, sticky='ns')
                            h_scrollbar.grid(row=1, column=0, sticky='ew')
                            results_frame.grid_rowconfigure(0, weight=1)
                            results_frame.grid_columnconfigure(0, weight=1)
                            
                            # Fetch all results
                            rows = cursor.fetchall()
                            
                            # Pagination setup
                            self.tech_current_page = 1
                            self.tech_items_per_page = 15
                            self.tech_total_items = len(rows)
                            self.tech_total_pages = (self.tech_total_items + self.tech_items_per_page - 1) // self.tech_items_per_page
                            self.tech_all_rows = rows  # Store all rows
                            self.tech_tree = tree  # Store tree reference
                            self.tech_available_col_index = available_col_index
                            self.tech_columns = columns
                            self.tech_display_columns = display_columns
                            
                            # Collect unique values for dropdowns
                            unique_technicians = set()
                            unique_locations = set()
                            
                            # Collect unique values from ALL rows (not just current page)
                            for row in rows:
                                # Collect unique values for dropdowns (use original row indices)
                                if tech_name_col:
                                    tech_idx = columns.index('Technician_Name') if 'Technician_Name' in columns else None
                                    if tech_idx is not None and row[tech_idx]:
                                        unique_technicians.add(str(row[tech_idx]))
                                
                                # Note: City and State are now combined as Location
                                loc_idx = columns.index('Location') if 'Location' in columns else None
                                if loc_idx is not None and row[loc_idx]:
                                    unique_locations.add(str(row[loc_idx]))
                            
                            # Function to display current page
                            def display_tech_page():
                                """Display the current page of technician results"""
                                # Clear tree
                                for item in tree.get_children():
                                    tree.delete(item)
                                
                                # Calculate start and end indices for current page
                                start_idx = (self.tech_current_page - 1) * self.tech_items_per_page
                                end_idx = min(start_idx + self.tech_items_per_page, self.tech_total_items)
                                
                                # Display rows for current page
                                for row in self.tech_all_rows[start_idx:end_idx]:
                                    # Prepare display row (replace Available with dot)
                                    display_row = list(row)
                                    
                                    if self.tech_available_col_index is not None:
                                        avail_value = display_row[self.tech_available_col_index]
                                        # Use bullet with colored tag
                                        dot_value = "●"  # Bullet character
                                        if avail_value == 1 or str(avail_value).lower() == 'true':
                                            tag = 'available'  # Green
                                        else:
                                            tag = 'unavailable'  # Red
                                        
                                        # Reorder: dot first, then other columns
                                        new_display_row = [dot_value]
                                        for i, val in enumerate(display_row):
                                            if i != self.tech_available_col_index:
                                                new_display_row.append(val)
                                        display_row = new_display_row
                                    else:
                                        tag = ''
                                    
                                    tree.insert('', tk.END, values=display_row, tags=(tag,))
                                
                                # Update pagination label
                                if hasattr(self, 'tech_pagination_label'):
                                    self.tech_pagination_label.config(text=f"Page {self.tech_current_page} of {self.tech_total_pages} ({self.tech_total_items} items)")
                                
                                # Update button states
                                if hasattr(self, 'tech_prev_button'):
                                    self.tech_prev_button['state'] = 'normal' if self.tech_current_page > 1 else 'disabled'
                                if hasattr(self, 'tech_next_button'):
                                    self.tech_next_button['state'] = 'normal' if self.tech_current_page < self.tech_total_pages else 'disabled'
                            
                            # Pagination controls
                            pagination_frame = ttk.Frame(results_frame)
                            pagination_frame.grid(row=2, column=0, columnspan=2, sticky='ew', pady=5)
                            
                            self.tech_prev_button = ttk.Button(pagination_frame, text="◄ Previous", command=lambda: self.tech_prev_page(display_tech_page))
                            self.tech_prev_button.pack(side=tk.LEFT, padx=5)
                            
                            self.tech_pagination_label = ttk.Label(pagination_frame, text=f"Page 1 of {self.tech_total_pages} ({self.tech_total_items} items)")
                            self.tech_pagination_label.pack(side=tk.LEFT, padx=10)
                            
                            self.tech_next_button = ttk.Button(pagination_frame, text="Next ►", command=lambda: self.tech_next_page(display_tech_page))
                            self.tech_next_button.pack(side=tk.LEFT, padx=5)
                            
                            # Display first page
                            display_tech_page()
                            
                            # Update dropdowns with unique values
                            if unique_technicians:
                                self.filter_technician_combo['values'] = ['All'] + sorted(unique_technicians)
                                self.filter_technician_combo.current(0)
                            if unique_locations:
                                self.filter_location_combo['values'] = ['All'] + sorted(unique_locations)
                                self.filter_location_combo.current(0)
                            
                            # Store results with lat/lon data for map
                            lat_idx = columns.index('Latitude') if 'Latitude' in columns else None
                            lon_idx = columns.index('Longitude') if 'Longitude' in columns else None
                            tech_name_idx = columns.index('Technician_Name') if 'Technician_Name' in columns else None
                            
                            # Find display column indices (after Status column was added)
                            display_lat_idx = None
                            display_lon_idx = None
                            display_tech_name_idx = None
                            for i, col in enumerate(display_columns):
                                if col == 'Latitude':
                                    display_lat_idx = i
                                elif col == 'Longitude':
                                    display_lon_idx = i
                                elif col == 'Technician_Name':
                                    display_tech_name_idx = i
                            
                            self.smart_dispatch_results[table_key] = {
                                'columns': columns,
                                'rows': rows,
                                'tree': tree,
                                'lat_idx': lat_idx,
                                'lon_idx': lon_idx,
                                'name_idx': tech_name_idx,
                                'display_lat_idx': display_lat_idx,
                                'display_lon_idx': display_lon_idx,
                                'display_tech_name_idx': display_tech_name_idx
                            }
                            
                            # Add click binding to zoom map when technician is selected
                            def on_technician_click(event):
                                selection = tree.selection()
                                if selection:
                                    item = tree.item(selection[0])
                                    values = item['values']
                                    tags = item['tags']
                                    
                                    # Check if technician is available by checking the row tag
                                    # Tag 'available' = green dot (available=1)
                                    # Tag 'unavailable' = red dot (available=0)
                                    if 'unavailable' in tags:
                                        # Don't zoom to unavailable technicians (red status)
                                        self.map_status_label.config(text="Cannot zoom to unavailable technician (red status)")
                                        print(f"Skipping zoom: Technician has red status (unavailable)")
                                        return
                                    
                                    if display_lat_idx is not None and display_lon_idx is not None:
                                        try:
                                            lat = float(values[display_lat_idx])
                                            lon = float(values[display_lon_idx])
                                            tech_name = values[display_tech_name_idx] if display_tech_name_idx is not None else "Selected Technician"
                                            # Only zoom if technician is available (has green status - 'available' tag)
                                            self.zoom_map_to_location(lat, lon, tech_name)
                                        except (ValueError, IndexError, TypeError):
                                            pass
                            
                            tree.bind('<<TreeviewSelect>>', on_technician_click)
                            
                            # Update map after loading technicians (schedule on main thread)
                            self.root.after(100, self.update_map)
                            
                            self.smart_dispatch_status_label.config(text=f"Loaded {len(rows)} technicians")
                            
                        except Exception as e:
                            messagebox.showerror("Error", f"Error querying technicians:\n{str(e)}")
                            self.smart_dispatch_status_label.config(text=f"Error: {str(e)}")
                        continue
                    
                    # Skip other tables - only show combined technicians
                    if table_key in ['current_dispatches', 'technicians', 'technician_calendar']:
                        continue
                    
                    # Handle any other tables (if added in future)
                    table_name = self.smart_dispatch_tables[table_key]
                    
                    # Build query based on type
                    if query_type == "schema":
                        query = f"DESCRIBE {table_name}"
                    elif query_type == "all":
                        query = f"SELECT * FROM {table_name} LIMIT {limit}"
                    elif query_type == "exact":
                        if search_column:
                            query = f"SELECT * FROM {table_name} WHERE {search_column} = '{search_term_escaped}' LIMIT {limit}"
                        else:
                            # Get all columns and search in each for exact match
                            cursor.execute(f"DESCRIBE {table_name}")
                            columns_info = cursor.fetchall()
                            column_names = [col[0] for col in columns_info]
                            
                            # Build OR conditions for all columns
                            conditions = " OR ".join([f"CAST({col} AS STRING) = '{search_term_escaped}'" for col in column_names])
                            query = f"SELECT * FROM {table_name} WHERE {conditions} LIMIT {limit}"
                    else:  # search (LIKE)
                        if search_column:
                            query = f"SELECT * FROM {table_name} WHERE {search_column} LIKE '%{search_term_escaped}%' LIMIT {limit}"
                        else:
                            # Get all columns and search in each
                            # First, get column names
                            cursor.execute(f"DESCRIBE {table_name}")
                            columns_info = cursor.fetchall()
                            column_names = [col[0] for col in columns_info]
                            
                            # Build OR conditions for all columns
                            conditions = " OR ".join([f"CAST({col} AS STRING) LIKE '%{search_term_escaped}%'" for col in column_names])
                            query = f"SELECT * FROM {table_name} WHERE {conditions} LIMIT {limit}"
                    
                    try:
                        cursor.execute(query)
                        
                        # Get column names
                        columns = [desc[0] for desc in cursor.description] if cursor.description else []
                        
                        # Create tab for this table
                        tab_frame = ttk.Frame(self.smart_dispatch_notebook)
                        self.smart_dispatch_notebook.add(tab_frame, text=table_key)
                        
                        # Create treeview for results
                        results_frame = ttk.Frame(tab_frame)
                        results_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
                        
                        tree = ttk.Treeview(results_frame, columns=columns, show='headings')
                        for col in columns:
                            tree.heading(col, text=col)
                            tree.column(col, width=150, anchor=tk.W)
                        
                        # Scrollbars
                        v_scrollbar = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=tree.yview)
                        h_scrollbar = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL, command=tree.xview)
                        tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
                        
                        # Pack widgets
                        tree.grid(row=0, column=0, sticky='nsew')
                        v_scrollbar.grid(row=0, column=1, sticky='ns')
                        h_scrollbar.grid(row=1, column=0, sticky='ew')
                        results_frame.grid_rowconfigure(0, weight=1)
                        results_frame.grid_columnconfigure(0, weight=1)
                        
                        # Fetch and display results
                        rows = cursor.fetchall()
                        for row in rows:
                            tree.insert('', tk.END, values=row)
                        
                        # Store results
                        self.smart_dispatch_results[table_key] = {
                            'columns': columns,
                            'rows': rows,
                            'tree': tree
                        }
                        
                        # Add status label
                        status_label = ttk.Label(tab_frame, text=f"Found {len(rows)} rows")
                        status_label.pack(pady=5)
                        
                    except Exception as e:
                        # Create error tab
                        error_frame = ttk.Frame(self.smart_dispatch_notebook)
                        self.smart_dispatch_notebook.add(error_frame, text=f"{table_key} (Error)")
                        error_text = scrolledtext.ScrolledText(error_frame, wrap=tk.WORD)
                        error_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
                        error_text.insert(tk.END, f"Error querying {table_name}:\n\n{str(e)}\n\nQuery:\n{query}")
                        error_text.config(state=tk.DISABLED)
                
                cursor.close()
                connection.close()
                self.smart_dispatch_status_label.config(text=f"Queries completed for {len(selected_tables)} table(s)")
                
            except Exception as e:
                self.smart_dispatch_status_label.config(text=f"Error: {str(e)}")
                messagebox.showerror("Query Error", f"Query execution failed:\n{str(e)}")
        
        threading.Thread(target=execute, daemon=True).start()
    
    def clear_ticket_filters(self):
        """Clear all ticket filters"""
        self.ticket_type_var.set('All')
        self.ticket_priority_var.set('All')
        self.ticket_skill_var.set('All')
        self.ticket_appointment_var.set('All')
        # Reset dates to today
        today_start = datetime.now().strftime("%Y-%m-%d 00:00:00")
        today_end = datetime.now().strftime("%Y-%m-%d 23:59:59")
        self.ticket_start_date_entry.delete(0, tk.END)
        self.ticket_start_date_entry.insert(0, today_start)
        self.ticket_end_date_entry.delete(0, tk.END)
        self.ticket_end_date_entry.insert(0, today_end)
        self.load_dispatches()
    
    def load_dispatches(self):
        """Load current tickets into the Tickets section with filters"""
        def load():
            try:
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                
                table_name = self.smart_dispatch_tables['current_dispatches']
                
                # Build WHERE clause based on filters
                where_clauses = []
                
                # Get filter values
                ticket_type = self.ticket_type_var.get() if hasattr(self, 'ticket_type_var') else 'All'
                priority = self.ticket_priority_var.get() if hasattr(self, 'ticket_priority_var') else 'All'
                skill = self.ticket_skill_var.get() if hasattr(self, 'ticket_skill_var') else 'All'
                appointment = self.ticket_appointment_var.get() if hasattr(self, 'ticket_appointment_var') else 'All'
                start_date = self.ticket_start_date_var.get() if hasattr(self, 'ticket_start_date_var') else ''
                end_date = self.ticket_end_date_var.get() if hasattr(self, 'ticket_end_date_var') else ''
                
                # Strip whitespace from dates
                start_date = start_date.strip() if start_date else ''
                end_date = end_date.strip() if end_date else ''
                
                print(f"DEBUG Filter: Applying filters - Type: '{ticket_type}', Priority: '{priority}', Skill: '{skill}', Appointment: '{appointment}', Start: '{start_date}', End: '{end_date}'")
                
                # Add WHERE clauses using stored actual column names (will be set after first load)
                if ticket_type != 'All' and hasattr(self, 'ticket_type_column_name'):
                    where_clauses.append(f"{self.ticket_type_column_name} = '{ticket_type}'")
                    print(f"DEBUG Filter: Added WHERE clause: {self.ticket_type_column_name} = '{ticket_type}'")
                if priority != 'All' and hasattr(self, 'priority_column_name'):
                    where_clauses.append(f"{self.priority_column_name} = '{priority}'")
                    print(f"DEBUG Filter: Added WHERE clause: {self.priority_column_name} = '{priority}'")
                if skill != 'All' and hasattr(self, 'skill_column_name'):
                    where_clauses.append(f"{self.skill_column_name} = '{skill}'")
                    print(f"DEBUG Filter: Added WHERE clause: {self.skill_column_name} = '{skill}'")
                if appointment != 'All' and hasattr(self, 'appointment_column_name'):
                    where_clauses.append(f"{self.appointment_column_name} = '{appointment}'")
                    print(f"DEBUG Filter: Added WHERE clause: {self.appointment_column_name} = '{appointment}'")
                
                # Add date range filters if provided
                # First, we need to identify the date column - try common date column names
                # We'll store the date column name after first query execution
                if start_date and hasattr(self, 'ticket_date_column_name'):
                    where_clauses.append(f"{self.ticket_date_column_name} >= '{start_date}'")
                    print(f"DEBUG Filter: Added WHERE clause: {self.ticket_date_column_name} >= '{start_date}'")
                if end_date and hasattr(self, 'ticket_date_column_name'):
                    where_clauses.append(f"{self.ticket_date_column_name} <= '{end_date}'")
                    print(f"DEBUG Filter: Added WHERE clause: {self.ticket_date_column_name} <= '{end_date}'")
                
                # Build complete query
                if where_clauses:
                    query = f"SELECT * FROM {table_name} WHERE {' AND '.join(where_clauses)}"
                else:
                    query = f"SELECT * FROM {table_name}"
                
                print(f"DEBUG Filter: Executing query: {query}")
                cursor.execute(query)
                
                # Get column names
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                
                # Load technician ID to name mapping
                technician_name_map = {}
                try:
                    tech_table = self.smart_dispatch_tables.get('technicians', '')
                    if tech_table:
                        tech_query = f"SELECT Technician_id, Technician_name FROM {tech_table}"
                        cursor.execute(tech_query)
                        tech_results = cursor.fetchall()
                        for tech_row in tech_results:
                            if tech_row[0] is not None:  # Technician_id
                                technician_name_map[str(tech_row[0])] = tech_row[1] if tech_row[1] else f"Tech {tech_row[0]}"
                        print(f"DEBUG: Loaded {len(technician_name_map)} technician names")
                except Exception as e:
                    print(f"DEBUG: Could not load technician names: {e}")
                    technician_name_map = {}
                
                # Re-execute the tickets query to get fresh cursor
                cursor.execute(query)
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                
                # Clear previous results
                for item in self.dispatches_tree.get_children():
                    self.dispatches_tree.delete(item)
                
                # Find address column indices (case-insensitive)
                street_idx = None
                city_idx = None
                county_idx = None
                state_idx = None
                postal_idx = None
                priority_idx = None
                lat_idx = None
                lon_idx = None
                assigned_tech_idx = None
                
                # Columns to exclude from display
                excluded_columns = []
                
                for i, col in enumerate(columns):
                    col_lower = col.lower()
                    if 'street' in col_lower:
                        street_idx = i
                    elif 'city' in col_lower:
                        city_idx = i
                    elif 'county' in col_lower:
                        county_idx = i
                    elif 'state' in col_lower:
                        state_idx = i
                    elif 'postal' in col_lower or 'zip' in col_lower:
                        postal_idx = i
                    elif 'priority' in col_lower:  # More flexible matching - catches Priority, priority_level, ticket_priority, etc.
                        priority_idx = i
                        self.priority_column_name = col  # Store actual column name for WHERE clause
                        excluded_columns.append(i)  # Exclude priority text column
                        print(f"DEBUG: Found Priority column at index {i}, column name: '{col}'")
                    # Mark columns to exclude
                    elif col_lower == 'dispatch_id':
                        excluded_columns.append(i)
                    # Find lat/lon columns for map
                    elif 'latitude' in col_lower:
                        lat_idx = i
                    elif 'longitude' in col_lower:
                        lon_idx = i
                    # Find assigned technician column
                    elif 'assigned' in col_lower and 'technician' in col_lower:
                        assigned_tech_idx = i
                        print(f"DEBUG: Found assigned_technician column at index {i}, column name: '{col}'")
                    # Find date/time column for filtering
                    elif ('date' in col_lower or 'time' in col_lower or 'created' in col_lower or 'updated' in col_lower) and not hasattr(self, 'ticket_date_column_name'):
                        # Store the first date-related column found
                        self.ticket_date_column_name = col
                        print(f"DEBUG: Found date/time column at index {i}, column name: '{col}' - will use for date filtering")
                    # Note: customer_latitude and customer_longitude are kept for map zoom functionality
                
                # Debug: Show all columns found
                print(f"DEBUG: All columns: {columns}")
                print(f"DEBUG: Priority index: {priority_idx}")
                
                if priority_idx is None:
                    print(f"⚠️ WARNING: Priority column not found! Row colors will not be applied based on priority.")
                    print(f"   Available columns: {', '.join(columns)}")
                
                # Create new column list with combined address and excluded columns removed
                address_indices = {street_idx, city_idx, county_idx, state_idx, postal_idx}
                address_indices.discard(None)  # Remove None values
                
                new_columns = []
                address_position = None
                
                for i, col in enumerate(columns):
                    if i in address_indices:
                        if address_position is None:
                            # First address column found, replace with "Address"
                            new_columns.append('Address')
                            address_position = len(new_columns) - 1
                        # Skip other address columns
                    elif i in excluded_columns:
                        # Skip excluded columns (including Priority)
                        pass
                    else:
                        new_columns.append(col)
                
                # Configure treeview columns with new combined columns
                self.dispatches_tree['columns'] = new_columns
                for col in new_columns:
                    self.dispatches_tree.heading(col, text=col)
                    if col == 'Address':
                        self.dispatches_tree.column(col, width=300, anchor=tk.W)
                    elif 'latitude' in col.lower() or 'longitude' in col.lower():
                        # Hide lat/lon columns but keep them in data for map zoom
                        self.dispatches_tree.column(col, width=0, stretch=False)
                    else:
                        self.dispatches_tree.column(col, width=150, anchor=tk.W)
                
                # Configure row colors based on priority (similar to technician availability)
                style = ttk.Style()
                self.dispatches_tree.tag_configure('critical', background='#ffcccc')  # Light red for critical/high
                self.dispatches_tree.tag_configure('normal', background='#ccffcc')    # Light green for normal/medium
                self.dispatches_tree.tag_configure('low', background='white')         # White for low priority
                
                # Fetch and display results with combined address and priority status
                rows = cursor.fetchall()
                
                # Clear previous ticket data for map
                self.ticket_data = {}
                
                # Debug: Check unique priority values
                if priority_idx is not None and rows:
                    unique_priorities = set(str(row[priority_idx]) for row in rows if row[priority_idx])
                    print(f"DEBUG: Found {len(rows)} tickets with priority values: {unique_priorities}")
                
                for row_idx, row in enumerate(rows):
                    # Determine row tag based on priority value (for row background color)
                    row_tag = 'low'  # Default tag
                    
                    if priority_idx is not None:
                        priority_value = str(row[priority_idx]).lower() if row[priority_idx] else ''
                        print(f"DEBUG: Processing priority value: '{priority_value}'")  # Debug output
                        if 'critical' in priority_value or 'high' in priority_value:
                            row_tag = 'critical'  # Red background for critical/high priority
                            print(f"  -> Set CRITICAL tag (red background)")
                        elif 'normal' in priority_value or 'medium' in priority_value:
                            row_tag = 'normal'  # Green background for normal/medium priority
                            print(f"  -> Set NORMAL tag (green background)")
                        else:
                            row_tag = 'low'  # White background for low priority
                            print(f"  -> Set LOW tag (white background)")
                    
                    # Create new row with data (no status dot column)
                    new_row = []
                    address_added = False
                    
                    for i, value in enumerate(row):
                        if i in address_indices:
                            if not address_added:
                                # Build combined address
                                address_parts = []
                                if street_idx is not None and row[street_idx]:
                                    address_parts.append(str(row[street_idx]))
                                if city_idx is not None and row[city_idx]:
                                    address_parts.append(str(row[city_idx]))
                                if county_idx is not None and row[county_idx]:
                                    address_parts.append(str(row[county_idx]))
                                if state_idx is not None and row[state_idx]:
                                    address_parts.append(str(row[state_idx]))
                                if postal_idx is not None and row[postal_idx]:
                                    address_parts.append(str(row[postal_idx]))
                                
                                combined_address = ', '.join(address_parts) if address_parts else ''
                                new_row.append(combined_address)
                                address_added = True
                            # Skip other address columns
                        elif i in excluded_columns:
                            # Skip excluded columns
                            pass
                        elif i == assigned_tech_idx and assigned_tech_idx is not None:
                            # Replace technician ID with name
                            tech_id = str(value) if value is not None else None
                            if tech_id and tech_id in technician_name_map:
                                tech_name = technician_name_map[tech_id]
                                new_row.append(tech_name)
                                print(f"DEBUG: Mapped technician ID '{tech_id}' to name '{tech_name}'")
                            else:
                                new_row.append(value)  # Keep original if no mapping found
                                if tech_id:
                                    print(f"DEBUG: No mapping found for technician ID '{tech_id}'")
                        else:
                            new_row.append(value)
                    
                    # Insert row with priority tag for background color
                    self.dispatches_tree.insert('', tk.END, values=new_row, tags=(row_tag,))
                    
                    # Store ticket data for map (if lat/lon/state are available)
                    if lat_idx is not None and lon_idx is not None and row[lat_idx] and row[lon_idx]:
                        try:
                            ticket_lat = float(row[lat_idx])
                            ticket_lon = float(row[lon_idx])
                            ticket_state = str(row[state_idx]) if state_idx is not None and row[state_idx] else None
                            
                            self.ticket_data[row_idx] = {
                                'latitude': ticket_lat,
                                'longitude': ticket_lon,
                                'state': ticket_state,
                                'row': row
                            }
                        except (ValueError, TypeError) as e:
                            print(f"DEBUG: Could not parse lat/lon for ticket {row_idx}: {e}")
                
                # Populate filter dropdowns with unique values
                # Find filter column indices (case-insensitive) - more flexible matching
                filter_type_idx = None
                filter_skill_idx = None
                filter_appointment_idx = None
                
                print(f"DEBUG Filters: Looking for dropdown columns in: {columns}")
                
                for i, col in enumerate(columns):
                    col_lower = col.lower()
                    # More flexible matching - check for key terms
                    if filter_type_idx is None and ('ticket' in col_lower and 'type' in col_lower or col_lower == 'type' or col_lower == 'ticket_type'):
                        filter_type_idx = i
                        self.ticket_type_column_name = col  # Store actual column name for WHERE clause
                        print(f"DEBUG Filters: Found Ticket Type column at index {i}: '{col}'")
                    if filter_skill_idx is None and ('skill' in col_lower):
                        filter_skill_idx = i
                        self.skill_column_name = col  # Store actual column name for WHERE clause
                        print(f"DEBUG Filters: Found Skill column at index {i}: '{col}'")
                    if filter_appointment_idx is None and ('appointment' in col_lower):
                        filter_appointment_idx = i
                        self.appointment_column_name = col  # Store actual column name for WHERE clause
                        print(f"DEBUG Filters: Found Appointment column at index {i}: '{col}'")
                
                # Extract unique values for each filter
                if filter_type_idx is not None:
                    unique_types = sorted(set(str(row[filter_type_idx]) for row in rows if row[filter_type_idx] is not None and str(row[filter_type_idx]) != 'None'))
                    print(f"DEBUG Filters: Ticket Type values: {unique_types}")
                    self.ticket_type_combo['values'] = ['All'] + unique_types
                else:
                    print(f"⚠️ WARNING: Ticket Type column not found!")
                
                # Priority filter still works using priority_idx found earlier
                if priority_idx is not None:
                    unique_priorities = sorted(set(str(row[priority_idx]) for row in rows if row[priority_idx] is not None and str(row[priority_idx]) != 'None'))
                    print(f"DEBUG Filters: Priority values: {unique_priorities}")
                    self.ticket_priority_combo['values'] = ['All'] + unique_priorities
                else:
                    print(f"⚠️ WARNING: Priority column not found (already reported above)")
                
                if filter_skill_idx is not None:
                    unique_skills = sorted(set(str(row[filter_skill_idx]) for row in rows if row[filter_skill_idx] is not None and str(row[filter_skill_idx]) != 'None'))
                    print(f"DEBUG Filters: Skill values: {unique_skills}")
                    self.ticket_skill_combo['values'] = ['All'] + unique_skills
                else:
                    print(f"⚠️ WARNING: Skill column not found!")
                
                if filter_appointment_idx is not None:
                    unique_appointments = sorted(set(str(row[filter_appointment_idx]) for row in rows if row[filter_appointment_idx] is not None and str(row[filter_appointment_idx]) != 'None'))
                    print(f"DEBUG Filters: Appointment values: {unique_appointments}")
                    self.ticket_appointment_combo['values'] = ['All'] + unique_appointments
                else:
                    print(f"⚠️ WARNING: Appointment column not found!")
                
                # Store ticket data with lat/lon for map
                # Try to find latitude/longitude columns (case-insensitive)
                lat_idx = None
                lon_idx = None
                ticket_id_idx = None
                
                for i, col in enumerate(columns):
                    col_lower = col.lower()
                    if 'latitude' in col_lower or col_lower == 'lat':
                        lat_idx = i
                    elif 'longitude' in col_lower or col_lower == 'lon' or col_lower == 'lng':
                        lon_idx = i
                    elif 'ticket' in col_lower and 'id' in col_lower:
                        ticket_id_idx = i
                
                self.ticket_data = {
                    'columns': columns,
                    'rows': rows,
                    'lat_idx': lat_idx,
                    'lon_idx': lon_idx,
                    'id_idx': ticket_id_idx
                }
                
                # Find display indices for lat/lon in the new_columns (after hiding/combining columns)
                # We need to map from original column indices to displayed column indices
                display_lat_idx = None
                display_lon_idx = None
                original_to_display = {}  # Map original index to display index
                
                display_idx = 0
                for i, col in enumerate(columns):
                    if i in address_indices:
                        if i == min(address_indices):  # Only map the first address column
                            original_to_display[i] = display_idx
                            display_idx += 1
                    elif i not in excluded_columns:
                        original_to_display[i] = display_idx
                        display_idx += 1
                
                # Map lat/lon original indices to display indices
                if lat_idx is not None and lat_idx in original_to_display:
                    display_lat_idx = original_to_display[lat_idx]
                if lon_idx is not None and lon_idx in original_to_display:
                    display_lon_idx = original_to_display[lon_idx]
                
                print(f"DEBUG Tickets: Original lat_idx={lat_idx}, display_lat_idx={display_lat_idx}")
                print(f"DEBUG Tickets: Original lon_idx={lon_idx}, display_lon_idx={display_lon_idx}")
                
                # Add click binding to zoom tickets map when ticket is selected
                def on_ticket_click(event):
                    selection = self.dispatches_tree.selection()
                    if selection:
                        item = self.dispatches_tree.item(selection[0])
                        values = item['values']
                        
                        if display_lat_idx is not None and display_lon_idx is not None:
                            try:
                                lat = float(values[display_lat_idx])
                                lon = float(values[display_lon_idx])
                                
                                # Store selected ticket location and state for filtering technicians
                                self.selected_ticket_lat = lat
                                self.selected_ticket_lon = lon
                                
                                # Try to find state from the address column or state index
                                if state_idx is not None:
                                    # Need to find the state value from the original row
                                    # Get row index from the treeview
                                    tree_index = self.dispatches_tree.index(selection[0])
                                    if tree_index < len(rows):
                                        original_row = rows[tree_index]
                                        self.selected_ticket_state = str(original_row[state_idx]) if original_row[state_idx] else None
                                else:
                                    self.selected_ticket_state = None
                                
                                print(f"DEBUG: Selected ticket at ({lat}, {lon}), state: {self.selected_ticket_state}")
                                
                                # Get ticket identifier for label (could be from any displayed column)
                                ticket_label = f"Ticket at {values[0]}" if values else "Selected Ticket"
                                
                                # Store the label for the selection marker
                                self.selected_ticket_label = ticket_label
                                
                                # Update map to show nearby technicians (this will also add the selection marker)
                                self.update_tickets_map()
                                
                                # Zoom to the selected location
                                self.tickets_map_widget.set_position(lat, lon)
                                self.tickets_map_widget.set_zoom(15)  # Close zoom for selected ticket
                            except (ValueError, IndexError, TypeError) as e:
                                print(f"Error zooming to ticket location: {e}")
                                self.tickets_map_status_label.config(text="Could not zoom to ticket location")
                
                self.dispatches_tree.bind('<<TreeviewSelect>>', on_ticket_click)
                
                cursor.close()
                connection.close()
                
                # Load technician data for map
                self.load_technician_data_for_map()
                
                # Update tickets map after loading tickets (schedule on main thread)
                self.root.after(100, self.update_tickets_map)
                
                # Update status labels
                if hasattr(self, 'tickets_status_label'):
                    self.tickets_status_label.config(text=f"Loaded {len(rows)} tickets")
                else:
                    self.smart_dispatch_status_label.config(text=f"Loaded {len(rows)} tickets")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load tickets:\n{str(e)}")
                self.smart_dispatch_status_label.config(text=f"Error loading tickets: {str(e)}")
        
        threading.Thread(target=load, daemon=True).start()
    
    def load_technician_data_for_map(self):
        """Load technician data from database for map display"""
        try:
            connection = sql.connect(
                server_hostname=self.server_hostname.get().strip(),
                http_path=self.http_path.get().strip(),
                access_token=self.get_access_token()
            )
            cursor = connection.cursor()
            
            # Get technician and calendar tables
            tech_table = self.smart_dispatch_tables.get('technicians', '')
            tech_cal_table = self.smart_dispatch_tables.get('technician_calendar', '')
            
            # Query to get technician data with calendar info
            query = f"""
                SELECT 
                    t.*,
                    tc.available,
                    tc.date,
                    tc.start_time,
                    tc.end_time
                FROM {tech_table} t
                LEFT JOIN {tech_cal_table} tc ON t.Technician_id = tc.Technician_id
                WHERE tc.available = 1 OR tc.available IS NULL
            """
            
            cursor.execute(query)
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            rows = cursor.fetchall()
            
            # Find column indices
            tech_id_idx = None
            tech_name_idx = None
            lat_idx = None
            lon_idx = None
            state_idx = None
            skill_idx = None
            available_idx = None
            
            for i, col in enumerate(columns):
                col_lower = col.lower()
                if 'technician' in col_lower and 'id' in col_lower:
                    tech_id_idx = i
                elif 'technician' in col_lower and 'name' in col_lower:
                    tech_name_idx = i
                elif 'latitude' in col_lower:
                    lat_idx = i
                elif 'longitude' in col_lower:
                    lon_idx = i
                elif 'state' in col_lower:
                    state_idx = i
                elif 'skill' in col_lower:
                    skill_idx = i
                elif col_lower == 'available':
                    available_idx = i
            
            # Process and store technician data
            self.technician_data = []
            for row in rows:
                # Skip if lat/lon not available or not available
                if lat_idx is None or lon_idx is None or not row[lat_idx] or not row[lon_idx]:
                    continue
                    
                # Check if technician is available
                is_available = True
                if available_idx is not None and row[available_idx] is not None:
                    try:
                        is_available = int(row[available_idx]) == 1
                    except (ValueError, TypeError):
                        pass
                
                if not is_available:
                    continue  # Skip unavailable technicians
                
                try:
                    tech_data = {
                        'technician_id': row[tech_id_idx] if tech_id_idx is not None else None,
                        'name': row[tech_name_idx] if tech_name_idx is not None else 'Unknown',
                        'latitude': float(row[lat_idx]),
                        'longitude': float(row[lon_idx]),
                        'state': str(row[state_idx]) if state_idx is not None and row[state_idx] else None,
                        'skill': str(row[skill_idx]) if skill_idx is not None and row[skill_idx] else None,
                        'row': row
                    }
                    self.technician_data.append(tech_data)
                except (ValueError, TypeError) as e:
                    print(f"DEBUG: Could not parse technician data: {e}")
                    continue
            
            connection.close()
            print(f"DEBUG: Loaded {len(self.technician_data)} available technicians for map")
            
        except Exception as e:
            print(f"Error loading technician data: {e}")
            self.technician_data = []
    
    def update_tickets_map(self):
        """Update the tickets map with current ticket locations and nearby technicians"""
        try:
            if not hasattr(self, 'tickets_map_widget'):
                return
            
            # Clear previous markers
            self.tickets_map_widget.delete_all_marker()
            self.selected_ticket_marker = None  # Clear selection marker reference since all markers are deleted
            print("Tickets map markers cleared")
            
            # Reset info label
            if hasattr(self, 'tickets_map_info_label'):
                self.tickets_map_info_label.config(text="Click on a marker to see details", foreground='blue')
            
            # Collect location data
            all_lats = []
            all_lons = []
            ticket_count = 0
            tech_count = 0
            
            # Add ticket locations (red markers)
            if hasattr(self, 'ticket_data') and self.ticket_data:
                for ticket_idx, ticket_info in self.ticket_data.items():
                    try:
                        lat = ticket_info['latitude']
                        lon = ticket_info['longitude']
                        
                        all_lats.append(lat)
                        all_lons.append(lon)
                        
                        # Build detailed text for click event
                        detail_text = f"🎫 TICKET #{ticket_idx}\n"
                        detail_text += f"  • Location: {lat:.4f}, {lon:.4f}\n"
                        if ticket_info.get('state'):
                            detail_text += f"  • State: {ticket_info['state']}"
                        
                        # Add red marker for ticket (no text on hover, only on click)
                        marker = self.tickets_map_widget.set_marker(lat, lon, 
                                                           marker_color_circle="red", 
                                                           marker_color_outside="darkred",
                                                           command=lambda details=detail_text, label=self.tickets_map_info_label: label.config(text=details, foreground='black'))
                        ticket_count += 1
                    except (ValueError, TypeError, KeyError):
                        continue
            
            print(f"Added {ticket_count} ticket markers to tickets map")
            
            # Add technician markers (green) - filter based on selected ticket and distance
            if hasattr(self, 'technician_data') and self.technician_data:
                # Get distance filter value
                distance_filter = self.ticket_distance_var.get() if hasattr(self, 'ticket_distance_var') else 'All'
                
                # Parse distance limit from filter
                max_distance = None
                if distance_filter != 'All':
                    try:
                        max_distance = float(distance_filter.split()[0])  # Extract number from "10 miles"
                    except (ValueError, IndexError):
                        max_distance = None
                
                # Filter technicians
                for tech in self.technician_data:
                    try:
                        tech_lat = tech['latitude']
                        tech_lon = tech['longitude']
                        tech_state = tech.get('state')
                        
                        # If a ticket is selected, filter by state and distance
                        should_show = True
                        if self.selected_ticket_lat is not None and self.selected_ticket_lon is not None:
                            # Filter by state if both have state info
                            if tech_state and self.selected_ticket_state:
                                if tech_state.lower() != self.selected_ticket_state.lower():
                                    should_show = False
                            
                            # Filter by distance if limit is set
                            if should_show and max_distance is not None:
                                distance = self.calculate_distance(
                                    self.selected_ticket_lat, self.selected_ticket_lon,
                                    tech_lat, tech_lon
                                )
                                if distance > max_distance:
                                    should_show = False
                        elif max_distance is not None:
                            # No ticket selected but distance filter is set - don't show any technicians
                            should_show = False
                        
                        if should_show:
                            all_lats.append(tech_lat)
                            all_lons.append(tech_lon)
                            
                            # Build detailed text for click event
                            detail_text = f"👨‍🔧 TECHNICIAN: {tech.get('name', 'Unknown')}\n"
                            detail_text += f"  • ID: {tech.get('technician_id', 'N/A')}\n"
                            detail_text += f"  • Location: {tech_lat:.4f}, {tech_lon:.4f}\n"
                            if tech_state:
                                detail_text += f"  • State: {tech_state}\n"
                            if tech.get('skill'):
                                detail_text += f"  • Skill: {tech['skill']}\n"
                            if self.selected_ticket_lat and self.selected_ticket_lon:
                                distance = self.calculate_distance(
                                    self.selected_ticket_lat, self.selected_ticket_lon,
                                    tech_lat, tech_lon
                                )
                                detail_text += f"  • Distance: {distance:.1f} miles"
                            
                            # Add green marker for technician
                            marker = self.tickets_map_widget.set_marker(tech_lat, tech_lon,
                                                               marker_color_circle="green",
                                                               marker_color_outside="darkgreen",
                                                               command=lambda details=detail_text, label=self.tickets_map_info_label: label.config(text=details, foreground='black'))
                            tech_count += 1
                    except (ValueError, TypeError, KeyError):
                        continue
            
            print(f"Added {tech_count} technician markers to tickets map")
            
            # Center and zoom map if we have data
            if all_lats and all_lons:
                # Calculate center
                center_lat = sum(all_lats) / len(all_lats)
                center_lon = sum(all_lons) / len(all_lons)
                
                # Calculate appropriate zoom level based on data spread
                lat_range = max(all_lats) - min(all_lats) if len(set(all_lats)) > 1 else 0.1
                lon_range = max(all_lons) - min(all_lons) if len(set(all_lons)) > 1 else 0.1
                max_range = max(lat_range, lon_range)
                
                # Determine zoom level
                if max_range > 20:
                    zoom = 5
                elif max_range > 10:
                    zoom = 7
                elif max_range > 5:
                    zoom = 9
                elif max_range > 2:
                    zoom = 10
                elif max_range > 1:
                    zoom = 11
                elif max_range > 0.5:
                    zoom = 12
                elif max_range > 0.1:
                    zoom = 13
                else:
                    zoom = 14
                
                print(f"Tickets map centering: ({center_lat:.4f}, {center_lon:.4f}), zoom={zoom}")
                
                self.tickets_map_widget.set_position(center_lat, center_lon)
                self.tickets_map_widget.set_zoom(zoom)
                
                status_text = f"Showing {ticket_count} tickets"
                if tech_count > 0:
                    status_text += f" and {tech_count} technicians"
                self.tickets_map_status_label.config(text=status_text)
            else:
                self.tickets_map_status_label.config(text="No location data to display")
            
            # Add green selection marker if a ticket is selected
            if self.selected_ticket_lat is not None and self.selected_ticket_lon is not None:
                try:
                    label = self.selected_ticket_label if hasattr(self, 'selected_ticket_label') else "Selected Ticket"
                    detail_text = f"📍 SELECTED: {label}\n  • Location: {self.selected_ticket_lat:.4f}, {self.selected_ticket_lon:.4f}"
                    self.selected_ticket_marker = self.tickets_map_widget.set_marker(
                        self.selected_ticket_lat, self.selected_ticket_lon,
                        text="📍",  # Pin emoji as marker text
                        marker_color_circle="lime",  # Bright green
                        marker_color_outside="green",
                        command=lambda details=detail_text, lbl=self.tickets_map_info_label: lbl.config(text=details, foreground='darkgreen')
                    )
                    print(f"Added green selection marker at ({self.selected_ticket_lat}, {self.selected_ticket_lon})")
                except Exception as marker_error:
                    print(f"Error adding selection marker: {marker_error}")
            
        except Exception as e:
            print(f"Error updating tickets map: {e}")
            import traceback
            traceback.print_exc()
            self.tickets_map_status_label.config(text="Error displaying tickets map")
    
    def update_map(self):
        """Update the technicians map with current technician locations"""
        try:
            if not hasattr(self, 'map_widget'):
                return
            
            # Clear previous markers
            self.map_widget.delete_all_marker()
            print("Technicians map markers cleared")
            
            # Reset info label
            if hasattr(self, 'map_info_label'):
                self.map_info_label.config(text="Click on a marker to see technician details", foreground='blue')
            
            # Collect location data
            all_lats = []
            all_lons = []
            tech_count = 0
            
            # Add technician locations (green markers for available only)
            if hasattr(self, 'smart_dispatch_results') and 'technicians_combined' in self.smart_dispatch_results:
                tech_data = self.smart_dispatch_results['technicians_combined']
                tech_lat_idx = tech_data.get('lat_idx')
                tech_lon_idx = tech_data.get('lon_idx')
                tech_name_idx = tech_data.get('name_idx')
                
                # Find availability and skill columns
                avail_idx = None
                skill_idx = None
                city_idx = None
                state_idx = None
                
                for i, col in enumerate(tech_data['columns']):
                    col_lower = col.lower()
                    if col_lower == 'available':
                        avail_idx = i
                    elif 'skill' in col_lower:
                        skill_idx = i
                    elif col_lower == 'city':
                        city_idx = i
                    elif col_lower == 'state':
                        state_idx = i
                
                if tech_lat_idx is not None and tech_lon_idx is not None:
                    for row in tech_data['rows']:
                        try:
                            lat = float(row[tech_lat_idx])
                            lon = float(row[tech_lon_idx])
                            tech_name = row[tech_name_idx] if tech_name_idx is not None else "Unknown"
                            
                            # ALWAYS skip unavailable technicians on map (only show green/available)
                            # This ensures map only shows available technicians regardless of filter selection
                            if avail_idx is not None:
                                is_available = row[avail_idx]
                                # Convert to comparable format
                                if isinstance(is_available, bool):
                                    is_available_bool = is_available
                                elif isinstance(is_available, (int, float)):
                                    is_available_bool = (is_available == 1)
                                else:
                                    is_available_bool = str(is_available).lower() in ('true', '1', 'yes')
                                
                                # Skip if NOT available (only show available=1 on map)
                                if not is_available_bool:
                                    continue
                            else:
                                # If no availability column found, skip this technician to be safe
                                continue
                            
                            all_lats.append(lat)
                            all_lons.append(lon)
                            
                            # Build detailed text for click event
                            text_parts = [f"👨‍🔧 TECHNICIAN: {tech_name}"]
                            if skill_idx is not None and row[skill_idx]:
                                text_parts.append(f"  • Skill: {row[skill_idx]}")
                            if city_idx is not None and state_idx is not None:
                                location = f"{row[city_idx]}, {row[state_idx]}" if row[city_idx] and row[state_idx] else "N/A"
                                text_parts.append(f"  • Location: {location}")
                            if avail_idx is not None:
                                text_parts.append("  • Status: ✅ Available")
                            text_parts.append(f"  • Coordinates: ({lat:.4f}, {lon:.4f})")
                            detail_text = "\n".join(text_parts)
                            
                            # Add green marker for available technician (no text on hover, only on click)
                            marker = self.map_widget.set_marker(lat, lon, 
                                                               marker_color_circle="green", 
                                                               marker_color_outside="darkgreen",
                                                               command=lambda details=detail_text: self.show_marker_details(details))
                            tech_count += 1
                        except (ValueError, TypeError, IndexError):
                            continue
                
                print(f"Added {tech_count} technician markers")
            
            # Center and zoom map if we have data
            if all_lats and all_lons:
                # Calculate center
                center_lat = sum(all_lats) / len(all_lats)
                center_lon = sum(all_lons) / len(all_lons)
                
                # Calculate appropriate zoom level based on data spread
                lat_range = max(all_lats) - min(all_lats) if len(set(all_lats)) > 1 else 0.1
                lon_range = max(all_lons) - min(all_lons) if len(set(all_lons)) > 1 else 0.1
                max_range = max(lat_range, lon_range)
                
                # Determine zoom level (approximate) - adjusted for better visibility
                if max_range > 20:
                    zoom = 5
                elif max_range > 10:
                    zoom = 7
                elif max_range > 5:
                    zoom = 9
                elif max_range > 2:
                    zoom = 10
                elif max_range > 1:
                    zoom = 11
                elif max_range > 0.5:
                    zoom = 12
                elif max_range > 0.1:
                    zoom = 13
                else:
                    zoom = 14
                
                print(f"Map centering: ({center_lat:.4f}, {center_lon:.4f}), zoom={zoom}, range={max_range:.4f}")
                print(f"Lat range: {min(all_lats):.4f} to {max(all_lats):.4f}")
                print(f"Lon range: {min(all_lons):.4f} to {max(all_lons):.4f}")
                
                self.map_widget.set_position(center_lat, center_lon)
                self.map_widget.set_zoom(zoom)
                
                self.map_status_label.config(text=f"Showing {tech_count} available technicians")
            else:
                self.map_status_label.config(text="No technician location data to display")
            
        except Exception as e:
            print(f"Error updating map: {e}")
            import traceback
            traceback.print_exc()
            self.map_status_label.config(text="Error displaying map")
    
    def show_marker_details(self, details):
        """Display marker details in the info label when clicked"""
        try:
            if hasattr(self, 'map_info_label'):
                self.map_info_label.config(text=details, foreground='black')
                print(f"Marker clicked, showing details")
        except Exception as e:
            print(f"Error showing marker details: {e}")
    
    def zoom_map_to_location(self, lat, lon, label="Selected Location"):
        """Zoom the technicians map to a specific location with a highlighted marker"""
        try:
            if not hasattr(self, 'map_widget'):
                return
            
            print(f"Zooming technicians map to location: {label} at ({lat}, {lon})")
            
            # Center on the selected location with a closer zoom
            self.map_widget.set_position(lat, lon)
            self.map_widget.set_zoom(15)  # Close zoom for selected technician
            
            # The markers are already on the map from update_map()
            # Just center and zoom to the selected location
            
            self.map_status_label.config(text=f"Zoomed to: {label}")
            
        except Exception as e:
            print(f"Error zooming technicians map: {e}")
            import traceback
            traceback.print_exc()
    
    def zoom_tickets_map_to_location(self, lat, lon, label="Selected Ticket"):
        """Zoom the tickets map to a specific ticket location and add a green arrow marker"""
        try:
            if not hasattr(self, 'tickets_map_widget'):
                return
            
            print(f"Zooming tickets map to location: {label} at ({lat}, {lon})")
            
            # Remove previous selection marker if it exists
            if hasattr(self, 'selected_ticket_marker') and self.selected_ticket_marker is not None:
                try:
                    self.selected_ticket_marker.delete()
                except:
                    pass
            
            # Center on the selected location with a closer zoom
            self.tickets_map_widget.set_position(lat, lon)
            self.tickets_map_widget.set_zoom(15)  # Close zoom for selected ticket
            
            # Add a green arrow/marker to highlight the selected ticket location
            detail_text = f"📍 SELECTED: {label}\n  • Location: {lat:.4f}, {lon:.4f}"
            self.selected_ticket_marker = self.tickets_map_widget.set_marker(
                lat, lon,
                text="📍",  # Pin emoji as marker text
                marker_color_circle="lime",  # Bright green
                marker_color_outside="green",
                command=lambda details=detail_text, lbl=self.tickets_map_info_label: lbl.config(text=details, foreground='darkgreen')
            )
            
            print(f"Added green selection marker at ({lat}, {lon})")
            
            self.tickets_map_status_label.config(text=f"Selected: {label}")
            
        except Exception as e:
            print(f"Error zooming tickets map: {e}")
            import traceback
            traceback.print_exc()
            if hasattr(self, 'tickets_map_status_label'):
                self.tickets_map_status_label.config(text="Error zooming map")
    
    def create_dispatch_history_tab(self):
        """Create Dispatch History tab"""
        # Search/Filter frame
        filter_frame = ttk.LabelFrame(self.dispatch_history_frame, text="Search Filters", padding=10)
        filter_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Search term
        ttk.Label(filter_frame, text="Search Term:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.dispatch_history_search_var = tk.StringVar()
        search_entry = ttk.Entry(filter_frame, textvariable=self.dispatch_history_search_var, width=40)
        search_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # Column to search (optional)
        ttk.Label(filter_frame, text="Column (optional):").grid(row=0, column=2, sticky=tk.W, padx=5, pady=5)
        self.dispatch_history_column_var = tk.StringVar()
        ttk.Entry(filter_frame, textvariable=self.dispatch_history_column_var, width=30).grid(row=0, column=3, padx=5, pady=5)
        
        # Limit results
        ttk.Label(filter_frame, text="Limit:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.dispatch_history_limit_var = tk.StringVar(value="100")
        ttk.Entry(filter_frame, textvariable=self.dispatch_history_limit_var, width=10).grid(row=1, column=1, sticky=tk.W, padx=5, pady=5)
        
        # Query type selection
        ttk.Label(filter_frame, text="Query Type:").grid(row=1, column=2, sticky=tk.W, padx=5, pady=5)
        self.dispatch_history_query_type_var = tk.StringVar(value="all")
        query_types = [
            ("Search (LIKE)", "search"),
            ("Exact Match", "exact"),
            ("Show All", "all"),
            ("Show Schema", "schema")
        ]
        for i, (text, value) in enumerate(query_types):
            rb = ttk.Radiobutton(filter_frame, text=text, variable=self.dispatch_history_query_type_var, value=value)
            rb.grid(row=1, column=3+i, padx=5, pady=5)
        
        # Buttons frame
        button_frame = ttk.Frame(self.dispatch_history_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(button_frame, text="Load History", command=self.load_dispatch_history, width=15).pack(side=tk.LEFT, padx=3)
        ttk.Button(button_frame, text="Clear Results", command=self.clear_dispatch_history, width=15).pack(side=tk.LEFT, padx=3)
        ttk.Button(button_frame, text="Export Results", command=self.export_dispatch_history, width=15).pack(side=tk.LEFT, padx=3)
        
        # Results frame
        results_frame = ttk.LabelFrame(self.dispatch_history_frame, text="Dispatch History Results", padding=10)
        results_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Treeview for results
        self.dispatch_history_tree = ttk.Treeview(results_frame)
        self.dispatch_history_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        # Scrollbars
        history_scrollbar_v = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.dispatch_history_tree.yview)
        history_scrollbar_h = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL, command=self.dispatch_history_tree.xview)
        history_scrollbar_v.pack(side=tk.RIGHT, fill=tk.Y)
        history_scrollbar_h.pack(side=tk.BOTTOM, fill=tk.X)
        self.dispatch_history_tree.configure(yscrollcommand=history_scrollbar_v.set, xscrollcommand=history_scrollbar_h.set)
        
        # Status label
        self.dispatch_history_status_label = ttk.Label(self.dispatch_history_frame, text="Ready to load dispatch history")
        self.dispatch_history_status_label.pack(pady=5)
        
        # Store results
        self.dispatch_history_results = []
    
    def load_dispatch_history(self):
        """Load dispatch history"""
        query_type = self.dispatch_history_query_type_var.get()
        search_term = self.dispatch_history_search_var.get().strip()
        
        # Validate search term for search/exact queries
        if query_type in ["search", "exact"] and not search_term:
            messagebox.showwarning("Warning", "Please enter a search term for search/exact queries")
            return
        
        def load():
            try:
                self.dispatch_history_status_label.config(text="Loading dispatch history...")
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                
                table_name = 'hackathon.hackathon_the_original_packet.smart_dispatch_history'
                search_column = self.dispatch_history_column_var.get().strip()
                limit = self.dispatch_history_limit_var.get().strip() or "100"
                search_term_escaped = search_term.replace("'", "''")
                
                # Build query based on type
                if query_type == "schema":
                    query = f"DESCRIBE {table_name}"
                elif query_type == "all":
                    query = f"SELECT * FROM {table_name} LIMIT {limit}"
                elif query_type == "exact":
                    if search_column:
                        query = f"SELECT * FROM {table_name} WHERE {search_column} = '{search_term_escaped}' LIMIT {limit}"
                    else:
                        cursor.execute(f"DESCRIBE {table_name}")
                        columns_info = cursor.fetchall()
                        column_names = [col[0] for col in columns_info]
                        conditions = " OR ".join([f"CAST({col} AS STRING) = '{search_term_escaped}'" for col in column_names])
                        query = f"SELECT * FROM {table_name} WHERE {conditions} LIMIT {limit}"
                else:  # search (LIKE)
                    if search_column:
                        query = f"SELECT * FROM {table_name} WHERE {search_column} LIKE '%{search_term_escaped}%' LIMIT {limit}"
                    else:
                        cursor.execute(f"DESCRIBE {table_name}")
                        columns_info = cursor.fetchall()
                        column_names = [col[0] for col in columns_info]
                        conditions = " OR ".join([f"CAST({col} AS STRING) LIKE '%{search_term_escaped}%'" for col in column_names])
                        query = f"SELECT * FROM {table_name} WHERE {conditions} LIMIT {limit}"
                
                cursor.execute(query)
                
                # Get column names
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                
                # Clear previous results
                for item in self.dispatch_history_tree.get_children():
                    self.dispatch_history_tree.delete(item)
                
                # Configure treeview columns
                self.dispatch_history_tree['columns'] = columns
                self.dispatch_history_tree.heading('#0', text='#')
                for col in columns:
                    self.dispatch_history_tree.heading(col, text=col)
                    self.dispatch_history_tree.column(col, width=150, anchor=tk.W)
                
                # Fetch and display results
                rows = cursor.fetchall()
                for i, row in enumerate(rows):
                    self.dispatch_history_tree.insert('', tk.END, text=str(i+1), values=row)
                
                self.dispatch_history_results = rows
                
                cursor.close()
                connection.close()
                
                self.dispatch_history_status_label.config(text=f"Loaded {len(rows)} history records")
                
            except Exception as e:
                self.dispatch_history_status_label.config(text=f"Error: {str(e)}")
                messagebox.showerror("Error", f"Failed to load dispatch history:\n{str(e)}")
        
        threading.Thread(target=load, daemon=True).start()
    
    def clear_dispatch_history(self):
        """Clear dispatch history results"""
        for item in self.dispatch_history_tree.get_children():
            self.dispatch_history_tree.delete(item)
        self.dispatch_history_results = []
        self.dispatch_history_status_label.config(text="Results cleared")
    
    def export_dispatch_history(self):
        """Export dispatch history to CSV"""
        if not self.dispatch_history_results:
            messagebox.showwarning("Warning", "No results to export")
            return
        
        filename = filedialog.asksaveasfilename(
            title="Export Dispatch History",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                import csv
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    
                    # Write column headers
                    if self.dispatch_history_results:
                        columns = [col for col in self.dispatch_history_tree['columns']]
                        writer.writerow(columns)
                        
                        # Write rows
                        for row in self.dispatch_history_results:
                            writer.writerow(row)
                
                messagebox.showinfo("Success", f"Dispatch history exported to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export results:\n{str(e)}")
    
    def export_smart_dispatch_results(self):
        """Export results to CSV"""
        if not self.smart_dispatch_results:
            messagebox.showwarning("Warning", "No results to export")
            return
        
        filename = filedialog.asksaveasfilename(
            title="Export Results",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                import csv
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    
                    for table_key, data in self.smart_dispatch_results.items():
                        # Write table name as header
                        if table_key == 'technicians_combined':
                            table_name = "Technicians (Combined View)"
                        elif table_key in self.smart_dispatch_tables:
                            table_name = self.smart_dispatch_tables[table_key]
                        else:
                            table_name = table_key
                        
                        writer.writerow([f"Table: {table_name}"])
                        writer.writerow([])
                        
                        # Write column headers
                        writer.writerow(data['columns'])
                        
                        # Write rows
                        for row in data['rows']:
                            writer.writerow(row)
                        
                        writer.writerow([])
                        writer.writerow([])
                
                messagebox.showinfo("Success", f"Results exported to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export results:\n{str(e)}")
    
    
    def log_status(self, message):
        """Log message to status text"""
        self.status_text.config(state=tk.NORMAL)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.status_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.status_text.see(tk.END)
        self.status_text.config(state=tk.DISABLED)
    
    def test_sql_connection(self):
        """Test SQL connection"""
        def test():
            try:
                self.log_status("Testing SQL connection...")
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                cursor.close()
                connection.close()
                self.log_status("✓ SQL connection successful!")
                messagebox.showinfo("Success", "SQL connection test successful!")
            except Exception as e:
                self.log_status(f"✗ SQL connection failed: {str(e)}")
                messagebox.showerror("Connection Error", f"SQL connection failed:\n{str(e)}")
        
        threading.Thread(target=test, daemon=True).start()
    
    def test_workspace_connection(self):
        """Test Workspace API connection"""
        def test():
            try:
                self.log_status("Testing Workspace API connection...")
                client = WorkspaceClient(
                    host=self.workspace_url.get().strip(),
                    token=self.get_access_token()
                )
                # Try to get current user
                current_user = client.current_user.me()
                self.log_status(f"✓ Workspace connection successful! User: {current_user.user_name}")
                messagebox.showinfo("Success", f"Workspace connection successful!\nUser: {current_user.user_name}")
            except Exception as e:
                self.log_status(f"✗ Workspace connection failed: {str(e)}")
                messagebox.showerror("Connection Error", f"Workspace connection failed:\n{str(e)}")
        
        threading.Thread(target=test, daemon=True).start()
    
    def execute_sql_query(self):
        """Execute SQL query"""
        query = self.sql_query_text.get(1.0, tk.END).strip()
        if not query:
            messagebox.showwarning("Warning", "Please enter a SQL query")
            return
        
        def execute():
            try:
                self.sql_status_label.config(text="Executing query...")
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                cursor.execute(query)
                
                # Clear previous results
                for item in self.sql_results_tree.get_children():
                    self.sql_results_tree.delete(item)
                
                # Get column names
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                self.sql_results_tree['columns'] = columns
                for col in columns:
                    self.sql_results_tree.heading(col, text=col)
                    self.sql_results_tree.column(col, width=150)
                
                # Fetch and display results
                rows = cursor.fetchall()
                for row in rows:
                    self.sql_results_tree.insert('', tk.END, values=row)
                
                cursor.close()
                connection.close()
                self.sql_status_label.config(text=f"Query executed successfully. {len(rows)} rows returned.")
            except Exception as e:
                self.sql_status_label.config(text=f"Error: {str(e)}")
                messagebox.showerror("Query Error", f"Query execution failed:\n{str(e)}")
        
        threading.Thread(target=execute, daemon=True).start()
    
    def load_query_file(self):
        """Load SQL query from file"""
        filename = filedialog.askopenfilename(
            title="Select SQL File",
            filetypes=[("SQL files", "*.sql"), ("All files", "*.*")]
        )
        if filename:
            try:
                with open(filename, 'r') as f:
                    content = f.read()
                    self.sql_query_text.delete(1.0, tk.END)
                    self.sql_query_text.insert(1.0, content)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load file:\n{str(e)}")
    
    # ==================== DISPATCH OPTIMIZER TAB ====================
    
    def create_optimizer_tab(self):
        """Create the Dispatch Optimizer tab"""
        # Main container
        main_container = ttk.Frame(self.optimizer_frame)
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Title at top
        title_label = ttk.Label(main_container, text="Smart Dispatch Optimizer", 
                               font=('Arial', 16, 'bold'))
        title_label.pack(pady=(0, 15))
        
        # Top section - Instructions (left) and Metrics (right) side by side
        top_section = ttk.Frame(main_container)
        top_section.pack(fill=tk.BOTH, expand=False, pady=(0, 15))
        
        # Left: Instructions
        instructions_frame = ttk.LabelFrame(top_section, text="Instructions", padding=10)
        instructions_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        instructions = """This tool optimizes dispatch assignments based on:
        
1. Skill Matching - Assigns technicians with correct skills
2. Distance Minimization - Assigns closest available technician
3. Workload Balancing - Distributes work evenly
4. Calendar Availability - Respects technician schedules

SETUP: Table names are pre-configured for your data.
Credentials auto-load from databricks_config.json

Click 'Run Optimization' to optimize all pending dispatches."""
        
        instructions_label = ttk.Label(instructions_frame, text=instructions, 
                                      justify=tk.LEFT, wraplength=400)
        instructions_label.pack()
        
        # Right: Metrics Display
        metrics_frame = ttk.LabelFrame(top_section, text="Optimization Metrics", padding=10)
        metrics_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.opt_metrics_text = scrolledtext.ScrolledText(metrics_frame, height=12, width=50,
                                                          font=('Consolas', 9))
        self.opt_metrics_text.pack(fill=tk.BOTH, expand=True)
        
        # Action Buttons (always visible)
        button_frame = ttk.Frame(main_container)
        button_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Create a row of buttons
        button_row = ttk.Frame(button_frame)
        button_row.pack()
        
        self.opt_run_button = ttk.Button(button_row, text="🚀 Run Optimization", 
                                         command=self.run_optimization,
                                         width=25)
        self.opt_run_button.pack(side=tk.LEFT, padx=5)
        
        self.opt_export_button = ttk.Button(button_row, text="📤 Export Results to CSV", 
                                           command=self.export_optimization_results,
                                           state=tk.DISABLED,
                                           width=25)
        self.opt_export_button.pack(side=tk.LEFT, padx=5)
        
        self.opt_update_button = ttk.Button(button_row, text="💾 Update Databricks Table", 
                                           command=self.update_databricks_with_results,
                                           state=tk.DISABLED,
                                           width=25)
        self.opt_update_button.pack(side=tk.LEFT, padx=5)
        
        # Configuration toggle button (in same row)
        self.config_visible = False
        self.config_toggle_button = ttk.Button(button_row, 
                                               text="⚙️ Configuration", 
                                               command=self.toggle_configuration,
                                               width=20)
        self.config_toggle_button.pack(side=tk.LEFT, padx=5)
        
        # Hidden Configuration Frame (collapsible)
        self.config_container = ttk.Frame(main_container)
        # Don't pack initially - will be shown/hidden by toggle
        
        # Configuration Frame (initially hidden)
        self.config_frame = ttk.LabelFrame(self.config_container, text="Configuration", padding=10)
        self.config_frame.pack(fill=tk.X, pady=(0, 5))
        
        # Table names
        ttk.Label(self.config_frame, text="Technicians Table:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.opt_tech_table = ttk.Entry(self.config_frame, width=70)
        self.opt_tech_table.insert(0, "hackathon.hackathon_the_original_packet.smart_dispatch_technicians")
        self.opt_tech_table.grid(row=0, column=1, pady=5, padx=5)
        
        ttk.Label(self.config_frame, text="Calendar Table:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.opt_cal_table = ttk.Entry(self.config_frame, width=70)
        self.opt_cal_table.insert(0, "hackathon.hackathon_the_original_packet.smart_dispatch_technician_calendar")
        self.opt_cal_table.grid(row=1, column=1, pady=5, padx=5)
        
        ttk.Label(self.config_frame, text="Dispatches Table:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.opt_dispatch_table = ttk.Entry(self.config_frame, width=70)
        self.opt_dispatch_table.insert(0, "hackathon.hackathon_the_original_packet.smartdispatchcurrentdispatches")
        self.opt_dispatch_table.grid(row=2, column=1, pady=5, padx=5)
        
        # Bottom section - Results Table
        results_container = ttk.Frame(main_container)
        results_container.pack(fill=tk.BOTH, expand=True)
        
        # Results Label
        results_label = ttk.Label(results_container, text="Optimization Results", 
                                 font=('Arial', 12, 'bold'))
        results_label.pack(pady=(0, 10))
        
        # Filter Frame
        filter_frame = ttk.LabelFrame(results_container, text="🔍 Column Filters (type to filter)", padding=5)
        filter_frame.pack(fill=tk.X, padx=5, pady=(0, 5))
        
        # Create filter entry widgets for each column
        self.filter_entries = {}
        columns_list = [
            ('Dispatch ID', 100),
            ('Required Skill', 180),
            ('City, State', 120),
            ('Original Tech', 100),
            ('Optimized Tech', 100),
            ('Distance (mi)', 100),
            ('Workload %', 90),
            ('Status', 100)
        ]
        
        filter_row = ttk.Frame(filter_frame)
        filter_row.pack(fill=tk.X)
        
        for col_name, col_width in columns_list:
            col_frame = ttk.Frame(filter_row)
            col_frame.pack(side=tk.LEFT, padx=2)
            
            # Column label (smaller font)
            ttk.Label(col_frame, text=col_name, font=('Arial', 8)).pack()
            
            # Filter entry
            filter_entry = ttk.Entry(col_frame, width=int(col_width/8))
            filter_entry.pack()
            self.filter_entries[col_name] = filter_entry
            
            # Bind to apply filter on keyup
            filter_entry.bind('<KeyRelease>', lambda e: self.apply_result_filters())
        
        # Clear filters button
        clear_btn = ttk.Button(filter_frame, text="✖ Clear All Filters", 
                              command=self.clear_all_filters)
        clear_btn.pack(pady=(5, 0))
        
        # Results Table
        results_table_frame = ttk.Frame(results_container)
        results_table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbars
        results_yscroll = ttk.Scrollbar(results_table_frame, orient=tk.VERTICAL)
        results_xscroll = ttk.Scrollbar(results_table_frame, orient=tk.HORIZONTAL)
        
        # Treeview for results
        columns = ('Dispatch ID', 'Required Skill', 'City, State', 'Original Tech', 
                  'Optimized Tech', 'Distance (mi)', 'Workload %', 'Status')
        self.opt_results_tree = ttk.Treeview(results_table_frame, columns=columns, 
                                            show='headings',
                                            yscrollcommand=results_yscroll.set,
                                            xscrollcommand=results_xscroll.set,
                                            height=15)
        
        # Configure scrollbars
        results_yscroll.config(command=self.opt_results_tree.yview)
        results_xscroll.config(command=self.opt_results_tree.xview)
        
        # Column headings
        self.opt_results_tree.heading('Dispatch ID', text='Dispatch ID')
        self.opt_results_tree.heading('Required Skill', text='Required Skill')
        self.opt_results_tree.heading('City, State', text='City, State')
        self.opt_results_tree.heading('Original Tech', text='Original Tech')
        self.opt_results_tree.heading('Optimized Tech', text='Optimized Tech')
        self.opt_results_tree.heading('Distance (mi)', text='Distance (mi)')
        self.opt_results_tree.heading('Workload %', text='Workload %')
        self.opt_results_tree.heading('Status', text='Status')
        
        # Column widths and alignment
        self.opt_results_tree.column('Dispatch ID', width=100, anchor='center')
        self.opt_results_tree.column('Required Skill', width=180, anchor='w')
        self.opt_results_tree.column('City, State', width=120, anchor='w')
        self.opt_results_tree.column('Original Tech', width=100, anchor='center')
        self.opt_results_tree.column('Optimized Tech', width=100, anchor='center')
        self.opt_results_tree.column('Distance (mi)', width=100, anchor='center')
        self.opt_results_tree.column('Workload %', width=90, anchor='center')
        self.opt_results_tree.column('Status', width=100, anchor='center')
        
        # Pack tree and scrollbars
        self.opt_results_tree.grid(row=0, column=0, sticky='nsew')
        results_yscroll.grid(row=0, column=1, sticky='ns')
        results_xscroll.grid(row=1, column=0, sticky='ew')
        
        # Configure grid weights
        results_table_frame.grid_rowconfigure(0, weight=1)
        results_table_frame.grid_columnconfigure(0, weight=1)
        
        # Store optimized results for export and filtering
        self.optimized_results = []
        self.optimized_results_display = []  # For filtering display
    
    def toggle_configuration(self):
        """Toggle visibility of configuration frame"""
        if self.config_visible:
            # Hide configuration container
            self.config_container.pack_forget()
            self.config_toggle_button.config(text="⚙️ Configuration")
            self.config_visible = False
        else:
            # Show configuration container (pack between buttons and results)
            self.config_container.pack(fill=tk.X, pady=(0, 10), after=self.opt_run_button.master.master)
            self.config_toggle_button.config(text="⚙️ Hide Config")
            self.config_visible = True
    
    def apply_result_filters(self):
        """Apply filters to the optimization results table"""
        if not self.optimized_results_display:
            return
        
        # Get filter values from all entries
        filters = {}
        for col_name, entry in self.filter_entries.items():
            filter_text = entry.get().strip().lower()
            if filter_text:
                filters[col_name] = filter_text
        
        # Clear current display
        self.opt_results_tree.delete(*self.opt_results_tree.get_children())
        
        # If no filters, show all results
        if not filters:
            for row in self.optimized_results_display:
                self.opt_results_tree.insert('', tk.END, values=row)
            return
        
        # Apply filters
        column_indices = {
            'Dispatch ID': 0,
            'Required Skill': 1,
            'City, State': 2,
            'Original Tech': 3,
            'Optimized Tech': 4,
            'Distance (mi)': 5,
            'Workload %': 6,
            'Status': 7
        }
        
        filtered_count = 0
        for row in self.optimized_results_display:
            # Check if row matches all filters
            matches = True
            for col_name, filter_text in filters.items():
                col_index = column_indices[col_name]
                cell_value = str(row[col_index]).lower()
                
                if filter_text not in cell_value:
                    matches = False
                    break
            
            if matches:
                self.opt_results_tree.insert('', tk.END, values=row)
                filtered_count += 1
        
        # Update status in metrics (optional)
        if hasattr(self, 'opt_metrics_text') and self.opt_metrics_text.winfo_exists():
            # Show filter status
            pass  # We could add a status message here
    
    def clear_all_filters(self):
        """Clear all filter entries and show all results"""
        # Clear all filter entry widgets
        for entry in self.filter_entries.values():
            entry.delete(0, tk.END)
        
        # Reapply filters (which will show all results since filters are empty)
        self.apply_result_filters()
    
    def run_optimization(self):
        """Run the dispatch optimization algorithm"""
        # Disable button during processing
        self.opt_run_button.config(state=tk.DISABLED)
        self.opt_metrics_text.delete(1.0, tk.END)
        self.opt_metrics_text.insert(tk.END, "Starting optimization...\n")
        
        def optimization_thread():
            try:
                # Get table names
                tech_table = self.opt_tech_table.get().strip()
                cal_table = self.opt_cal_table.get().strip()
                dispatch_table = self.opt_dispatch_table.get().strip()
                
                self.opt_metrics_text.insert(tk.END, f"\n📊 Loading data from Databricks...\n")
                self.opt_metrics_text.insert(tk.END, f"  - Technicians: {tech_table}\n")
                self.opt_metrics_text.insert(tk.END, f"  - Calendar: {cal_table}\n")
                self.opt_metrics_text.insert(tk.END, f"  - Dispatches: {dispatch_table}\n\n")
                
                # Load data from Databricks
                # Check if connection exists, if not try to establish one
                if not self.connection:
                    self.opt_metrics_text.insert(tk.END, "No active connection found. Attempting to connect...\n")
                    
                    # Check if we have saved credentials
                    server = self.server_hostname.get().strip()
                    http_path = self.http_path.get().strip()
                    token = self.access_token.get().strip()
                    
                    if not server or not http_path or not token:
                        self.opt_metrics_text.insert(tk.END, "❌ Error: No Databricks credentials found\n")
                        self.opt_metrics_text.insert(tk.END, "Please configure connection in Connection tab.\n")
                        self.opt_metrics_text.insert(tk.END, "Required fields: Server Hostname, HTTP Path, Access Token\n")
                        return
                    
                    # Try to establish connection
                    try:
                        self.opt_metrics_text.insert(tk.END, f"Connecting to {server}...\n")
                        self.connection = sql.connect(
                            server_hostname=server,
                            http_path=http_path,
                            access_token=token
                        )
                        self.opt_metrics_text.insert(tk.END, "✓ Connected successfully!\n\n")
                    except Exception as e:
                        self.opt_metrics_text.insert(tk.END, f"❌ Connection failed: {str(e)}\n")
                        self.opt_metrics_text.insert(tk.END, "Please verify your credentials in Connection tab.\n")
                        return
                
                cursor = self.connection.cursor()
                
                # Load technicians
                self.opt_metrics_text.insert(tk.END, "Loading technicians...\n")
                cursor.execute(f"SELECT * FROM {tech_table}")
                tech_columns = [desc[0] for desc in cursor.description]
                technicians = [dict(zip(tech_columns, row)) for row in cursor.fetchall()]
                self.opt_metrics_text.insert(tk.END, f"✓ Loaded {len(technicians)} technicians\n")
                
                # Load calendar
                self.opt_metrics_text.insert(tk.END, "Loading calendar data...\n")
                cursor.execute(f"SELECT * FROM {cal_table}")
                cal_columns = [desc[0] for desc in cursor.description]
                calendar_data = [dict(zip(cal_columns, row)) for row in cursor.fetchall()]
                self.opt_metrics_text.insert(tk.END, f"✓ Loaded {len(calendar_data)} calendar entries\n")
                
                # Load dispatches
                self.opt_metrics_text.insert(tk.END, "Loading dispatches...\n")
                cursor.execute(f"SELECT * FROM {dispatch_table}")
                dispatch_columns = [desc[0] for desc in cursor.description]
                dispatches = [dict(zip(dispatch_columns, row)) for row in cursor.fetchall()]
                self.opt_metrics_text.insert(tk.END, f"✓ Loaded {len(dispatches)} dispatches\n\n")
                
                cursor.close()
                
                # Run optimization
                self.opt_metrics_text.insert(tk.END, "🔄 Running optimization algorithm...\n\n")
                optimized_results, metrics = self.optimize_dispatch_assignments(
                    dispatches, technicians, calendar_data
                )
                
                # Store results
                self.optimized_results = optimized_results
                
                # Display metrics
                self.opt_metrics_text.insert(tk.END, "=" * 50 + "\n")
                self.opt_metrics_text.insert(tk.END, "OPTIMIZATION COMPLETE\n")
                self.opt_metrics_text.insert(tk.END, "=" * 50 + "\n\n")
                
                self.opt_metrics_text.insert(tk.END, f"Total Dispatches: {metrics['total_dispatches']}\n")
                self.opt_metrics_text.insert(tk.END, f"Skill Matches Found: {metrics['skill_matches']}\n")
                self.opt_metrics_text.insert(tk.END, f"Skill Match Rate: {metrics['skill_match_rate']}%\n\n")
                
                self.opt_metrics_text.insert(tk.END, f"Average Distance: {metrics['avg_distance']} miles\n")
                self.opt_metrics_text.insert(tk.END, f"Calendar Checks: {metrics['calendar_checks']}\n")
                self.opt_metrics_text.insert(tk.END, f"Overloaded Technicians: {metrics['overloaded_techs']}\n\n")
                
                # Calculate improvements vs current assignments
                skill_mismatches_before = sum(1 for d in dispatches 
                                             for t in technicians 
                                             if d.get('Assigned_technician_id') == t['Technician_id'] 
                                             and d['Required_skill'] != t['Primary_skill'])
                
                skill_match_improvement = metrics['skill_matches'] - (len(dispatches) - skill_mismatches_before)
                
                self.opt_metrics_text.insert(tk.END, "IMPROVEMENTS:\n")
                self.opt_metrics_text.insert(tk.END, f"✓ Skill matching improved\n")
                self.opt_metrics_text.insert(tk.END, f"✓ Distance optimization applied\n")
                self.opt_metrics_text.insert(tk.END, f"✓ Workload balanced across {len(technicians)} technicians\n")
                self.opt_metrics_text.insert(tk.END, f"✓ Calendar availability verified\n\n")
                
                self.opt_metrics_text.insert(tk.END, "=" * 50 + "\n")
                
                # Display results in table
                self.opt_results_tree.delete(*self.opt_results_tree.get_children())
                
                # Store display data for filtering
                self.optimized_results_display = []
                
                for result in optimized_results:
                    row_values = (
                        result['Dispatch_id'],
                        result['Required_skill'],
                        result['Customer_city_state'],
                        result['Original_technician'],
                        result['Optimized_technician'],
                        result['Distance_mi'] if result['Distance_mi'] else 'N/A',
                        result['Workload_pct'] if result['Workload_pct'] else 'N/A',
                        result['Match_found']
                    )
                    self.optimized_results_display.append(row_values)
                    self.opt_results_tree.insert('', tk.END, values=row_values)
                
                # Clear any existing filters
                for entry in self.filter_entries.values():
                    entry.delete(0, tk.END)
                
                # Enable export buttons
                self.opt_export_button.config(state=tk.NORMAL)
                self.opt_update_button.config(state=tk.NORMAL)
                
            except Exception as e:
                self.opt_metrics_text.insert(tk.END, f"\n❌ Error: {str(e)}\n")
                import traceback
                self.opt_metrics_text.insert(tk.END, f"\n{traceback.format_exc()}\n")
            finally:
                self.opt_run_button.config(state=tk.NORMAL)
        
        # Run in thread to keep UI responsive
        thread = threading.Thread(target=optimization_thread)
        thread.daemon = True
        thread.start()
    
    def export_optimization_results(self):
        """Export optimization results to CSV"""
        if not self.optimized_results:
            messagebox.showwarning("No Results", "No optimization results to export.")
            return
        
        # Ask user for file location
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile=f"optimized_dispatches_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        )
        
        if file_path:
            try:
                import csv
                with open(file_path, 'w', newline='') as f:
                    if self.optimized_results:
                        writer = csv.DictWriter(f, fieldnames=self.optimized_results[0].keys())
                        writer.writeheader()
                        writer.writerows(self.optimized_results)
                
                messagebox.showinfo("Success", f"Results exported to:\n{file_path}")
            except Exception as e:
                messagebox.showerror("Export Error", f"Failed to export results:\n{str(e)}")
    
    def update_databricks_with_results(self):
        """Update the Databricks table with optimized technician assignments"""
        if not self.optimized_results:
            messagebox.showwarning("No Results", "No optimization results to update.")
            return
        
        # Confirm with user
        response = messagebox.askyesno(
            "Confirm Update",
            f"This will update {len(self.optimized_results)} dispatch records in Databricks.\n\n"
            "The 'Optimized_technician_id' field will be populated with the optimized assignments.\n\n"
            "Continue?"
        )
        
        if not response:
            return
        
        try:
            dispatch_table = self.opt_dispatch_table.get().strip()
            cursor = self.connection.cursor()
            
            # Update each dispatch with optimized technician
            updated_count = 0
            for result in self.optimized_results:
                if result['Optimized_technician']:
                    update_query = f"""
                    UPDATE {dispatch_table}
                    SET Optimized_technician_id = '{result['Optimized_technician']}',
                        Optimization_status = 'completed',
                        Optimization_timestamp = current_timestamp()
                    WHERE Dispatch_id = {result['Dispatch_id']}
                    """
                    cursor.execute(update_query)
                    updated_count += 1
            
            cursor.close()
            
            messagebox.showinfo("Success", 
                              f"Successfully updated {updated_count} dispatch records in Databricks!")
            
        except Exception as e:
            messagebox.showerror("Update Error", 
                               f"Failed to update Databricks:\n{str(e)}")

def main():
    # Hide console window on Windows if running from console
    if sys.platform == 'win32':
        try:
            import ctypes
            # Try to hide console window (only works if there is one)
            console_window = ctypes.windll.kernel32.GetConsoleWindow()
            if console_window:
                ctypes.windll.user32.ShowWindow(console_window, 0)
        except:
            pass  # If hiding fails, continue anyway
    
    root = tk.Tk()
    app = DatabricksGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()

