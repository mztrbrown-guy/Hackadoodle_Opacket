# Databricks GUI Client

A modern, user-friendly GUI application for accessing and managing Databricks workspaces.

## Features

- **Connection Management**: Configure and test connections to Databricks SQL and Workspace APIs
- **SQL Query Execution**: Execute SQL queries and view results in a table format
- **Smart Dispatch Query Tab**: Specialized interface for querying Smart Dispatch tables with search filters
- **Cluster Management**: View and monitor Databricks clusters
- **Job Management**: Browse and monitor Databricks jobs
- **Workspace Browser**: Navigate through your Databricks workspace files and notebooks
- **No Console Window**: Launcher files run the GUI without showing a console/terminal window

## Installation

1. Install Python 3.8 or higher

2. Install required dependencies:
```bash
pip install -r requirements.txt
```

## Configuration

### Getting Your Databricks Credentials

1. **Server Hostname**: Your Databricks workspace URL (e.g., `adb-1234567890123456.7.azuredatabricks.net`)

2. **HTTP Path**: The HTTP path for your SQL endpoint. You can find this in:
   - Databricks workspace → SQL Warehouses → Select your warehouse → Connection details → JDBC/ODBC → HTTP Path

3. **Access Token**: 
   - Go to User Settings → Access Tokens
   - Generate a new token or use an existing one

4. **Workspace URL**: Your Databricks workspace URL (e.g., `https://adb-1234567890123456.7.azuredatabricks.net`)

## Usage

### Launching the Application

You have several options to launch the GUI:

**Option 1: Double-click launcher (Recommended - No Console)**
- Double-click `launch_gui.pyw` (Windows will use Python to run it without showing a console)
- Or double-click `launch_gui.bat` (Windows batch file)
- Or double-click `launch_gui.vbs` (VBScript launcher - completely silent)

**Option 2: Command Line**
```bash
python databricks_gui.py
```

**Option 3: Direct PythonW (Windows - No Console)**
```bash
pythonw databricks_gui.py
```

The launcher files (`launch_gui.pyw`, `launch_gui.bat`, `launch_gui.vbs`) will start the GUI without showing a console window.

### First Time Setup

1. Navigate to the **Connection** tab and enter your Databricks credentials

2. Click **Save Configuration** to save your settings (stored in `databricks_config.json`)

3. Test your connections using the **Test SQL Connection** and **Test Workspace Connection** buttons

4. Use the other tabs to:
   - Execute SQL queries
   - View and manage clusters
   - Monitor jobs
   - Browse your workspace

## Features by Tab

### Connection Tab
- Configure connection settings
- Save/load configuration
- Test SQL and Workspace API connections
- View connection status logs

### SQL Query Tab
- Write and execute SQL queries
- View results in a table format
- Load queries from `.sql` files
- Clear query and results

### Clusters Tab
- View all clusters in your workspace
- See cluster status, Spark version, node types, and worker counts
- Refresh cluster list

### Jobs Tab
- View all jobs in your workspace
- See job names, creation times, creators, and schedules
- Refresh job list

### Workspace Tab
- Browse your Databricks workspace
- Navigate through directories and notebooks
- View file types, sizes, and modification dates
- Double-click directories to navigate into them

### Smart Dispatch Query Tab
- Select one or more Smart Dispatch tables to query
- Search across tables with flexible filters
- Query types: Search (LIKE), Exact Match, Show All, Show Schema
- View results in separate tabs for each table
- Export all results to CSV
- Search in specific columns or across all columns

## Security Note

Your access token is stored in `databricks_config.json` in plain text. Make sure to:
- Keep this file secure
- Add it to `.gitignore` if using version control
- Never share your access token

## Troubleshooting

- **Connection Errors**: Verify your credentials are correct and your token hasn't expired
- **SQL Query Errors**: Ensure you're connected to the correct SQL warehouse and have proper permissions
- **Workspace Errors**: Check that your workspace URL is correct and includes the protocol (https://)

## Requirements

- Python 3.8+
- tkinter (usually included with Python)
- databricks-sql-connector
- databricks-sdk

## License

This project is provided as-is for personal and commercial use.

