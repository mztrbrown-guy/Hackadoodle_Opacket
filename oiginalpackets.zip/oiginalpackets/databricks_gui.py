import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog, simpledialog
import json
import os
import sys
from databricks import sql
from databricks.sdk import WorkspaceClient
import threading
from datetime import datetime
import matplotlib
matplotlib.use('TkAgg')
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

class DatabricksGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Databricks GUI Client")
        self.root.geometry("1300x850")  # Compact size with side-by-side layout
        self.root.configure(bg='#f0f0f0')
        
        # Connection variables
        self.server_hostname = tk.StringVar()
        self.http_path = tk.StringVar()
        self.access_token = tk.StringVar()
        self.workspace_url = tk.StringVar()
        self.connection = None
        self.workspace_client = None
        
        # Profile management
        self.current_profile = tk.StringVar()
        self.profiles = {}
        
        # Load saved configuration
        self.config_file = "databricks_config.json"
        self.load_config()
        
        # Initialize ticket data for map
        self.ticket_data = {}
        
        self.create_widgets()
        
    def load_config(self):
        """Load saved configuration from file"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    
                    # Check if it's the new profile-based format
                    if 'profiles' in config:
                        self.profiles = config.get('profiles', {})
                        current_profile_name = config.get('current_profile', '')
                        
                        # If we have profiles, load the current one
                        if current_profile_name and current_profile_name in self.profiles:
                            self.current_profile.set(current_profile_name)
                            profile = self.profiles[current_profile_name]
                            self.server_hostname.set(profile.get('server_hostname', '').strip())
                            self.http_path.set(profile.get('http_path', '').strip())
                            self.access_token.set(profile.get('access_token', '').strip())
                            self.workspace_url.set(profile.get('workspace_url', '').strip())
                        elif self.profiles:
                            # Load first profile if current_profile not set
                            first_profile = list(self.profiles.keys())[0]
                            self.current_profile.set(first_profile)
                            profile = self.profiles[first_profile]
                            self.server_hostname.set(profile.get('server_hostname', '').strip())
                            self.http_path.set(profile.get('http_path', '').strip())
                            self.access_token.set(profile.get('access_token', '').strip())
                            self.workspace_url.set(profile.get('workspace_url', '').strip())
                    else:
                        # Legacy format - migrate to profile format
                        profile_name = "Default"
                        self.profiles[profile_name] = {
                            'server_hostname': config.get('server_hostname', '').strip(),
                            'http_path': config.get('http_path', '').strip(),
                            'access_token': config.get('access_token', '').strip(),
                            'workspace_url': config.get('workspace_url', '').strip()
                        }
                        self.current_profile.set(profile_name)
                        self.server_hostname.set(config.get('server_hostname', '').strip())
                        self.http_path.set(config.get('http_path', '').strip())
                        self.access_token.set(config.get('access_token', '').strip())
                        self.workspace_url.set(config.get('workspace_url', '').strip())
                        # Save in new format
                        self.save_all_profiles()
                
                # If no profiles exist, create a default one
                if not self.profiles:
                    profile_name = "Default"
                    self.profiles[profile_name] = {
                        'server_hostname': '',
                        'http_path': '',
                        'access_token': '',
                        'workspace_url': ''
                    }
                    self.current_profile.set(profile_name)
            except Exception as e:
                print(f"Error loading config: {e}")
                # Create default profile on error
                if not self.profiles:
                    profile_name = "Default"
                    self.profiles[profile_name] = {
                        'server_hostname': '',
                        'http_path': '',
                        'access_token': '',
                        'workspace_url': ''
                    }
                    self.current_profile.set(profile_name)
    
    def save_all_profiles(self):
        """Save all profiles to file"""
        config = {
            'current_profile': self.current_profile.get(),
            'profiles': self.profiles
        }
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            return True
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save config: {e}")
            return False
    
    def save_config(self):
        """Save current configuration as a profile"""
        profile_name = self.current_profile.get().strip()
        
        if not profile_name:
            # Ask for profile name
            profile_name = simpledialog.askstring(
                "Profile Name",
                "Enter a name for this profile:",
                initialvalue="Profile 1"
            )
            if not profile_name:
                messagebox.showwarning("Warning", "Profile name is required")
                return False
            self.current_profile.set(profile_name)
        
        # Save current values to profile
        self.profiles[profile_name] = {
            'server_hostname': self.server_hostname.get().strip(),
            'http_path': self.http_path.get().strip(),
            'access_token': self.access_token.get().strip(),
            'workspace_url': self.workspace_url.get().strip()
        }
        
        # Save all profiles
        if self.save_all_profiles():
            messagebox.showinfo("Success", f"Configuration saved as profile: {profile_name}")
            # Update profile dropdown
            if hasattr(self, 'profile_combo'):
                self.update_profile_dropdown()
            return True
        return False
    
    def load_profile(self, profile_name):
        """Load a profile"""
        if profile_name in self.profiles:
            profile = self.profiles[profile_name]
            self.server_hostname.set(profile.get('server_hostname', '').strip())
            self.http_path.set(profile.get('http_path', '').strip())
            self.access_token.set(profile.get('access_token', '').strip())
            self.workspace_url.set(profile.get('workspace_url', '').strip())
            self.current_profile.set(profile_name)
            self.save_all_profiles()  # Update current_profile in file
            return True
        return False
    
    def delete_profile(self):
        """Delete current profile"""
        profile_name = self.current_profile.get()
        if not profile_name:
            messagebox.showwarning("Warning", "No profile selected")
            return
        
        if len(self.profiles) <= 1:
            messagebox.showwarning("Warning", "Cannot delete the last profile")
            return
        
        # Confirm deletion
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete profile '{profile_name}'?"):
            del self.profiles[profile_name]
            
            # Switch to first available profile
            first_profile = list(self.profiles.keys())[0]
            self.load_profile(first_profile)
            
            # Update dropdown
            self.update_profile_dropdown()
            
            messagebox.showinfo("Success", f"Profile '{profile_name}' deleted")
    
    def create_new_profile(self):
        """Create a new profile"""
        profile_name = simpledialog.askstring(
            "New Profile",
            "Enter a name for the new profile:",
            initialvalue=f"Profile {len(self.profiles) + 1}"
        )
        
        if profile_name and profile_name.strip():
            profile_name = profile_name.strip()
            if profile_name in self.profiles:
                messagebox.showwarning("Warning", f"Profile '{profile_name}' already exists")
                return
            
            # Create empty profile
            self.profiles[profile_name] = {
                'server_hostname': '',
                'http_path': '',
                'access_token': '',
                'workspace_url': ''
            }
            
            # Switch to new profile
            self.load_profile(profile_name)
            self.update_profile_dropdown()
    
    def update_profile_dropdown(self):
        """Update the profile dropdown with current profiles"""
        if hasattr(self, 'profile_combo'):
            current = self.current_profile.get()
            self.profile_combo['values'] = list(self.profiles.keys())
            self.profile_combo.set(current)
    
    def get_access_token(self):
        """Get access token with whitespace stripped"""
        return self.access_token.get().strip()
    
    def on_profile_selected(self, event=None):
        """Handle profile selection change"""
        profile_name = self.current_profile.get()
        if profile_name:
            self.load_profile(profile_name)
    
    def create_widgets(self):
        """Create the main GUI widgets"""
        # Create notebook (tabbed interface)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Connection Tab
        self.connection_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.connection_frame, text="Connection")
        self.create_connection_tab()
        
        # SQL Query Tab
        self.sql_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.sql_frame, text="SQL Query")
        self.create_sql_tab()
        
        # Smart Dispatch Query Tab
        self.smart_dispatch_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.smart_dispatch_frame, text="Smart Dispatch Query")
        self.create_smart_dispatch_tab()
        
        # Dispatch History Tab
        self.dispatch_history_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.dispatch_history_frame, text="Dispatch History")
        self.create_dispatch_history_tab()
    
    def create_connection_tab(self):
        """Create connection configuration tab"""
        # Profile management frame
        profile_frame = ttk.LabelFrame(self.connection_frame, text="Profile Management", padding=10)
        profile_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Profile dropdown
        ttk.Label(profile_frame, text="Profile:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.profile_combo = ttk.Combobox(profile_frame, textvariable=self.current_profile, width=30, state='readonly')
        self.profile_combo.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        self.profile_combo.bind('<<ComboboxSelected>>', self.on_profile_selected)
        
        # Profile buttons
        profile_buttons = ttk.Frame(profile_frame)
        profile_buttons.grid(row=0, column=2, padx=10, pady=5)
        
        ttk.Button(profile_buttons, text="New Profile", command=self.create_new_profile).pack(side=tk.LEFT, padx=2)
        ttk.Button(profile_buttons, text="Delete Profile", command=self.delete_profile).pack(side=tk.LEFT, padx=2)
        
        # Update dropdown with existing profiles
        self.update_profile_dropdown()
        
        # Connection settings frame
        settings_frame = ttk.LabelFrame(self.connection_frame, text="Connection Settings", padding=20)
        settings_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Server Hostname
        ttk.Label(settings_frame, text="Server Hostname:").grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Entry(settings_frame, textvariable=self.server_hostname, width=50).grid(row=0, column=1, pady=5, padx=10)
        
        # HTTP Path
        ttk.Label(settings_frame, text="HTTP Path:").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(settings_frame, textvariable=self.http_path, width=50).grid(row=1, column=1, pady=5, padx=10)
        
        # Access Token
        ttk.Label(settings_frame, text="Access Token:").grid(row=2, column=0, sticky=tk.W, pady=5)
        token_entry = ttk.Entry(settings_frame, textvariable=self.access_token, width=50, show="*")
        token_entry.grid(row=2, column=1, pady=5, padx=10)
        
        # Workspace URL (for Workspace API)
        ttk.Label(settings_frame, text="Workspace URL:").grid(row=3, column=0, sticky=tk.W, pady=5)
        ttk.Entry(settings_frame, textvariable=self.workspace_url, width=50).grid(row=3, column=1, pady=5, padx=10)
        
        # Buttons frame
        button_frame = ttk.Frame(settings_frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=20)
        
        ttk.Button(button_frame, text="Save Configuration", command=self.save_config).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Test SQL Connection", command=self.test_sql_connection).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Test Workspace Connection", command=self.test_workspace_connection).pack(side=tk.LEFT, padx=5)
        
        # Status frame
        status_frame = ttk.LabelFrame(self.connection_frame, text="Connection Status", padding=10)
        status_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.status_text = scrolledtext.ScrolledText(status_frame, height=10, wrap=tk.WORD)
        self.status_text.pack(fill=tk.BOTH, expand=True)
        self.status_text.insert(tk.END, "Ready to connect. Please configure your connection settings.\n")
        self.status_text.config(state=tk.DISABLED)
    
    def create_sql_tab(self):
        """Create SQL query tab"""
        # Query input frame
        query_frame = ttk.LabelFrame(self.sql_frame, text="SQL Query", padding=10)
        query_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.sql_query_text = scrolledtext.ScrolledText(query_frame, height=10, wrap=tk.NONE, font=('Consolas', 10))
        self.sql_query_text.pack(fill=tk.BOTH, expand=True)
        
        # Buttons
        button_frame = ttk.Frame(query_frame)
        button_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(button_frame, text="Execute Query", command=self.execute_sql_query).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear", command=lambda: self.sql_query_text.delete(1.0, tk.END)).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Load Query from File", command=self.load_query_file).pack(side=tk.LEFT, padx=5)
        
        # Search/Filter frame (moved from Smart Dispatch Query tab)
        filter_frame = ttk.LabelFrame(self.sql_frame, text="Search Filters", padding=10)
        filter_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        # Search term
        ttk.Label(filter_frame, text="Search Term:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.search_term_var = tk.StringVar()
        search_entry = ttk.Entry(filter_frame, textvariable=self.search_term_var, width=40)
        search_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # Column to search (optional)
        ttk.Label(filter_frame, text="Column (optional):").grid(row=0, column=2, sticky=tk.W, padx=5, pady=5)
        self.search_column_var = tk.StringVar()
        ttk.Entry(filter_frame, textvariable=self.search_column_var, width=30).grid(row=0, column=3, padx=5, pady=5)
        
        # Limit results
        ttk.Label(filter_frame, text="Limit:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.limit_var = tk.StringVar(value="100")
        ttk.Entry(filter_frame, textvariable=self.limit_var, width=10).grid(row=1, column=1, sticky=tk.W, padx=5, pady=5)
        
        # Query type selection
        ttk.Label(filter_frame, text="Query Type:").grid(row=1, column=2, sticky=tk.W, padx=5, pady=5)
        self.query_type_var = tk.StringVar(value="all")
        query_types = [
            ("Search (LIKE)", "search"),
            ("Exact Match", "exact"),
            ("Show All", "all"),
            ("Show Schema", "schema")
        ]
        for i, (text, value) in enumerate(query_types):
            rb = ttk.Radiobutton(filter_frame, text=text, variable=self.query_type_var, value=value)
            rb.grid(row=1, column=3+i, padx=5, pady=5)
        
        # Results frame
        results_frame = ttk.LabelFrame(self.sql_frame, text="Query Results", padding=10)
        results_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Treeview for results
        self.sql_results_tree = ttk.Treeview(results_frame)
        self.sql_results_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        # Scrollbar for treeview
        sql_scrollbar = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.sql_results_tree.yview)
        sql_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.sql_results_tree.configure(yscrollcommand=sql_scrollbar.set)
        
        # Status label
        self.sql_status_label = ttk.Label(self.sql_frame, text="Ready to execute queries")
        self.sql_status_label.pack(pady=5)
    
    def create_smart_dispatch_tab(self):
        """Create Smart Dispatch query tab with table selection and search"""
        # Table definitions (dispatch_history moved to separate tab)
        self.smart_dispatch_tables = {
            'technician_calendar': 'hackathon.hackathon_the_original_packet.smart_dispatch_technician_calendar',
            'technicians': 'hackathon.hackathon_the_original_packet.smart_dispatch_technicians',
            'current_dispatches': 'hackathon.hackathon_the_original_packet.smartdispatchcurrentdispatches'
        }
        
        # Table for combined technicians view
        self.technicians_combined_table = {
            'technicians_combined': {
                'technicians': 'hackathon.hackathon_the_original_packet.smart_dispatch_technicians',
                'technician_calendar': 'hackathon.hackathon_the_original_packet.smart_dispatch_technician_calendar'
            }
        }
        
        # Initialize table_vars - all tables selected by default
        self.table_vars = {}
        # Add combined technicians view (selected by default)
        self.table_vars['technicians_combined'] = tk.BooleanVar(value=True)
        # Add individual tables (excluding dispatch_history and current_dispatches)
        for key, table_name in self.smart_dispatch_tables.items():
            if key != 'current_dispatches':  # Will be shown separately
                self.table_vars[key] = tk.BooleanVar(value=True)
        
        # Main container with left and right panels
        main_container = ttk.Frame(self.smart_dispatch_frame)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        main_container.grid_rowconfigure(0, weight=1)
        main_container.grid_columnconfigure(0, weight=2)  # Left side: 65%
        main_container.grid_columnconfigure(1, weight=1)  # Right side: 35%
        
        # LEFT PANEL: Tickets + Technician Details
        left_panel = ttk.Frame(main_container)
        left_panel.grid(row=0, column=0, sticky='nsew', padx=(0, 3))
        
        # Tickets section (top of left panel)
        tickets_frame = ttk.LabelFrame(left_panel, text="Tickets", padding=5)
        tickets_frame.pack(fill=tk.X, pady=(0, 5))
        tickets_frame.grid_rowconfigure(1, weight=1)
        tickets_frame.grid_columnconfigure(0, weight=1)
        
        # Tickets toolbar
        tickets_toolbar = ttk.Frame(tickets_frame)
        tickets_toolbar.grid(row=0, column=0, sticky='ew', pady=(0, 3))
        
        ttk.Button(tickets_toolbar, text="Load Tickets", command=self.load_dispatches).pack(side=tk.LEFT, padx=3)
        ttk.Button(tickets_toolbar, text="Refresh", command=self.load_dispatches).pack(side=tk.LEFT, padx=3)
        
        # Tickets results
        tickets_results_frame = ttk.Frame(tickets_frame)
        tickets_results_frame.grid(row=1, column=0, sticky='nsew')
        tickets_results_frame.grid_rowconfigure(0, weight=1)
        tickets_results_frame.grid_columnconfigure(0, weight=1)
        
        self.dispatches_tree = ttk.Treeview(tickets_results_frame, show='headings', height=4)
        self.dispatches_tree.grid(row=0, column=0, sticky='nsew')
        
        dispatches_scrollbar_v = ttk.Scrollbar(tickets_results_frame, orient=tk.VERTICAL, command=self.dispatches_tree.yview)
        dispatches_scrollbar_h = ttk.Scrollbar(tickets_results_frame, orient=tk.HORIZONTAL, command=self.dispatches_tree.xview)
        dispatches_scrollbar_v.grid(row=0, column=1, sticky='ns')
        dispatches_scrollbar_h.grid(row=1, column=0, sticky='ew')
        self.dispatches_tree.configure(yscrollcommand=dispatches_scrollbar_v.set, xscrollcommand=dispatches_scrollbar_h.set)
        
        # Technician Details section (bottom of left panel)
        tech_details_frame = ttk.LabelFrame(left_panel, text="Technician Details", padding=5)
        tech_details_frame.pack(fill=tk.BOTH, expand=True)
        tech_details_frame.grid_rowconfigure(0, weight=1)
        tech_details_frame.grid_columnconfigure(0, weight=0)  # Left side: filters (fixed width)
        tech_details_frame.grid_columnconfigure(1, weight=1)  # Right side: results (expand)
        
        # LEFT SIDE: Filters and buttons
        filters_subframe = ttk.Frame(tech_details_frame)
        filters_subframe.grid(row=0, column=0, sticky='nsew', padx=(0, 5))
        
        # Date filter (default to today)
        today = datetime.now().strftime("%Y-%m-%d")
        ttk.Label(filters_subframe, text="Date:").grid(row=0, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_date_var = tk.StringVar(value=today)
        date_entry = ttk.Entry(filters_subframe, textvariable=self.filter_date_var, width=15)
        date_entry.grid(row=1, column=0, padx=3, pady=(0, 3), sticky='ew')
        ttk.Button(filters_subframe, text="Today", command=lambda: self.filter_date_var.set(today)).grid(row=2, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Technician name filter
        ttk.Label(filters_subframe, text="Technician:").grid(row=3, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_technician_var = tk.StringVar()
        self.filter_technician_combo = ttk.Combobox(filters_subframe, textvariable=self.filter_technician_var, width=15, state='readonly')
        self.filter_technician_combo.grid(row=4, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # City/State filter
        ttk.Label(filters_subframe, text="City/State:").grid(row=5, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_location_var = tk.StringVar()
        self.filter_location_combo = ttk.Combobox(filters_subframe, textvariable=self.filter_location_var, width=15, state='readonly')
        self.filter_location_combo.grid(row=6, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Available filter
        ttk.Label(filters_subframe, text="Available:").grid(row=7, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_available_var = tk.StringVar()
        available_combo = ttk.Combobox(filters_subframe, textvariable=self.filter_available_var, width=15, state='readonly')
        available_combo['values'] = ('All', 'Available (1)', 'Not Available (0)')
        available_combo.current(0)
        available_combo.grid(row=8, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Reason filter
        ttk.Label(filters_subframe, text="Reason:").grid(row=9, column=0, sticky=tk.W, padx=3, pady=3)
        self.filter_reason_var = tk.StringVar()
        reason_combo = ttk.Combobox(filters_subframe, textvariable=self.filter_reason_var, width=15, state='readonly')
        reason_combo['values'] = ('Hide (default)', 'Show All', 'Show Non-Null Only')
        reason_combo.current(0)
        reason_combo.grid(row=10, column=0, padx=3, pady=(0, 5), sticky='ew')
        
        # Show reasons checkbox
        self.show_reasons_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(filters_subframe, text="Show Reason Column", variable=self.show_reasons_var).grid(row=11, column=0, padx=3, pady=(0, 10), sticky='w')
        
        # Buttons frame
        button_frame = ttk.Frame(filters_subframe)
        button_frame.grid(row=12, column=0, pady=5, sticky='ew')
        
        ttk.Button(button_frame, text="Execute Queries", command=self.execute_smart_dispatch_queries).pack(fill=tk.X, padx=3, pady=2)
        ttk.Button(button_frame, text="Clear Results", command=self.clear_smart_dispatch_results).pack(fill=tk.X, padx=3, pady=2)
        ttk.Button(button_frame, text="Export Results", command=self.export_smart_dispatch_results).pack(fill=tk.X, padx=3, pady=2)
        
        # RIGHT SIDE: Technician results frame (table)
        self.details_results_frame = ttk.Frame(tech_details_frame)
        self.details_results_frame.grid(row=0, column=1, sticky='nsew')
        self.details_results_frame.grid_rowconfigure(0, weight=1)
        self.details_results_frame.grid_columnconfigure(0, weight=1)
        
        # RIGHT PANEL: Location Map (full height)
        map_frame = ttk.LabelFrame(main_container, text="Location Map", padding=5)
        map_frame.grid(row=0, column=1, sticky='nsew', padx=(3, 0))
        map_frame.grid_rowconfigure(0, weight=1)
        map_frame.grid_columnconfigure(0, weight=1)
        
        # Map display
        self.map_display_frame = ttk.Frame(map_frame)
        self.map_display_frame.grid(row=0, column=0, sticky='nsew')
        self.map_display_frame.grid_rowconfigure(0, weight=1)
        self.map_display_frame.grid_columnconfigure(0, weight=1)
        
        # Map status label
        self.map_status_label = ttk.Label(map_frame, text="Load tickets and technicians to display map", font=('TkDefaultFont', 8))
        self.map_status_label.grid(row=1, column=0, pady=2)
        
        # Status label
        self.smart_dispatch_status_label = ttk.Label(self.smart_dispatch_frame, text="Ready to query Smart Dispatch tables")
        self.smart_dispatch_status_label.pack(pady=5)
        
        # Store results for each table
        self.smart_dispatch_results = {}
    
    def clear_smart_dispatch_results(self):
        """Clear all results"""
        # Clear details frame
        for widget in self.details_results_frame.winfo_children():
            widget.destroy()
        # Clear tickets
        for item in self.dispatches_tree.get_children():
            self.dispatches_tree.delete(item)
        # Clear map
        for widget in self.map_display_frame.winfo_children():
            widget.destroy()
        self.map_status_label.config(text="Load tickets and technicians to display map")
        self.smart_dispatch_results = {}
        self.smart_dispatch_status_label.config(text="Results cleared")
    
    def execute_smart_dispatch_queries(self):
        """Execute queries for all tables (all selected by default)"""
        # Get all available tables (all are selected by default)
        selected_tables = list(self.table_vars.keys())
        
        query_type = self.query_type_var.get()
        search_term = self.search_term_var.get().strip()
        
        # Validate search term for search/exact queries
        if query_type in ["search", "exact"] and not search_term:
            messagebox.showwarning("Warning", "Please enter a search term for search/exact queries")
            return
        
        def execute():
            try:
                self.smart_dispatch_status_label.config(text="Executing queries...")
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                
                search_column = self.search_column_var.get().strip()
                limit = self.limit_var.get().strip() or "100"
                
                # Escape single quotes in search term to prevent SQL injection
                search_term_escaped = search_term.replace("'", "''")
                
                # Clear previous results
                self.clear_smart_dispatch_results()
                
                for table_key in selected_tables:
                    # Handle combined technicians view
                    if table_key == 'technicians_combined':
                        try:
                            # Build JOIN query for technicians and technician_calendar
                            tech_table = self.technicians_combined_table['technicians_combined']['technicians']
                            cal_table = self.technicians_combined_table['technicians_combined']['technician_calendar']
                            
                            # Get actual column names from schema
                            cursor.execute(f"DESCRIBE {tech_table}")
                            tech_columns_info = cursor.fetchall()
                            tech_columns = {col[0].lower(): col[0] for col in tech_columns_info}  # Map lowercase to actual
                            
                            cursor.execute(f"DESCRIBE {cal_table}")
                            cal_columns_info = cursor.fetchall()
                            cal_columns = {col[0].lower(): col[0] for col in cal_columns_info}  # Map lowercase to actual
                            
                            # Find actual column names (case-insensitive matching)
                            def find_column(col_dict, possible_names):
                                for name in possible_names:
                                    if name.lower() in col_dict:
                                        return col_dict[name.lower()]
                                return None
                            
                            tech_id_col = find_column(tech_columns, ['technician_id', 'Technician_id', 'Technician_ID'])
                            tech_name_col = find_column(tech_columns, ['technician_name', 'Technician_name', 'Name', 'name'])
                            # Search for skill column with many variations
                            skill_col = find_column(tech_columns, ['skill', 'Skill', 'skills', 'Skills', 'Skillset', 'skillset', 'Skill_set', 'skill_set', 'SkillSet'])
                            
                            # If not found with exact matches, search for any column containing "skill" (case-insensitive)
                            if not skill_col:
                                for col_name in tech_columns.values():
                                    if 'skill' in col_name.lower():
                                        skill_col = col_name
                                        break
                            
                            state_col = find_column(tech_columns, ['state', 'State', 'STATE'])
                            city_col = find_column(tech_columns, ['city', 'City', 'CITY'])
                            lat_col = find_column(tech_columns, ['latitude', 'Latitude', 'lat'])
                            lon_col = find_column(tech_columns, ['longitude', 'Longitude', 'lon', 'lng'])
                            
                            # Also check calendar table for skills if not found in technicians table
                            if not skill_col:
                                skill_col = find_column(cal_columns, ['skill', 'Skill', 'skills', 'Skills', 'Skillset', 'skillset', 'Skill_set', 'skill_set', 'SkillSet'])
                                # If still not found, search for any column containing "skill"
                                if not skill_col:
                                    for col_name in cal_columns.values():
                                        if 'skill' in col_name.lower():
                                            skill_col = col_name
                                            break
                            
                            cal_id_col = find_column(cal_columns, ['technician_id', 'Technician_id', 'Technician_ID'])
                            
                            # Determine which table the skill column is in (if found)
                            skill_table_prefix = None
                            if skill_col:
                                # Check if it's in technicians table
                                if any(skill_col.lower() == col.lower() for col in tech_columns.values()):
                                    skill_table_prefix = "t"
                                # Check if it's in calendar table
                                elif any(skill_col.lower() == col.lower() for col in cal_columns.values()):
                                    skill_table_prefix = "tc"
                            
                            # Find calendar time columns and available column
                            start_time_col = find_column(cal_columns, ['start_time', 'Start_time', 'Start_Time', 'startTime', 'StartTime'])
                            end_time_col = find_column(cal_columns, ['end_time', 'End_time', 'End_Time', 'endTime', 'EndTime'])
                            available_col = find_column(cal_columns, ['available', 'Available', 'AVAILABLE', 'is_available', 'Is_Available'])
                            reason_col = find_column(cal_columns, ['reason', 'Reason', 'REASON', 'reason_text', 'Reason_Text'])
                            
                            # Find date column for filtering
                            date_col = find_column(cal_columns, ['date', 'Date', 'DATE', 'work_date', 'Work_Date', 'calendar_date', 'Calendar_Date'])
                            
                            # Build SELECT clause - organized and simplified for clarity
                            select_parts = []
                            
                            # 0. AVAILABILITY: Dot indicator (will be shown as colored dot, not as column)
                            if available_col:
                                select_parts.append(f"tc.{available_col} AS Available")
                            
                            # 1. DATE: Calendar date (2nd column after Status)
                            if date_col:
                                select_parts.append(f"tc.{date_col} AS Date")
                            
                            # 2. MAX_ASSIGNMENT: Maximum assignments (3rd column)
                            max_assignment_col = find_column(cal_columns, ['max_assignment', 'max_assignments', 'maxassignment'])
                            if max_assignment_col:
                                select_parts.append(f"tc.{max_assignment_col} AS Max_Assignment")
                            
                            # 3. WHO: Technician Name
                            if tech_name_col:
                                select_parts.append(f"t.{tech_name_col} AS Technician_Name")
                            
                            # 4. SKILL: What skill they have
                            if skill_col and skill_table_prefix:
                                select_parts.append(f"{skill_table_prefix}.{skill_col} AS Skill")
                            
                            # 5. WHERE: Location (City, State)
                            if city_col:
                                select_parts.append(f"t.{city_col} AS City")
                            if state_col:
                                select_parts.append(f"t.{state_col} AS State")
                            
                            # 6. EXACT LOCATION: Latitude and Longitude
                            if lat_col:
                                select_parts.append(f"t.{lat_col} AS Latitude")
                            if lon_col:
                                select_parts.append(f"t.{lon_col} AS Longitude")
                            
                            # 7. CALENDAR: Days and Hours (Start Time, End Time)
                            if start_time_col:
                                select_parts.append(f"tc.{start_time_col} AS Start_Time")
                            if end_time_col:
                                select_parts.append(f"tc.{end_time_col} AS End_Time")
                            
                            # 8. REASON: Only include if show_reasons is checked
                            if reason_col and self.show_reasons_var.get():
                                select_parts.append(f"tc.{reason_col} AS Reason")
                            
                            # 9. OTHER CALENDAR FIELDS: Add other relevant calendar fields (excluding already added ones)
                            for cal_col_name in cal_columns.values():
                                # Skip already added columns
                                skip = False
                                if cal_id_col and cal_col_name.lower() == cal_id_col.lower():
                                    skip = True
                                if start_time_col and cal_col_name.lower() == start_time_col.lower():
                                    skip = True
                                if end_time_col and cal_col_name.lower() == end_time_col.lower():
                                    skip = True
                                if available_col and cal_col_name.lower() == available_col.lower():
                                    skip = True
                                if date_col and cal_col_name.lower() == date_col.lower():
                                    skip = True
                                if reason_col and cal_col_name.lower() == reason_col.lower():
                                    skip = True
                                if max_assignment_col and cal_col_name.lower() == max_assignment_col.lower():
                                    skip = True
                                # Skip day_of_week column
                                if 'day_of_week' in cal_col_name.lower():
                                    skip = True
                                
                                if not skip:
                                    select_parts.append(f"tc.{cal_col_name}")
                            
                            # If no columns found at all, fallback to select all
                            if not select_parts:
                                select_parts = ["t.*", "tc.*"]
                            
                            select_clause = ",\n                                    ".join(select_parts)
                            
                            # Build JOIN condition
                            if tech_id_col and cal_id_col:
                                join_condition = f"t.{tech_id_col} = tc.{cal_id_col}"
                            else:
                                # Try to find any matching ID column
                                join_condition = "1=1"  # Fallback to cross join if no ID found
                            
                            # Build WHERE clause for filters
                            where_conditions = []
                            
                            # Date filter (default to today)
                            filter_date = self.filter_date_var.get().strip()
                            if filter_date and date_col:
                                where_conditions.append(f"CAST(tc.{date_col} AS DATE) = CAST('{filter_date}' AS DATE)")
                            
                            # Technician name filter
                            filter_tech = self.filter_technician_var.get().strip()
                            if filter_tech and filter_tech != 'All' and tech_name_col:
                                filter_tech_escaped = filter_tech.replace("'", "''")
                                where_conditions.append(f"t.{tech_name_col} = '{filter_tech_escaped}'")
                            
                            # Location filter (city/state)
                            filter_loc = self.filter_location_var.get().strip()
                            if filter_loc and filter_loc != 'All':
                                filter_loc_escaped = filter_loc.replace("'", "''")
                                if city_col and state_col:
                                    where_conditions.append(f"(t.{city_col} LIKE '%{filter_loc_escaped}%' OR t.{state_col} LIKE '%{filter_loc_escaped}%')")
                                elif city_col:
                                    where_conditions.append(f"t.{city_col} LIKE '%{filter_loc_escaped}%'")
                                elif state_col:
                                    where_conditions.append(f"t.{state_col} LIKE '%{filter_loc_escaped}%'")
                            
                            # Available filter
                            filter_avail = self.filter_available_var.get()
                            if filter_avail and available_col:
                                if filter_avail == 'Available (1)':
                                    where_conditions.append(f"tc.{available_col} = 1")
                                elif filter_avail == 'Not Available (0)':
                                    where_conditions.append(f"tc.{available_col} = 0")
                            
                            # Reason filter (only show non-null if selected)
                            filter_reason = self.filter_reason_var.get()
                            if filter_reason == 'Show Non-Null Only' and reason_col:
                                where_conditions.append(f"tc.{reason_col} IS NOT NULL")
                            
                            where_clause = " AND ".join(where_conditions) if where_conditions else "1=1"
                            
                            # Build query with specific fields
                            if query_type == "schema":
                                # Show schema for both tables
                                query = f"DESCRIBE {tech_table}"
                            elif query_type == "all":
                                query = f"""
                                SELECT 
                                    {select_clause}
                                FROM {tech_table} t
                                LEFT JOIN {cal_table} tc ON {join_condition}
                                WHERE {where_clause}
                                LIMIT {limit}
                                """
                            elif query_type == "exact":
                                if search_column:
                                    query = f"""
                                    SELECT 
                                        {select_clause}
                                    FROM {tech_table} t
                                    LEFT JOIN {cal_table} tc ON {join_condition}
                                    WHERE {search_column} = '{search_term_escaped}' AND {where_clause}
                                    LIMIT {limit}
                                    """
                                else:
                                    # Build search conditions for available text columns from both tables
                                    search_conditions = []
                                    # Technician table columns
                                    if tech_name_col:
                                        search_conditions.append(f"CAST(t.{tech_name_col} AS STRING) = '{search_term_escaped}'")
                                    if skill_col and skill_table_prefix == "t":
                                        search_conditions.append(f"CAST(t.{skill_col} AS STRING) = '{search_term_escaped}'")
                                    if state_col:
                                        search_conditions.append(f"CAST(t.{state_col} AS STRING) = '{search_term_escaped}'")
                                    if city_col:
                                        search_conditions.append(f"CAST(t.{city_col} AS STRING) = '{search_term_escaped}'")
                                    # Calendar table columns (search in all text columns)
                                    for cal_col_name in cal_columns.values():
                                        if cal_id_col and cal_col_name.lower() != cal_id_col.lower():
                                            search_conditions.append(f"CAST(tc.{cal_col_name} AS STRING) = '{search_term_escaped}'")
                                    
                                    where_clause = " OR ".join(search_conditions) if search_conditions else "1=1"
                                    
                                    query = f"""
                                    SELECT 
                                        {select_clause}
                                    FROM {tech_table} t
                                    LEFT JOIN {cal_table} tc ON {join_condition}
                                    WHERE {where_clause}
                                    LIMIT {limit}
                                    """
                            else:  # search (LIKE)
                                if search_column:
                                    query = f"""
                                    SELECT 
                                        {select_clause}
                                    FROM {tech_table} t
                                    LEFT JOIN {cal_table} tc ON {join_condition}
                                    WHERE {search_column} LIKE '%{search_term_escaped}%' AND {where_clause}
                                    LIMIT {limit}
                                    """
                                else:
                                    # Build search conditions for available text columns from both tables
                                    search_conditions = []
                                    # Technician table columns
                                    if tech_name_col:
                                        search_conditions.append(f"CAST(t.{tech_name_col} AS STRING) LIKE '%{search_term_escaped}%'")
                                    if skill_col and skill_table_prefix == "t":
                                        search_conditions.append(f"CAST(t.{skill_col} AS STRING) LIKE '%{search_term_escaped}%'")
                                    if state_col:
                                        search_conditions.append(f"CAST(t.{state_col} AS STRING) LIKE '%{search_term_escaped}%'")
                                    if city_col:
                                        search_conditions.append(f"CAST(t.{city_col} AS STRING) LIKE '%{search_term_escaped}%'")
                                    # Calendar table columns (search in all text columns)
                                    for cal_col_name in cal_columns.values():
                                        if cal_id_col and cal_col_name.lower() != cal_id_col.lower():
                                            search_conditions.append(f"CAST(tc.{cal_col_name} AS STRING) LIKE '%{search_term_escaped}%'")
                                    
                                    search_where = " OR ".join(search_conditions) if search_conditions else "1=1"
                                    
                                    query = f"""
                                    SELECT 
                                        {select_clause}
                                    FROM {tech_table} t
                                    LEFT JOIN {cal_table} tc ON {join_condition}
                                    WHERE ({search_where}) AND {where_clause}
                                    LIMIT {limit}
                                    """
                            
                            cursor.execute(query)
                            columns = [desc[0] for desc in cursor.description] if cursor.description else []
                            
                            # Clear previous details
                            for widget in self.details_results_frame.winfo_children():
                                widget.destroy()
                            
                            # Create treeview for results directly in details frame
                            results_frame = ttk.Frame(self.details_results_frame)
                            results_frame.pack(fill=tk.BOTH, expand=True)
                            results_frame.grid_rowconfigure(0, weight=1)
                            results_frame.grid_columnconfigure(0, weight=1)
                            
                            # Find Available column index for dot display
                            available_col_index = None
                            display_columns = []
                            other_columns = []
                            
                            for i, col in enumerate(columns):
                                if col.lower() == 'available':
                                    available_col_index = i
                                    # Will add "Status" as first column
                                else:
                                    other_columns.append(col)
                            
                            # Put Status (dot) as first column, then other columns
                            if available_col_index is not None:
                                display_columns.append("Status")
                            display_columns.extend(other_columns)
                            
                            tree = ttk.Treeview(results_frame, columns=display_columns, show='headings')
                            
                            # Configure columns with sorting
                            sort_states = {}  # Track sort direction for each column
                            
                            def sort_column(col_name, reverse=False):
                                """Sort treeview by column"""
                                # Get all items
                                items = [(tree.set(item, col_name), item) for item in tree.get_children('')]
                                
                                # Try to sort as numbers if possible
                                try:
                                    items.sort(key=lambda t: float(t[0]) if t[0] else 0, reverse=reverse)
                                except (ValueError, TypeError):
                                    items.sort(key=lambda t: str(t[0]).lower() if t[0] else '', reverse=reverse)
                                
                                # Rearrange items
                                for index, (val, item) in enumerate(items):
                                    tree.move(item, '', index)
                                
                                # Update heading to show sort direction
                                sort_states[col_name] = not reverse
                                direction = " ↓" if reverse else " ↑"
                                tree.heading(col_name, text=col_name + direction, command=lambda c=col_name: sort_column(c, sort_states.get(c, False)))
                            
                            # Configure headings with sorting
                            for i, col in enumerate(display_columns):
                                tree.heading(col, text=col, command=lambda c=col: sort_column(c, sort_states.get(c, False)))
                                # Status column is narrower and centered for the colored dot
                                if col == "Status":
                                    tree.column(col, width=60, anchor=tk.CENTER)
                                else:
                                    tree.column(col, width=150, anchor=tk.W)
                            
                            # Configure tags for colored dots (Status column)
                            tree.tag_configure('available', foreground='#00AA00')  # Green for available (1)
                            tree.tag_configure('unavailable', foreground='#FF0000')  # Red for unavailable (0)
                            
                            # Scrollbars
                            v_scrollbar = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=tree.yview)
                            h_scrollbar = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL, command=tree.xview)
                            tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
                            
                            # Pack widgets
                            tree.grid(row=0, column=0, sticky='nsew')
                            v_scrollbar.grid(row=0, column=1, sticky='ns')
                            h_scrollbar.grid(row=1, column=0, sticky='ew')
                            results_frame.grid_rowconfigure(0, weight=1)
                            results_frame.grid_columnconfigure(0, weight=1)
                            
                            # Fetch and display results
                            rows = cursor.fetchall()
                            
                            # Collect unique values for dropdowns
                            unique_technicians = set()
                            unique_locations = set()
                            
                            for row in rows:
                                # Prepare display row (replace Available with dot)
                                display_row = list(row)
                                
                                if available_col_index is not None:
                                    avail_value = display_row[available_col_index]
                                    # Use bullet with colored tag
                                    dot_value = "●"  # Bullet character
                                    if avail_value == 1 or str(avail_value).lower() == 'true':
                                        tag = 'available'  # Green
                                    else:
                                        tag = 'unavailable'  # Red
                                    
                                    # Reorder: dot first, then other columns
                                    new_display_row = [dot_value]
                                    for i, val in enumerate(display_row):
                                        if i != available_col_index:
                                            new_display_row.append(val)
                                    display_row = new_display_row
                                else:
                                    tag = ''
                                
                                # Collect unique values for dropdowns (use original row indices)
                                if tech_name_col:
                                    tech_idx = columns.index('Technician_Name') if 'Technician_Name' in columns else None
                                    if tech_idx is not None and row[tech_idx]:
                                        unique_technicians.add(str(row[tech_idx]))
                                
                                city_idx = columns.index('City') if 'City' in columns else None
                                state_idx = columns.index('State') if 'State' in columns else None
                                if city_idx is not None or state_idx is not None:
                                    city_val = str(row[city_idx]) if city_idx is not None and row[city_idx] else ''
                                    state_val = str(row[state_idx]) if state_idx is not None and row[state_idx] else ''
                                    location = f"{city_val}, {state_val}".strip(', ')
                                    if location:
                                        unique_locations.add(location)
                                
                                tree.insert('', tk.END, values=display_row, tags=(tag,))
                            
                            # Update dropdowns with unique values
                            if unique_technicians:
                                self.filter_technician_combo['values'] = ['All'] + sorted(unique_technicians)
                                self.filter_technician_combo.current(0)
                            if unique_locations:
                                self.filter_location_combo['values'] = ['All'] + sorted(unique_locations)
                                self.filter_location_combo.current(0)
                            
                            # Store results with lat/lon data for map
                            lat_idx = columns.index('Latitude') if 'Latitude' in columns else None
                            lon_idx = columns.index('Longitude') if 'Longitude' in columns else None
                            tech_name_idx = columns.index('Technician_Name') if 'Technician_Name' in columns else None
                            
                            # Find display column indices (after Status column was added)
                            display_lat_idx = None
                            display_lon_idx = None
                            display_tech_name_idx = None
                            for i, col in enumerate(display_columns):
                                if col == 'Latitude':
                                    display_lat_idx = i
                                elif col == 'Longitude':
                                    display_lon_idx = i
                                elif col == 'Technician_Name':
                                    display_tech_name_idx = i
                            
                            self.smart_dispatch_results[table_key] = {
                                'columns': columns,
                                'rows': rows,
                                'tree': tree,
                                'lat_idx': lat_idx,
                                'lon_idx': lon_idx,
                                'name_idx': tech_name_idx,
                                'display_lat_idx': display_lat_idx,
                                'display_lon_idx': display_lon_idx,
                                'display_tech_name_idx': display_tech_name_idx
                            }
                            
                            # Add click binding to zoom map when technician is selected
                            def on_technician_click(event):
                                selection = tree.selection()
                                if selection:
                                    item = tree.item(selection[0])
                                    values = item['values']
                                    if display_lat_idx is not None and display_lon_idx is not None:
                                        try:
                                            lat = float(values[display_lat_idx])
                                            lon = float(values[display_lon_idx])
                                            tech_name = values[display_tech_name_idx] if display_tech_name_idx is not None else "Selected Technician"
                                            self.zoom_map_to_location(lat, lon, tech_name)
                                        except (ValueError, IndexError, TypeError):
                                            pass
                            
                            tree.bind('<<TreeviewSelect>>', on_technician_click)
                            
                            # Update map after loading technicians (schedule on main thread)
                            self.root.after(100, self.update_map)
                            
                            self.smart_dispatch_status_label.config(text=f"Loaded {len(rows)} technicians")
                            
                        except Exception as e:
                            messagebox.showerror("Error", f"Error querying technicians:\n{str(e)}")
                            self.smart_dispatch_status_label.config(text=f"Error: {str(e)}")
                        continue
                    
                    # Skip other tables - only show combined technicians
                    if table_key in ['current_dispatches', 'technicians', 'technician_calendar']:
                        continue
                    
                    # Handle any other tables (if added in future)
                    table_name = self.smart_dispatch_tables[table_key]
                    
                    # Build query based on type
                    if query_type == "schema":
                        query = f"DESCRIBE {table_name}"
                    elif query_type == "all":
                        query = f"SELECT * FROM {table_name} LIMIT {limit}"
                    elif query_type == "exact":
                        if search_column:
                            query = f"SELECT * FROM {table_name} WHERE {search_column} = '{search_term_escaped}' LIMIT {limit}"
                        else:
                            # Get all columns and search in each for exact match
                            cursor.execute(f"DESCRIBE {table_name}")
                            columns_info = cursor.fetchall()
                            column_names = [col[0] for col in columns_info]
                            
                            # Build OR conditions for all columns
                            conditions = " OR ".join([f"CAST({col} AS STRING) = '{search_term_escaped}'" for col in column_names])
                            query = f"SELECT * FROM {table_name} WHERE {conditions} LIMIT {limit}"
                    else:  # search (LIKE)
                        if search_column:
                            query = f"SELECT * FROM {table_name} WHERE {search_column} LIKE '%{search_term_escaped}%' LIMIT {limit}"
                        else:
                            # Get all columns and search in each
                            # First, get column names
                            cursor.execute(f"DESCRIBE {table_name}")
                            columns_info = cursor.fetchall()
                            column_names = [col[0] for col in columns_info]
                            
                            # Build OR conditions for all columns
                            conditions = " OR ".join([f"CAST({col} AS STRING) LIKE '%{search_term_escaped}%'" for col in column_names])
                            query = f"SELECT * FROM {table_name} WHERE {conditions} LIMIT {limit}"
                    
                    try:
                        cursor.execute(query)
                        
                        # Get column names
                        columns = [desc[0] for desc in cursor.description] if cursor.description else []
                        
                        # Create tab for this table
                        tab_frame = ttk.Frame(self.smart_dispatch_notebook)
                        self.smart_dispatch_notebook.add(tab_frame, text=table_key)
                        
                        # Create treeview for results
                        results_frame = ttk.Frame(tab_frame)
                        results_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
                        
                        tree = ttk.Treeview(results_frame, columns=columns, show='headings')
                        for col in columns:
                            tree.heading(col, text=col)
                            tree.column(col, width=150, anchor=tk.W)
                        
                        # Scrollbars
                        v_scrollbar = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=tree.yview)
                        h_scrollbar = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL, command=tree.xview)
                        tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
                        
                        # Pack widgets
                        tree.grid(row=0, column=0, sticky='nsew')
                        v_scrollbar.grid(row=0, column=1, sticky='ns')
                        h_scrollbar.grid(row=1, column=0, sticky='ew')
                        results_frame.grid_rowconfigure(0, weight=1)
                        results_frame.grid_columnconfigure(0, weight=1)
                        
                        # Fetch and display results
                        rows = cursor.fetchall()
                        for row in rows:
                            tree.insert('', tk.END, values=row)
                        
                        # Store results
                        self.smart_dispatch_results[table_key] = {
                            'columns': columns,
                            'rows': rows,
                            'tree': tree
                        }
                        
                        # Add status label
                        status_label = ttk.Label(tab_frame, text=f"Found {len(rows)} rows")
                        status_label.pack(pady=5)
                        
                    except Exception as e:
                        # Create error tab
                        error_frame = ttk.Frame(self.smart_dispatch_notebook)
                        self.smart_dispatch_notebook.add(error_frame, text=f"{table_key} (Error)")
                        error_text = scrolledtext.ScrolledText(error_frame, wrap=tk.WORD)
                        error_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
                        error_text.insert(tk.END, f"Error querying {table_name}:\n\n{str(e)}\n\nQuery:\n{query}")
                        error_text.config(state=tk.DISABLED)
                
                cursor.close()
                connection.close()
                self.smart_dispatch_status_label.config(text=f"Queries completed for {len(selected_tables)} table(s)")
                
            except Exception as e:
                self.smart_dispatch_status_label.config(text=f"Error: {str(e)}")
                messagebox.showerror("Query Error", f"Query execution failed:\n{str(e)}")
        
        threading.Thread(target=execute, daemon=True).start()
    
    def load_dispatches(self):
        """Load current tickets into the Tickets section"""
        def load():
            try:
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                
                table_name = self.smart_dispatch_tables['current_dispatches']
                query = f"SELECT * FROM {table_name}"
                
                cursor.execute(query)
                
                # Get column names
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                
                # Clear previous results
                for item in self.dispatches_tree.get_children():
                    self.dispatches_tree.delete(item)
                
                # Find address column indices (case-insensitive)
                street_idx = None
                city_idx = None
                county_idx = None
                state_idx = None
                postal_idx = None
                
                for i, col in enumerate(columns):
                    col_lower = col.lower()
                    if 'street' in col_lower:
                        street_idx = i
                    elif 'city' in col_lower:
                        city_idx = i
                    elif 'county' in col_lower:
                        county_idx = i
                    elif 'state' in col_lower:
                        state_idx = i
                    elif 'postal' in col_lower or 'zip' in col_lower:
                        postal_idx = i
                
                # Create new column list with "Address" instead of individual address fields
                address_indices = {street_idx, city_idx, county_idx, state_idx, postal_idx}
                address_indices.discard(None)  # Remove None values
                
                new_columns = []
                address_position = None
                
                for i, col in enumerate(columns):
                    if i in address_indices:
                        if address_position is None:
                            # First address column found, replace with "Address"
                            new_columns.append('Address')
                            address_position = len(new_columns) - 1
                        # Skip other address columns
                    else:
                        new_columns.append(col)
                
                # Configure treeview columns with new combined columns
                self.dispatches_tree['columns'] = new_columns
                for col in new_columns:
                    self.dispatches_tree.heading(col, text=col)
                    if col == 'Address':
                        self.dispatches_tree.column(col, width=300, anchor=tk.W)
                    else:
                        self.dispatches_tree.column(col, width=150, anchor=tk.W)
                
                # Fetch and display results with combined address
                rows = cursor.fetchall()
                for row in rows:
                    # Create new row with combined address
                    new_row = []
                    address_added = False
                    
                    for i, value in enumerate(row):
                        if i in address_indices:
                            if not address_added:
                                # Build combined address
                                address_parts = []
                                if street_idx is not None and row[street_idx]:
                                    address_parts.append(str(row[street_idx]))
                                if city_idx is not None and row[city_idx]:
                                    address_parts.append(str(row[city_idx]))
                                if county_idx is not None and row[county_idx]:
                                    address_parts.append(str(row[county_idx]))
                                if state_idx is not None and row[state_idx]:
                                    address_parts.append(str(row[state_idx]))
                                if postal_idx is not None and row[postal_idx]:
                                    address_parts.append(str(row[postal_idx]))
                                
                                combined_address = ', '.join(address_parts) if address_parts else ''
                                new_row.append(combined_address)
                                address_added = True
                            # Skip other address columns
                        else:
                            new_row.append(value)
                    
                    self.dispatches_tree.insert('', tk.END, values=new_row)
                
                # Store ticket data with lat/lon for map
                # Try to find latitude/longitude columns (case-insensitive)
                lat_idx = None
                lon_idx = None
                ticket_id_idx = None
                
                for i, col in enumerate(columns):
                    col_lower = col.lower()
                    if 'latitude' in col_lower or col_lower == 'lat':
                        lat_idx = i
                    elif 'longitude' in col_lower or col_lower == 'lon' or col_lower == 'lng':
                        lon_idx = i
                    elif 'ticket' in col_lower and 'id' in col_lower:
                        ticket_id_idx = i
                
                self.ticket_data = {
                    'columns': columns,
                    'rows': rows,
                    'lat_idx': lat_idx,
                    'lon_idx': lon_idx,
                    'id_idx': ticket_id_idx
                }
                
                cursor.close()
                connection.close()
                
                # Update map after loading tickets (schedule on main thread)
                self.root.after(100, self.update_map)
                
                self.smart_dispatch_status_label.config(text=f"Loaded {len(rows)} tickets")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load tickets:\n{str(e)}")
                self.smart_dispatch_status_label.config(text=f"Error loading tickets: {str(e)}")
        
        threading.Thread(target=load, daemon=True).start()
    
    def update_map(self):
        """Update the embedded map with current ticket and technician locations"""
        try:
            print("update_map called")
            
            # Verify map display frame exists
            if not hasattr(self, 'map_display_frame') or not self.map_display_frame.winfo_exists():
                print("Map display frame doesn't exist")
                return
            
            # Clear previous map
            for widget in self.map_display_frame.winfo_children():
                widget.destroy()
            
            print(f"Has ticket_data: {hasattr(self, 'ticket_data')}")
            if hasattr(self, 'ticket_data'):
                print(f"Ticket data keys: {self.ticket_data.keys() if self.ticket_data else 'None'}")
                if self.ticket_data:
                    print(f"Ticket rows: {len(self.ticket_data.get('rows', []))}")
                    print(f"Ticket lat_idx: {self.ticket_data.get('lat_idx')}")
                    print(f"Ticket lon_idx: {self.ticket_data.get('lon_idx')}")
            
            # Collect location data
            ticket_lats = []
            ticket_lons = []
            ticket_labels = []
            
            tech_available_lats = []
            tech_available_lons = []
            tech_available_labels = []
            
            # Add ticket locations (red markers)
            if hasattr(self, 'ticket_data') and self.ticket_data.get('rows'):
                ticket_lat_idx = self.ticket_data.get('lat_idx')
                ticket_lon_idx = self.ticket_data.get('lon_idx')
                ticket_id_idx = self.ticket_data.get('id_idx')
                
                if ticket_lat_idx is not None and ticket_lon_idx is not None:
                    for row in self.ticket_data['rows']:
                        try:
                            lat = float(row[ticket_lat_idx])
                            lon = float(row[ticket_lon_idx])
                            ticket_id = row[ticket_id_idx] if ticket_id_idx is not None else "Unknown"
                            
                            ticket_lats.append(lat)
                            ticket_lons.append(lon)
                            
                            # Build detailed label with all ticket info
                            label_parts = [f"TICKET: {ticket_id}"]
                            for i, col_name in enumerate(self.ticket_data['columns']):
                                if i not in [ticket_lat_idx, ticket_lon_idx]:
                                    label_parts.append(f"{col_name}: {row[i]}")
                            ticket_labels.append("\n".join(label_parts[:5]))  # Limit to 5 lines
                        except (ValueError, TypeError, IndexError):
                            continue
            
            # Add technician locations (green/orange markers based on availability)
            if hasattr(self, 'smart_dispatch_results') and 'technicians_combined' in self.smart_dispatch_results:
                tech_data = self.smart_dispatch_results['technicians_combined']
                tech_lat_idx = tech_data.get('lat_idx')
                tech_lon_idx = tech_data.get('lon_idx')
                tech_name_idx = tech_data.get('name_idx')
                
                # Find availability and skill columns
                avail_idx = None
                skill_idx = None
                city_idx = None
                state_idx = None
                
                for i, col in enumerate(tech_data['columns']):
                    col_lower = col.lower()
                    if col_lower == 'available':
                        avail_idx = i
                    elif 'skill' in col_lower:
                        skill_idx = i
                    elif col_lower == 'city':
                        city_idx = i
                    elif col_lower == 'state':
                        state_idx = i
                
                if tech_lat_idx is not None and tech_lon_idx is not None:
                    for row in tech_data['rows']:
                        try:
                            lat = float(row[tech_lat_idx])
                            lon = float(row[tech_lon_idx])
                            tech_name = row[tech_name_idx] if tech_name_idx is not None else "Unknown"
                            
                            # Build detailed label
                            label_parts = [f"TECHNICIAN: {tech_name}"]
                            if skill_idx is not None:
                                label_parts.append(f"Skill: {row[skill_idx]}")
                            if city_idx is not None and state_idx is not None:
                                label_parts.append(f"Location: {row[city_idx]}, {row[state_idx]}")
                            if avail_idx is not None:
                                avail_status = "Available" if (row[avail_idx] == 1 or str(row[avail_idx]).lower() == 'true') else "Unavailable"
                                label_parts.append(f"Status: {avail_status}")
                            label_parts.append(f"Coords: ({lat:.4f}, {lon:.4f})")
                            
                            # Determine availability for color (only show available technicians)
                            if avail_idx is not None:
                                is_available = row[avail_idx]
                                if is_available == 1 or str(is_available).lower() == 'true':
                                    tech_available_lats.append(lat)
                                    tech_available_lons.append(lon)
                                    tech_available_labels.append("\n".join(label_parts))
                                # Skip unavailable technicians (red status) - don't add to map
                            else:
                                # If availability unknown, show on map
                                tech_available_lats.append(lat)
                                tech_available_lons.append(lon)
                                tech_available_labels.append("\n".join(label_parts))
                        except (ValueError, TypeError, IndexError):
                            continue
            
            # Check if we have any data (only count available technicians)
            total_points = len(ticket_lats) + len(tech_available_lats)
            if total_points == 0:
                no_data_label = ttk.Label(self.map_display_frame, text="No location data available.\nLoad tickets and execute queries for technicians first.")
                no_data_label.grid(row=0, column=0, sticky='nsew')
                self.map_status_label.config(text="No location data to display")
                return
            
            # Create matplotlib figure
            fig = Figure(figsize=(6, 8), dpi=100)
            ax = fig.add_subplot(111)
            
            # Store annotations for hover
            annotations = []
            all_lats = []
            all_lons = []
            all_labels = []
            all_colors = []
            
            # Plot tickets (red)
            if ticket_lats:
                ax.scatter(ticket_lons, ticket_lats, c='red', s=100, marker='o', 
                          label=f'Tickets ({len(ticket_lats)})', alpha=0.7, edgecolors='black', linewidth=1.5)
                all_lats.extend(ticket_lats)
                all_lons.extend(ticket_lons)
                all_labels.extend(ticket_labels)
                all_colors.extend(['red'] * len(ticket_lats))
            
            # Plot available technicians (green) - unavailable technicians are not shown
            if tech_available_lats:
                ax.scatter(tech_available_lons, tech_available_lats, c='lime', s=100, marker='^', 
                          label=f'Available Techs ({len(tech_available_lats)})', alpha=0.7, edgecolors='black', linewidth=1.5)
                all_lats.extend(tech_available_lats)
                all_lons.extend(tech_available_lons)
                all_labels.extend(tech_available_labels)
                all_colors.extend(['green'] * len(tech_available_lats))
            
            ax.set_xlabel('Longitude', fontsize=10)
            ax.set_ylabel('Latitude', fontsize=10)
            ax.set_title('Tickets and Technicians Map', fontsize=12, fontweight='bold')
            ax.legend(loc='upper right', fontsize=9)
            ax.grid(True, alpha=0.3)
            
            # Add padding to the view
            if all_lats and all_lons:
                lat_margin = (max(all_lats) - min(all_lats)) * 0.1 or 0.01
                lon_margin = (max(all_lons) - min(all_lons)) * 0.1 or 0.01
                ax.set_xlim(min(all_lons) - lon_margin, max(all_lons) + lon_margin)
                ax.set_ylim(min(all_lats) - lat_margin, max(all_lats) + lat_margin)
            
            # Create annotation for hover
            annot = ax.annotate("", xy=(0,0), xytext=(20,20), textcoords="offset points",
                               bbox=dict(boxstyle="round", fc="yellow", alpha=0.9),
                               arrowprops=dict(arrowstyle="->"))
            annot.set_visible(False)
            
            # Create canvas
            canvas = FigureCanvasTkAgg(fig, master=self.map_display_frame)
            canvas.draw()
            canvas.get_tk_widget().grid(row=0, column=0, sticky='nsew')
            
            # Add hover functionality
            def on_hover(event):
                if event.inaxes == ax:
                    # Find closest point
                    if all_lats and all_lons:
                        min_dist = float('inf')
                        closest_idx = -1
                        
                        for i, (lat, lon) in enumerate(zip(all_lats, all_lons)):
                            dist = ((event.xdata - lon) ** 2 + (event.ydata - lat) ** 2) ** 0.5
                            if dist < min_dist:
                                min_dist = dist
                                closest_idx = i
                        
                        # Show annotation if close enough (threshold based on data range)
                        lat_range = max(all_lats) - min(all_lats) if len(set(all_lats)) > 1 else 1
                        lon_range = max(all_lons) - min(all_lons) if len(set(all_lons)) > 1 else 1
                        threshold = max(lat_range, lon_range) * 0.05
                        
                        if min_dist < threshold and closest_idx >= 0:
                            annot.xy = (all_lons[closest_idx], all_lats[closest_idx])
                            annot.set_text(all_labels[closest_idx])
                            annot.set_visible(True)
                            canvas.draw_idle()
                        else:
                            if annot.get_visible():
                                annot.set_visible(False)
                                canvas.draw_idle()
            
            canvas.mpl_connect('motion_notify_event', on_hover)
            
            # Update status
            self.map_status_label.config(
                text=f"Map showing: {len(ticket_lats)} tickets, "
                     f"{len(tech_available_lats)} available techs"
            )
            
        except Exception as e:
            import traceback
            print(f"Error generating map: {str(e)}")
            print(traceback.format_exc())
            error_label = ttk.Label(self.map_display_frame, 
                                   text=f"Error generating map:\n{str(e)}\n\nCheck console for details",
                                   wraplength=400, justify=tk.LEFT)
            error_label.grid(row=0, column=0, sticky='nsew', padx=10, pady=10)
            self.map_status_label.config(text=f"Map error: {str(e)}")
    
    def zoom_map_to_location(self, lat, lon, label="Selected Location"):
        """Zoom the map to a specific location"""
        try:
            # Clear previous map
            for widget in self.map_display_frame.winfo_children():
                widget.destroy()
            
            # Collect all location data (same as update_map)
            ticket_lats = []
            ticket_lons = []
            ticket_labels = []
            
            tech_available_lats = []
            tech_available_lons = []
            tech_available_labels = []
            
            # Add ticket locations
            if hasattr(self, 'ticket_data') and self.ticket_data.get('rows'):
                ticket_lat_idx = self.ticket_data.get('lat_idx')
                ticket_lon_idx = self.ticket_data.get('lon_idx')
                ticket_id_idx = self.ticket_data.get('id_idx')
                
                if ticket_lat_idx is not None and ticket_lon_idx is not None:
                    for row in self.ticket_data['rows']:
                        try:
                            t_lat = float(row[ticket_lat_idx])
                            t_lon = float(row[ticket_lon_idx])
                            ticket_id = row[ticket_id_idx] if ticket_id_idx is not None else "Unknown"
                            ticket_lats.append(t_lat)
                            ticket_lons.append(t_lon)
                            label_parts = [f"TICKET: {ticket_id}"]
                            for i, col_name in enumerate(self.ticket_data['columns']):
                                if i not in [ticket_lat_idx, ticket_lon_idx]:
                                    label_parts.append(f"{col_name}: {row[i]}")
                            ticket_labels.append("\n".join(label_parts[:5]))
                        except (ValueError, TypeError, IndexError):
                            continue
            
            # Add technician locations
            if hasattr(self, 'smart_dispatch_results') and 'technicians_combined' in self.smart_dispatch_results:
                tech_data = self.smart_dispatch_results['technicians_combined']
                tech_lat_idx = tech_data.get('lat_idx')
                tech_lon_idx = tech_data.get('lon_idx')
                tech_name_idx = tech_data.get('name_idx')
                
                avail_idx = None
                skill_idx = None
                city_idx = None
                state_idx = None
                
                for i, col in enumerate(tech_data['columns']):
                    col_lower = col.lower()
                    if col_lower == 'available':
                        avail_idx = i
                    elif 'skill' in col_lower:
                        skill_idx = i
                    elif col_lower == 'city':
                        city_idx = i
                    elif col_lower == 'state':
                        state_idx = i
                
                if tech_lat_idx is not None and tech_lon_idx is not None:
                    for row in tech_data['rows']:
                        try:
                            t_lat = float(row[tech_lat_idx])
                            t_lon = float(row[tech_lon_idx])
                            tech_name = row[tech_name_idx] if tech_name_idx is not None else "Unknown"
                            
                            label_parts = [f"TECHNICIAN: {tech_name}"]
                            if skill_idx is not None:
                                label_parts.append(f"Skill: {row[skill_idx]}")
                            if city_idx is not None and state_idx is not None:
                                label_parts.append(f"Location: {row[city_idx]}, {row[state_idx]}")
                            if avail_idx is not None:
                                avail_status = "Available" if (row[avail_idx] == 1 or str(row[avail_idx]).lower() == 'true') else "Unavailable"
                                label_parts.append(f"Status: {avail_status}")
                            label_parts.append(f"Coords: ({t_lat:.4f}, {t_lon:.4f})")
                            
                            # Only show available technicians (green status)
                            if avail_idx is not None:
                                is_available = row[avail_idx]
                                if is_available == 1 or str(is_available).lower() == 'true':
                                    tech_available_lats.append(t_lat)
                                    tech_available_lons.append(t_lon)
                                    tech_available_labels.append("\n".join(label_parts))
                                # Skip unavailable technicians (red status)
                            else:
                                # If availability unknown, show on map
                                tech_available_lats.append(t_lat)
                                tech_available_lons.append(t_lon)
                                tech_available_labels.append("\n".join(label_parts))
                        except (ValueError, TypeError, IndexError):
                            continue
            
            # Create matplotlib figure
            fig = Figure(figsize=(6, 8), dpi=100)
            ax = fig.add_subplot(111)
            
            all_lats = []
            all_lons = []
            all_labels = []
            
            # Plot tickets
            if ticket_lats:
                ax.scatter(ticket_lons, ticket_lats, c='red', s=100, marker='o', 
                          label=f'Tickets ({len(ticket_lats)})', alpha=0.7, edgecolors='black', linewidth=1.5)
                all_lats.extend(ticket_lats)
                all_lons.extend(ticket_lons)
                all_labels.extend(ticket_labels)
            
            # Plot available technicians only (green status)
            if tech_available_lats:
                ax.scatter(tech_available_lons, tech_available_lats, c='lime', s=100, marker='^', 
                          label=f'Available Techs ({len(tech_available_lats)})', alpha=0.7, edgecolors='black', linewidth=1.5)
                all_lats.extend(tech_available_lats)
                all_lons.extend(tech_available_lons)
                all_labels.extend(tech_available_labels)
            
            # Highlight selected location with a larger marker
            ax.scatter([lon], [lat], c='yellow', s=300, marker='*', 
                      label=f'Selected: {label}', alpha=0.9, edgecolors='red', linewidth=2, zorder=10)
            
            ax.set_xlabel('Longitude', fontsize=10)
            ax.set_ylabel('Latitude', fontsize=10)
            ax.set_title(f'Zoomed to: {label}', fontsize=12, fontweight='bold')
            ax.legend(loc='upper right', fontsize=9)
            ax.grid(True, alpha=0.3)
            
            # Zoom to selected location with context (show area around it)
            zoom_range = 0.5  # degrees of latitude/longitude to show around the point
            ax.set_xlim(lon - zoom_range, lon + zoom_range)
            ax.set_ylim(lat - zoom_range, lat + zoom_range)
            
            # Create annotation
            annot = ax.annotate("", xy=(0,0), xytext=(20,20), textcoords="offset points",
                               bbox=dict(boxstyle="round", fc="yellow", alpha=0.9),
                               arrowprops=dict(arrowstyle="->"))
            annot.set_visible(False)
            
            # Create canvas
            canvas = FigureCanvasTkAgg(fig, master=self.map_display_frame)
            canvas.draw()
            canvas.get_tk_widget().grid(row=0, column=0, sticky='nsew')
            
            # Add hover functionality
            def on_hover(event):
                if event.inaxes == ax:
                    if all_lats and all_lons:
                        min_dist = float('inf')
                        closest_idx = -1
                        
                        for i, (t_lat, t_lon) in enumerate(zip(all_lats, all_lons)):
                            dist = ((event.xdata - t_lon) ** 2 + (event.ydata - t_lat) ** 2) ** 0.5
                            if dist < min_dist:
                                min_dist = dist
                                closest_idx = i
                        
                        threshold = zoom_range * 0.1
                        
                        if min_dist < threshold and closest_idx >= 0:
                            annot.xy = (all_lons[closest_idx], all_lats[closest_idx])
                            annot.set_text(all_labels[closest_idx])
                            annot.set_visible(True)
                            canvas.draw_idle()
                        else:
                            if annot.get_visible():
                                annot.set_visible(False)
                                canvas.draw_idle()
            
            canvas.mpl_connect('motion_notify_event', on_hover)
            
            # Update status
            self.map_status_label.config(text=f"Zoomed to: {label} ({lat:.4f}, {lon:.4f})")
            
        except Exception as e:
            error_label = ttk.Label(self.map_display_frame, text=f"Error zooming map: {str(e)}")
            error_label.grid(row=0, column=0, sticky='nsew')
            self.map_status_label.config(text=f"Zoom error: {str(e)}")
    
    def create_dispatch_history_tab(self):
        """Create Dispatch History tab"""
        # Search/Filter frame
        filter_frame = ttk.LabelFrame(self.dispatch_history_frame, text="Search Filters", padding=10)
        filter_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Search term
        ttk.Label(filter_frame, text="Search Term:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.dispatch_history_search_var = tk.StringVar()
        search_entry = ttk.Entry(filter_frame, textvariable=self.dispatch_history_search_var, width=40)
        search_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # Column to search (optional)
        ttk.Label(filter_frame, text="Column (optional):").grid(row=0, column=2, sticky=tk.W, padx=5, pady=5)
        self.dispatch_history_column_var = tk.StringVar()
        ttk.Entry(filter_frame, textvariable=self.dispatch_history_column_var, width=30).grid(row=0, column=3, padx=5, pady=5)
        
        # Limit results
        ttk.Label(filter_frame, text="Limit:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.dispatch_history_limit_var = tk.StringVar(value="100")
        ttk.Entry(filter_frame, textvariable=self.dispatch_history_limit_var, width=10).grid(row=1, column=1, sticky=tk.W, padx=5, pady=5)
        
        # Query type selection
        ttk.Label(filter_frame, text="Query Type:").grid(row=1, column=2, sticky=tk.W, padx=5, pady=5)
        self.dispatch_history_query_type_var = tk.StringVar(value="all")
        query_types = [
            ("Search (LIKE)", "search"),
            ("Exact Match", "exact"),
            ("Show All", "all"),
            ("Show Schema", "schema")
        ]
        for i, (text, value) in enumerate(query_types):
            rb = ttk.Radiobutton(filter_frame, text=text, variable=self.dispatch_history_query_type_var, value=value)
            rb.grid(row=1, column=3+i, padx=5, pady=5)
        
        # Buttons frame
        button_frame = ttk.Frame(self.dispatch_history_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(button_frame, text="Load History", command=self.load_dispatch_history).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear Results", command=self.clear_dispatch_history).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Export Results", command=self.export_dispatch_history).pack(side=tk.LEFT, padx=5)
        
        # Results frame
        results_frame = ttk.LabelFrame(self.dispatch_history_frame, text="Dispatch History Results", padding=10)
        results_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Treeview for results
        self.dispatch_history_tree = ttk.Treeview(results_frame)
        self.dispatch_history_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        # Scrollbars
        history_scrollbar_v = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.dispatch_history_tree.yview)
        history_scrollbar_h = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL, command=self.dispatch_history_tree.xview)
        history_scrollbar_v.pack(side=tk.RIGHT, fill=tk.Y)
        history_scrollbar_h.pack(side=tk.BOTTOM, fill=tk.X)
        self.dispatch_history_tree.configure(yscrollcommand=history_scrollbar_v.set, xscrollcommand=history_scrollbar_h.set)
        
        # Status label
        self.dispatch_history_status_label = ttk.Label(self.dispatch_history_frame, text="Ready to load dispatch history")
        self.dispatch_history_status_label.pack(pady=5)
        
        # Store results
        self.dispatch_history_results = []
    
    def load_dispatch_history(self):
        """Load dispatch history"""
        query_type = self.dispatch_history_query_type_var.get()
        search_term = self.dispatch_history_search_var.get().strip()
        
        # Validate search term for search/exact queries
        if query_type in ["search", "exact"] and not search_term:
            messagebox.showwarning("Warning", "Please enter a search term for search/exact queries")
            return
        
        def load():
            try:
                self.dispatch_history_status_label.config(text="Loading dispatch history...")
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                
                table_name = 'hackathon.hackathon_the_original_packet.smart_dispatch_history'
                search_column = self.dispatch_history_column_var.get().strip()
                limit = self.dispatch_history_limit_var.get().strip() or "100"
                search_term_escaped = search_term.replace("'", "''")
                
                # Build query based on type
                if query_type == "schema":
                    query = f"DESCRIBE {table_name}"
                elif query_type == "all":
                    query = f"SELECT * FROM {table_name} LIMIT {limit}"
                elif query_type == "exact":
                    if search_column:
                        query = f"SELECT * FROM {table_name} WHERE {search_column} = '{search_term_escaped}' LIMIT {limit}"
                    else:
                        cursor.execute(f"DESCRIBE {table_name}")
                        columns_info = cursor.fetchall()
                        column_names = [col[0] for col in columns_info]
                        conditions = " OR ".join([f"CAST({col} AS STRING) = '{search_term_escaped}'" for col in column_names])
                        query = f"SELECT * FROM {table_name} WHERE {conditions} LIMIT {limit}"
                else:  # search (LIKE)
                    if search_column:
                        query = f"SELECT * FROM {table_name} WHERE {search_column} LIKE '%{search_term_escaped}%' LIMIT {limit}"
                    else:
                        cursor.execute(f"DESCRIBE {table_name}")
                        columns_info = cursor.fetchall()
                        column_names = [col[0] for col in columns_info]
                        conditions = " OR ".join([f"CAST({col} AS STRING) LIKE '%{search_term_escaped}%'" for col in column_names])
                        query = f"SELECT * FROM {table_name} WHERE {conditions} LIMIT {limit}"
                
                cursor.execute(query)
                
                # Get column names
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                
                # Clear previous results
                for item in self.dispatch_history_tree.get_children():
                    self.dispatch_history_tree.delete(item)
                
                # Configure treeview columns
                self.dispatch_history_tree['columns'] = columns
                self.dispatch_history_tree.heading('#0', text='#')
                for col in columns:
                    self.dispatch_history_tree.heading(col, text=col)
                    self.dispatch_history_tree.column(col, width=150, anchor=tk.W)
                
                # Fetch and display results
                rows = cursor.fetchall()
                for i, row in enumerate(rows):
                    self.dispatch_history_tree.insert('', tk.END, text=str(i+1), values=row)
                
                self.dispatch_history_results = rows
                
                cursor.close()
                connection.close()
                
                self.dispatch_history_status_label.config(text=f"Loaded {len(rows)} history records")
                
            except Exception as e:
                self.dispatch_history_status_label.config(text=f"Error: {str(e)}")
                messagebox.showerror("Error", f"Failed to load dispatch history:\n{str(e)}")
        
        threading.Thread(target=load, daemon=True).start()
    
    def clear_dispatch_history(self):
        """Clear dispatch history results"""
        for item in self.dispatch_history_tree.get_children():
            self.dispatch_history_tree.delete(item)
        self.dispatch_history_results = []
        self.dispatch_history_status_label.config(text="Results cleared")
    
    def export_dispatch_history(self):
        """Export dispatch history to CSV"""
        if not self.dispatch_history_results:
            messagebox.showwarning("Warning", "No results to export")
            return
        
        filename = filedialog.asksaveasfilename(
            title="Export Dispatch History",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                import csv
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    
                    # Write column headers
                    if self.dispatch_history_results:
                        columns = [col for col in self.dispatch_history_tree['columns']]
                        writer.writerow(columns)
                        
                        # Write rows
                        for row in self.dispatch_history_results:
                            writer.writerow(row)
                
                messagebox.showinfo("Success", f"Dispatch history exported to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export results:\n{str(e)}")
    
    def export_smart_dispatch_results(self):
        """Export results to CSV"""
        if not self.smart_dispatch_results:
            messagebox.showwarning("Warning", "No results to export")
            return
        
        filename = filedialog.asksaveasfilename(
            title="Export Results",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                import csv
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    
                    for table_key, data in self.smart_dispatch_results.items():
                        # Write table name as header
                        if table_key == 'technicians_combined':
                            table_name = "Technicians (Combined View)"
                        elif table_key in self.smart_dispatch_tables:
                            table_name = self.smart_dispatch_tables[table_key]
                        else:
                            table_name = table_key
                        
                        writer.writerow([f"Table: {table_name}"])
                        writer.writerow([])
                        
                        # Write column headers
                        writer.writerow(data['columns'])
                        
                        # Write rows
                        for row in data['rows']:
                            writer.writerow(row)
                        
                        writer.writerow([])
                        writer.writerow([])
                
                messagebox.showinfo("Success", f"Results exported to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export results:\n{str(e)}")
    
    
    def log_status(self, message):
        """Log message to status text"""
        self.status_text.config(state=tk.NORMAL)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.status_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.status_text.see(tk.END)
        self.status_text.config(state=tk.DISABLED)
    
    def test_sql_connection(self):
        """Test SQL connection"""
        def test():
            try:
                self.log_status("Testing SQL connection...")
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                cursor.close()
                connection.close()
                self.log_status("✓ SQL connection successful!")
                messagebox.showinfo("Success", "SQL connection test successful!")
            except Exception as e:
                self.log_status(f"✗ SQL connection failed: {str(e)}")
                messagebox.showerror("Connection Error", f"SQL connection failed:\n{str(e)}")
        
        threading.Thread(target=test, daemon=True).start()
    
    def test_workspace_connection(self):
        """Test Workspace API connection"""
        def test():
            try:
                self.log_status("Testing Workspace API connection...")
                client = WorkspaceClient(
                    host=self.workspace_url.get().strip(),
                    token=self.get_access_token()
                )
                # Try to get current user
                current_user = client.current_user.me()
                self.log_status(f"✓ Workspace connection successful! User: {current_user.user_name}")
                messagebox.showinfo("Success", f"Workspace connection successful!\nUser: {current_user.user_name}")
            except Exception as e:
                self.log_status(f"✗ Workspace connection failed: {str(e)}")
                messagebox.showerror("Connection Error", f"Workspace connection failed:\n{str(e)}")
        
        threading.Thread(target=test, daemon=True).start()
    
    def execute_sql_query(self):
        """Execute SQL query"""
        query = self.sql_query_text.get(1.0, tk.END).strip()
        if not query:
            messagebox.showwarning("Warning", "Please enter a SQL query")
            return
        
        def execute():
            try:
                self.sql_status_label.config(text="Executing query...")
                connection = sql.connect(
                    server_hostname=self.server_hostname.get().strip(),
                    http_path=self.http_path.get().strip(),
                    access_token=self.get_access_token()
                )
                cursor = connection.cursor()
                cursor.execute(query)
                
                # Clear previous results
                for item in self.sql_results_tree.get_children():
                    self.sql_results_tree.delete(item)
                
                # Get column names
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                self.sql_results_tree['columns'] = columns
                for col in columns:
                    self.sql_results_tree.heading(col, text=col)
                    self.sql_results_tree.column(col, width=150)
                
                # Fetch and display results
                rows = cursor.fetchall()
                for row in rows:
                    self.sql_results_tree.insert('', tk.END, values=row)
                
                cursor.close()
                connection.close()
                self.sql_status_label.config(text=f"Query executed successfully. {len(rows)} rows returned.")
            except Exception as e:
                self.sql_status_label.config(text=f"Error: {str(e)}")
                messagebox.showerror("Query Error", f"Query execution failed:\n{str(e)}")
        
        threading.Thread(target=execute, daemon=True).start()
    
    def load_query_file(self):
        """Load SQL query from file"""
        filename = filedialog.askopenfilename(
            title="Select SQL File",
            filetypes=[("SQL files", "*.sql"), ("All files", "*.*")]
        )
        if filename:
            try:
                with open(filename, 'r') as f:
                    content = f.read()
                    self.sql_query_text.delete(1.0, tk.END)
                    self.sql_query_text.insert(1.0, content)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load file:\n{str(e)}")
    
def main():
    # Hide console window on Windows if running from console
    if sys.platform == 'win32':
        try:
            import ctypes
            # Try to hide console window (only works if there is one)
            console_window = ctypes.windll.kernel32.GetConsoleWindow()
            if console_window:
                ctypes.windll.user32.ShowWindow(console_window, 0)
        except:
            pass  # If hiding fails, continue anyway
    
    root = tk.Tk()
    app = DatabricksGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()

