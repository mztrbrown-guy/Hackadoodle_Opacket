========================================
SMART DISPATCH OPTIMIZER - USER GUIDE
========================================

WHAT IS THIS?
-------------
This application optimizes technician dispatch assignments for field service operations.
It connects to Databricks and assigns technicians to jobs based on:
- Skill matching
- Geographic proximity
- Workload capacity
- Calendar availability


SYSTEM REQUIREMENTS
-------------------
- Windows 10 or later
- Network connection to Databricks
- Databricks credentials (Server Host, HTTP Path, Access Token)


HOW TO RUN
----------
1. Double-click "SmartDispatchOptimizer.exe"
2. The application window will open
3. On first run, you'll need to configure your Databricks connection


FIRST TIME SETUP
----------------
1. Click the ⚙️ Configuration button to show settings
2. Enter your Databricks information:
   - Server Host: dbc-XXXXXXXX-XXXX.cloud.databricks.com
   - HTTP Path: /sql/1.0/warehouses/XXXXXXXXXX
   - Access Token: (your personal access token)
3. Verify the table names match your Databricks tables
4. Click "▶️ Run Optimization"


TABLE NAMES (DEFAULT)
---------------------
The application is pre-configured with these table names:
- Technicians: hackathon.hackathon_the_original_packet.smart_dispatch_technicians
- Calendar: hackathon.hackathon_the_original_packet.smart_dispatch_technician_calendar
- Dispatches: hackathon.hackathon_the_original_packet.smartdispatchcurrentdispatches

If your tables have different names, update them in the Configuration section.


FEATURES
--------
✓ Optimize dispatch assignments
✓ Row index for easy reference
✓ Sortable columns (click headers to sort ascending/descending)
✓ Column filters (filter by any column with real-time search)
✓ Filter to show only changed assignments
✓ Color highlighting for changed technician assignments (yellow)
✓ Export results to CSV
✓ Update Databricks with optimized assignments
✓ View optimization metrics and statistics


HOW TO USE
----------
1. Click "▶️ Run Optimization"
   - Application will connect to Databricks
   - Load technician, calendar, and dispatch data
   - Calculate optimal assignments

2. Review Results
   - Results appear in the table at the bottom
   - Metrics appear in the top-right panel
   - Yellow highlight = technician was changed (optimized)
   - White = no change from original assignment
   - Status column shows "Yes" (matched) or "No" (no match found)

3. Sort Results (Optional)
   - Click any column header (▲▼) to sort
   - Click again to reverse sort direction
   - Useful for finding patterns (highest distance, specific skills, etc.)

4. Filter Results (Optional)
   - Type in any column filter box to search that column
   - Example: Type "dallas" in City, State to show only Dallas
   - Example: Type "fiber" in Required Skill to show fiber jobs
   - Multiple filters work together (AND logic)
   - Click "✖ Clear All Filters" to reset

5. Show Only Changed Assignments (Optional)
   - Check "🔄 Show Only Changed Assignments" 
   - Table shows only rows where technician was reassigned
   - Works with column filters - you can combine both!
   - Uncheck to see all results again

6. Export Results (Optional)
   - Click "📤 Export to CSV"
   - Choose where to save the file
   - Open in Excel or other tools

7. Update Database (Optional)
   - Click "💾 Update Databricks Table"
   - This writes optimized assignments back to your database
   - Confirmation dialog appears before updating

8. Undo Update (If Needed)
   - If you made a mistake, click "↩️ Undo Update"
   - This reverts all changes back to original assignments
   - Only available after you've updated the database
   - Confirmation dialog appears before undoing


TROUBLESHOOTING
---------------

Problem: "Not connected to Databricks"
Solution: Make sure credentials are configured correctly

Problem: "Table not found"
Solution: Verify table names in Configuration section

Problem: Application won't start
Solution: Check with IT - antivirus may be blocking it

Problem: "Windows protected your PC" message
Solution: Click "More info" → "Run anyway"


SECURITY
--------
- Your credentials are stored locally on YOUR computer only
- They are saved in: databricks_credentials.json
- Never share your Access Token with others
- The .exe file does NOT contain any credentials


GETTING HELP
------------
For support, contact your system administrator or the development team.


VERSION INFORMATION
-------------------
Application: Smart Dispatch Optimizer
Version: 1.0
Platform: Windows
Required Access: Databricks SQL Warehouse


IMPORTANT NOTES
---------------
⚠️ Do not move or rename the .exe file if it's in a folder with other files
⚠️ Keep the .exe in a location you can easily access
⚠️ Your credentials file must stay in the same folder as the .exe
⚠️ Always test optimization results before updating the database


========================================
© 2024 Smart Dispatch Optimizer
========================================

